import App from './App';
import * as constants from '@/common/constants.js';
import util from '@/common/util.js';
import theme from '@/common/theme.js';
import http from '@/common/http.js';
// import * as paths from '@/common/paths.js';

import uView from "@/node_modules/uview-ui";
// import '@/common/icon.css';

// #ifndef VUE3
import Vue from 'vue'
Vue.use(uView);
Vue.config.productionTip = false;

Vue.prototype.$CONSTANTS = constants;
Vue.prototype.$util = util;
Vue.prototype.$http = http;
Vue.prototype.$theme = theme;

// 获取系统信息
const systemInfo = uni.getSystemInfoSync();
Vue.prototype.$APP_NAME = systemInfo.appName;
Vue.prototype.$VERSION = systemInfo.appVersion;
console.log('main.js!', systemInfo);
// 将存储的appName与当前获取的appName对比。
if (uni.getStorageSync('APP_NAME') != Vue.prototype.$APP_NAME) {
	console.log(`Clear storage!`);
	uni.clearStorageSync();
	uni.setStorageSync('APP_NAME', Vue.prototype.$APP_NAME);
	uni.setStorageSync('mask', true);
}

if (!uni.getStorageSync('locale')) {
	uni.setStorageSync('locale', constants.DEFAULT_LOCALE);
}
// 设置当前语言库
util.setLang();

App.mpType = 'app'
const app = new Vue({
	...App
})
app.$mount()
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif

util.switchTabBar(); // 切换底部多语言
// uni.hideTabBar(); // 隐藏tabBar

// 白名单 将无需用户登录也可查看的页面写在这里。默认是启动页、登录页、隐私协议
const whiteList = [constants.LAUNCH,
	constants.SIGN_IN, constants.SIGN_UP,
	constants.PRVITE_PACT
];

// 目标url是否需要权限
function hasPermission(url) {
	// console.log(url, uni.getStorageSync("token"));
	// 在白名单中或有token，直接跳转
	if (whiteList.indexOf(url) !== -1 || uni.getStorageSync("token")) {
		return true;
	}
	return false;
}
// uniapp 跳转行为
const list = ["navigateTo", "reLaunch", "switchTab"]
list.forEach((item) => {
	// 路由拦截
	uni.addInterceptor(item, {
		// 页面跳转前进行拦截, invoke根据返回值进行判断是否继续执行跳转
		invoke(e) {
			if (!hasPermission(e.url)) {
				// 将用户的目标路径保存下来 这样可以实现 用户登录之后，直接跳转到目标页面
				// uni.setStorageSync("URL", e.url)
				uni.navigateTo({
					url: constants.SIGN_IN,
				});
				return false;
			}
			return true;
		}
	});
})