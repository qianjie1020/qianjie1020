<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.NOTIFY_TITLE}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="padding:20rpx;background-color: #F8F8F8;margin:40rpx 32rpx;border-radius: 8rpx;line-height: 1.8;"
					@tap="linkDetail(item.id)">
					<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{item.biaoti}}
					</view>
					<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
						{{$util.formatDate(item.updated_at)}}
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: []
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			linkDetail(val) {
				uni.navigateTo({
					url: this.$CONSTANTS.NOTIFY_DETAIL + `?id=${val}`
				})
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/app/gglist`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result.length > 0 ? result : [];
			}
		}
	}
</script>
<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>