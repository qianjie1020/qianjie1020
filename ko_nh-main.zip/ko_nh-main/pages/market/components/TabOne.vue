<template>
	<view>
		<TitleThird :title="$lang.MARKET_OVERVIEW_SELF_TITLE"></TitleThird>

		<!-- <TabsFifth :tabs="$lang.MARKET_OVERVIEW_SELF_TABS" @action="changeTab" :acitve="curTab"></TabsFifth> -->
		<scroll-view :scroll-x="true" style="white-space: nowrap;width: 99%;padding:0 20rpx 20rpx 0;" @touchmove.stop>
			<block v-for="(item,index) in $lang.MARKET_OVERVIEW_SELF_TABS" :key='index'>
				<view :style="setStyleTab(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</scroll-view>

		<view>
			<view style="display: flex;align-items: center;">
				<block v-for="(item,index) in top1" :key="index">
					<view
						style="flex:33%;padding:6px;margin:6px;border-radius: 6px;background-color: #F6F6F6;border:2px solid rgba(0, 0, 0, 0);line-height: 1.8;"
						:style="{backgroundColor:stockId==index?`#2D54AB1A`: '' }" @click='handleChangeType(index)'>
						<view :style="{color: stockId==index?'#121212':$theme.LOG_LABEL}" style="text-align: center;">
							{{top111[index]}}
						</view>
						<view :class="item.rate>0?'red':'green'" style="text-align: center;"
							:style="$theme.setStockRiseFall(item.rate>0)">{{item.close}}</view>
						<view class="t1 " :class="item.rate>0?'red':'green'" style="text-align: center;"
							:style="$theme.setStockRiseFall(item.rate>0)">{{(item.rate)}}%</view>
					</view>
				</block>
			</view>
			<view class="chart" id="chart-type-k-line" style="width: 100%;height: 300rpx;"> </view>
		</view>

		<view style="height: 48rpx;"></view>

		<TitleThird :title="$lang.MARKET_TABS[1]"></TitleThird>

		<MarketHotTop></MarketHotTop>

		<view style="margin-top:10px;padding:10px 0;">
			<view style="font-size:14px;display: flex;align-items: center;justify-content: center;padding: 10px;"
				@click="handleHot()" :style="{color:$theme.PRIMARY}">
				<view>{{$lang.MARKET_MORE_HOT_TITLE}}</view>
				<view class="arrow rotate_45" style="border-color:#F5B71C" :style="$theme.setImageSize(12)"></view>
			</view>
		</view>

		<TitleThird :title="$lang.MARKET_TABS[3]">
			<view style="font-size: 13px;" @click="linkMarketNews()" :style="{color:$theme.PRIMARY}">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
			</view>
		</TitleThird>

		<view style="display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;">
			<block v-for="(item,index) in article" v-if="index<=3" :key="index">
				<view style="flex:0 0 40%;" @click="open(item.url)">
					<view>
						<image :src="item.pic" mode="scaleToFill" style="border-radius: 8rpx;"
							:style="$theme.setImageSize(320,180)">
						</image>
					</view>
					<view style="white-space: break-spaces;padding: 10rpx 0;font-size: 24rpx;"
						:style="{color:$theme.LOG_VALUE}">
						{{setText(item.title)}}
					</view>
					<view
						style="padding-left: 10px;color:#ccc;text-align: right;font-size: 20rpx;padding-bottom: 20rpx;"
						:style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
			</block>
		</view>

		<TitleThird :title="$lang.MARKET_NEWS_TABS[3]"></TitleThird>

		<view style="padding:20rpx;background-color: #F8F8F8;border-radius: 8rpx;">
			<block v-for="(item,index) in industryList" :key="index">
				<view style="display: flex;align-items: center;line-height: 1.6;padding:10rpx;">
					<view style="font-size: 28rpx;flex:40%" :style="{color:$theme.LOG_VALUE}">{{item.name}}</view>
					<view style="font-size: 28rpx;text-align: right;padding-right: 30rpx;flex:20%;"
						:style="$theme.setStockRiseFall(item.avg_returns*1>0)">
						{{item.avg_returns}}
					</view>
					<view style="font-size: 24rpx;text-align: right;margin-left: auto;"
						:style="{color:$theme.LOG_VALUE}">
						{{item.dt.slice(0,10)}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		init,
		// registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';
	import uCharts from '@/common/u-charts.js';
	// import TabsFifth from '@/components/tabs/TabsFifth.vue';
	// import TabsSecond from '@/components/tabs/TabsSecond.vue'
	import TitleThird from '@/components/title/TitleThird.vue';
	import MarketHotTop from './MarketHotTop.vue';
	var uChartsInstance = {};
	export default {
		name: 'TabOne',
		components: {
			// TabsFifth,
			// TabsSecond,
			TitleThird,
			MarketHotTop
		},
		data() {
			return {
				timer: null,
				curTab: 0, // 国内走势ITEM 
				stockId: 141, // 股票ID,折线图所需股票ID，用于获取该股数据
				top111: {
					141: "코스닥",
					17470: "코스피 200",
					255: "코스피",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kLineChart: null,
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				industryList: [],
			}
		},
		created() {
			this.getData();
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},

		methods: {
			// 文字超出一行。转换为...
			setText(val) {
				let temp = '';
				return temp = val.length <= 15 ? val : val.slice(0, 15) + '...'
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 3000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			changeTab(val) {
				this.current1 = val;
				this.curTab = val;
				this.getData()
			},
			handleChangeTabHot(val) {
				console.log('top:', val);
				this.current2 = val;
				this.top_two()
			},
			handleChangeType(val) {
				this.stockId = val;
				this.getData()
			},

			open(url) {
				window.open(url)
			},

			// 点击查看股票详情
			handleStockInfo(code) {
				uni.navigateTo({
					url: `${this.$CONSTANTS.STOCK_OVERVIEW}?code=${code}`,
				})
			},

			handleHot() {
				uni.reLaunch({
					url: `${this.$CONSTANTS.MARKET_OVERVIEW}?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${this.$CONSTANTS.MARKET_OVERVIEW}?type=3`,
				})
			},

			async getData() {
				// uni.showLoading({
				// 	title: this.$lang.REQUEST_DATA,
				// });
				const result = await this.$http.get(`api/goods/top1`, {
					current1: this.current1,
					stockid: this.stockId
				});
				console.log('getData:', result);
				if (!result) return false;
				this.top1 = result.top1
				this.article = result.article;
				this.industryList = result.bottom;

				if (!this.kLineChart) {
					this.kLineChart = init('chart-type-k-line')
					this.kLineChart.setStyles({
						"candle": {
							"type": "area",
							"tooltip": {
								"showRule": "none",
							}
						},
					});
				}
				this.kLineChart.applyNewData(result.kline)
			},

			// 设置样式
			setStyleTab(val) {
				return {
					padding: `8rpx 48rpx`,
					color: val ? '#FFFFFF' : '#666666',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? `#1C1C1C` : `#EBEDF2`,
					borderRadius: `8rpx`,
					margin: `6rpx`,
					display: `inline-block`,
				}
			},
		},
	}
</script>

<style lang="scss">
	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.yinying-blue {
		box-shadow: #d1e0ff 0px 1px 6px 0px;
	}

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	.charts {
		width: 100%;
		height: 200px;
		margin: 10px;

	}




	.more {
		padding: 10px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}



	.lists {
		padding: 0 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}
</style>