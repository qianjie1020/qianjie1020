<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="display: flex;align-items: center;padding: 48rpx;">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"
				@click="linkToSignIn()"></image>
		</view>
		<view class="left_in">
			<view style="padding:64rpx 80rpx;">
				<view style="font-size: 40rpx;font-weight: 700; color:#333333;line-height: 2.4;padding-bottom: 2vh;">
					{{$lang.SIGN_UP_TITLE}}
				</view>
				<view style="">{{$lang.ACCOUNT_NAME}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="user" type="number" :placeholder="$lang.ACCOUNT_NAME" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
				</view>
				<view>{{$lang.ACCOUNT_PASSWORD}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="password" :password="isMask" :placeholder="$lang.ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
						style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
						@click="toggleMask()">
					</image>
				</view>
				<view>{{$lang.VERIFY_ACCOUNT_PASSWORD}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="verifyPassword" :password="isMask" :placeholder="$lang.VERIFY_ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
						style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
						@click="toggleMask()">
					</image>
				</view>

				<view>{{$lang.INVITATION_CODE}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
				</view>

				<view style="display: flex;align-items: center;justify-content: center;margin: 48rpx 0;">
					<view>
						<u-checkbox-group>
							<u-checkbox shape="circle" :activeColor="$theme.PRIMARY" :label="$lang.TIP_AGREE"
								v-model="isAgree" labelColor="#333333" labelSize="24rpx" @change="changeAgree"
								:checked="isAgree" iconColor="#FFFFFF"></u-checkbox>
						</u-checkbox-group>
					</view>
					<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
						{{$lang.TIP_PRVITE_PACT}}
					</view>
				</view>
			</view>
		</view>


		<view style="position: fixed;bottom: 10%;left: 0;right: 0;">
			<view class="common_btn" style="background-color: #1C1C1C;color:#FFF;margin:48rpx auto;width: 80%;"
				@click="register()">
				{{$lang.SIGN_UP_TITLE}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 掩码
				user: '', // 账户
				password: '', // 密码
				verifyPassword: '',
				code: '',
				isAgree: false, //
			}
		},
		computed: {},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('mask');
			this.changeAgree(this.isAgree);
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			linkToSignIn() {
				uni.navigateTo({
					url: this.$CONSTANTS.SIGN_IN
				})
			},
			// 勾选用户隐私协议
			changeAgree(e) {
				console.log(e);
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				uni.navigateTo({
					url: this.$CONSTANTS.PRVITE_PACT,
				})
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (this.password !== this.verifyPassword) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (this.code == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}
				if (this.isAgree != true) {
					uni.showToast({
						title: this.$lang.TIP_CHECK_AGREE,
						icon: 'none',
					});
					return false;
				}
				return true;
			},
			async register() {
				if (!this.checkForm()) return false;
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				setTimeout(() => {
					this.linkToSignIn();
				}, 1000);
			}
		}
	}
</script>

<style>
</style>