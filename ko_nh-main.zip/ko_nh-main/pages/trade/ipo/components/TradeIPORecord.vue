<template>
	<view style="padding-bottom: 160rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%">
							<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
									{{item.goods.name}}
									<text style="font-size: 20rpx;padding:20rpx;color:#999;">
										{{item.goods.code}}</text>
								</view>
								<view style="margin-left: auto;">
									<template v-if="item.message &&item.message.length>0">
										<view :style="setStyle()"> {{item.message}} </view>
									</template>
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_IPO_RECORD_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">공모 수량</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.goodsshengou.fa_amount}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">신청 금액</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.goodsshengou.fa_muji_zijin}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">배정공고일 </view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.goodsshengou.gb_date}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							매입 시간
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">거래 코드</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: "TradeIPORecord",
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`
				}
			},

		},
	}
</script>