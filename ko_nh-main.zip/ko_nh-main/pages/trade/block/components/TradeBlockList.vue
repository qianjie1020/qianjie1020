<template>
	<view style="padding-bottom: 160rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
									{{item.name}}
									<text style="font-size: 20rpx;padding:20rpx;color:#999;">
										{{item.code}}</text>
								</view>
								<view style="margin-left: auto;">
									<view :style="setStyle()" @click="handleDetail(item)">
										{{$lang.BTN_BUY}}
									</view>
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_BLOCK_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_RATE}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.rate,2)}}%
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_MIN_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.min_num+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_MAX_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.max_num+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeBlockList',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			handleDetail(val) {
				this.$emit('action', val);
			},
			setStyle() {
				return {
					backgroundColor: this.$theme.PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`
				}
			},
		},
	}
</script>