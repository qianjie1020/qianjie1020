<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #2E363B;">
		<!-- <HeaderPrimary isSearch :title="setToday"> </HeaderPrimary> -->
		<header class="header">
			<view class="left">
				<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}"></text>
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<!-- <CardPrimary></CardPrimary> -->

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->

		<!-- <view style="display: flex;align-items: center; justify-content: space-around;margin:30rpx 60rpx;">
			<view :style="setStyle(false)" @click="linkDeposit()">
				<image src="/static/center_left.png" mode="aspectFit" :style="$theme.setImageSize(28)"
					style="padding-right: 40rpx;"></image>
				{{$lang.DEPOSIT_TITLE}}
			</view>
			<view :style="setStyle(true)" @click="linkWithdraw()">
				<image src="/static/center_right.png" mode="aspectFit" :style="$theme.setImageSize(28)"
					style="padding-right: 40rpx;"></image>
				{{$lang.WITHDRAW_TITLE}}
			</view>
		</view> -->

		<!-- <view> -->
		<!-- <NotifyPrimary ref="notify"></NotifyPrimary> -->
		<!-- </view> -->
		<!-- <view
			style="display: flex;align-items: center;justify-content: space-around;line-height: 2.4;border-bottom: 1px solid #434C50;margin-bottom: 48rpx;">
			<block v-for="(item,index) in [`재고`,`자산`]" :key="index">
				<view style="font-size: 32rpx;" :style="{color:curTab==index?'#FFFFFF': '#959CA0'}">
					{{item}}
				</view>
			</block>
		</view> -->

		<view style="padding-bottom: 20rpx;margin: 24rpx 0;">
			<ButtonGroup></ButtonGroup>
		</view>

		<view style="border-radius: 16rpx 16rpx 0 0;background-color: #FFF;padding-top: 24rpx;padding-bottom: 100rpx;">
			<!-- <template v-if="curTab==0"> -->
			<view style="margin:10rpx 40rpx;">
				<TitleThird :title="$lang.MARKET_NEWS_TITLE">
					<view style="font-size: 13px;margin-left: auto;" @click="linkMarketNews()"
						:style="{color:$theme.PRIMARY}">
						{{$lang.MORE}}
						<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
					</view>
				</TitleThird>
			</view>

			<view style="margin-right: 24rpx;">
				<MarketNewsTop></MarketNewsTop>
			</view>

			<view style="margin:10rpx 40rpx;">
				<TitleThird :title="$lang.STOCK_ALL">
					<view style="font-size: 13px;margin-left: auto;" @click="linkAllList()"
						:style="{color:$theme.PRIMARY}">
						{{$lang.MORE}}
						<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
					</view>
				</TitleThird>
			</view>

			<!-- <MarketHot></MarketHot> -->
			<StockList :list="list" @action="handleFollow"></StockList>
			<!-- </template>
			<template v-if="curTab==1 && info">
				<AssetsCard :info="info" />
			</template> -->
		</view>


		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
</template>

<script>
	import CardPrimary from '@/components/card/CardPrimary.vue';
	import NotifyPrimary from '../notify/components/NotifyPrimary.vue';
	import TitleThird from '@/components/title/TitleThird.vue';
	import StockList from './components/StockList.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import MarketNewsTop from '../market/components/MarketNewsTop.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	export default {
		components: {
			CardPrimary,
			NotifyPrimary,
			TitleThird,
			StockList,

			ButtonGroup,
			MarketNewsTop,
			IPOSuccessAlert,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isActLang: true, // 当前登入用户是否开启多语言权限	
				isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.27
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
				list: [], // stock list
				curTab: 0,
				info: null, //
			}
		},
		computed: {
			// 今日
			// setToday() {
			// 	return this.$util.formatToday(new Date());
			// }
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getList();
			console.log(this.cardLabels);
			if (this.$refs.notify) this.$refs.notify.getList();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			linkSearch() {
				uni.navigateTo({
					url: this.$CONSTANTS.SEARCH
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$CONSTANTS.ACCOUNT_DEPOSIT
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: this.$CONSTANTS.ACCOUNT_WITHDRAW
				})
			},

			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$CONSTANTS.MARKET_OVERVIEW + `?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: this.$CONSTANTS.MARKET_OVERVIEW + `?type=3`,
				})
			},

			setStyle(val) {
				return {
					color: val ? '#FFFFFF' : this.$theme.PRIMARY,
					borderRadius: `16rpx`,
					border: `4rpx solid #38AA9A`,
					padding: `16rpx 32rpx`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					minWidth: `160rpx`,
				}
			},

			// 关注
			async handleFollow(id) {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.getList();
				}, 1000);
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/top2`, {
					current: 0,
					current1: 0,
				})
				if (!result) return false;
				this.list = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>