<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData img="search"></EmptyData>
		</template>
		<template v-else>
			<!-- <view style="color:#A8A8A8;line-height: 2.4;padding-left: 40rpx;">
				{{$lang.SEATCH_RESULT_COUNT + ` ${list.length}`}}
			</view>
			<view style="height: 1px;background-color: #F3F3F3;width: 90%;margin:0 auto;"></view> -->
			<block v-for="(item,index) in list" :key="index">
				<view
					style="display: flex;align-items: center;padding:16rpx 0;background-color: #F8F8F8;border-radius: 8rpx;margin:0 12rpx 20rpx 12rpx"
					@click="link(item.code)">
					<view style="width: 90rpx;text-align: center;">
						<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
					</view>
					<view style="flex:1 0 auto;">
						<view style="font-size: 28rpx;color: #121212;padding:0 20rpx;">
							{{item.name}}
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(24)" style="padding-left: 20rpx;"></image>
						</view>
						<view style="display: flex;align-items: center;padding:0 20rpx;">
							<view style="font-size: 24rpx;padding-right:80rpx;" :style="{color:$theme.LOG_LABEL}">
								{{item.code}}
							</view>
							<view style="font-size: 26rpx;text-align: center;"
								:style="$theme.setStockRiseFall(item.rate>0)">
								{{item.rate>0?'+':'-'}} {{$util.formatNumber(item.price)}}
							</view>
							<view style="margin-left: auto;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{item.rate>0?'+':'-'}} {{($util.formatNumber(Math.abs(item.rate),2))}}%
							</view>
						</view>
					</view>

					<!-- <view style="flex:50%;padding-left: 10px;">
						<view style="font-size: 32rpx;color: #121212;">
							{{item.name}}
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)" style="padding-left: 20rpx;"></image>
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.code}}
						</view>
					</view>

					<view style="font-size: 32rpx;color: #121212;flex: 30%;text-align: right;">
						{{$util.formatNumber(item.price)}}
					</view>
					<view :style="$theme.setStockRiseFall(item.rate>0)" style="margin-left: auto;padding-left: 32rpx;">
						{{($util.formatNumber(Math.abs(item.rate),2))}}%
					</view> -->
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'SearchList',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			// 列表数据
			list: {
				type: Array,
				default: []
			},
		},

		methods: {
			// 跳转到股票详情
			link(code) {
				if (!code || code == '') return false;
				uni.navigateTo({
					url: `${this.$CONSTANTS.STOCK_OVERVIEW}?code=${code}`
				});
			}
		}
	}
</script>

<style>
</style>