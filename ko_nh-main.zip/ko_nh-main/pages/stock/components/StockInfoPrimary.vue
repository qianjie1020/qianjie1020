<template>
	<view style="padding:20rpx;margin:0 16rpx;">
		<view style="display: flex;align-items: center;">
			<view style="flex:0 0 6%">
				<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
			</view>
			<view style="flex:84%">
				<view style="margin-bottom: 2px;font-size: 32rpx;padding-left: 20rpx;" :style="{color:$theme.PRIMARY}">
					{{info.name}}
					<image :src="`/static/arrow_${info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
						:style="$theme.setImageSize(28)" style="margin-left: 10px;"></image>
				</view>
				<view style="font-size: 20rpx;padding-left: 20rpx;" :style="{color:$theme.LOG_LABEL}">
					{{info.number_code}} {{info.ct_name}}
				</view>
			</view>
			<view style="flex:10%;text-align: right;" @click="handleUnFollow(info.gid)">
				<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
					:style="$theme.setImageSize(36)"></image>
			</view>
		</view>
		<view style="display: flex;align-items: center;padding-top:20rpx;justify-content:space-between;"
			:style="$theme.setStockRiseFall(info.rate>0)">
			<view style="font-size: 32rpx;">
				{{$util.formatNumber(info.current_price)}} {{$lang.CURRENCY_UNIT}}
			</view>
			<view style="text-align: right;font-size: 32rpx;">
				{{$util.formatNumber(info.rate_num)}}
			</view>
			<view style="text-align: right;font-size: 32rpx;">
				{{$util.formatNumber(info.rate)}}%
			</view>
		</view>

		<view style="display: flex;align-items: center;margin-bottom: 12rpx;line-height: 1.4;padding-top: 20rpx;">
			<view style="flex: 0 0 25%; ">
				<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.open) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[0]}}
				</view>
			</view>
			<view style="flex: 0 0 30%; ">
				<view style="font-size: 28rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.high) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;text-align: center;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[2]}}
				</view>
			</view>
			<view style="flex: 0 0 45%; ">
				<view style="font-size: 28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.volume / 10000) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;text-align: right;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[4]}}
				</view>
			</view>
		</view>

		<view style="display: flex;align-items: center;margin-bottom: 12rpx;line-height: 1.4;">
			<view style="flex: 0 0 25%; ">
				<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.prev_close) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[1]}}
				</view>
			</view>

			<view style="flex: 0 0 30%; ">
				<view style="font-size: 28rpx;text-align: center;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.low) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;text-align: center;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[3]}}
				</view>
			</view>
			<view style="flex: 0 0 45%; ">
				<view style="font-size: 28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
					{{$util.formatNumber(info.info.volume_valued / 10000) + ` ${$lang.CURRENCY_UNIT}`}}
				</view>
				<view style="font-size: 20rpx;text-align: right;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.STOCK_INFO_TITLES[5]}}
				</view>
			</view>
		</view>

		<!-- <view style="display: flex;align-items: center;line-height: 1.4;">
			<view style="flex: 1 0 45%;"> </view>
			<view style="flex:1 0 10%;"></view>
			<view style="flex: 1 0 45%;"> </view>
		</view> -->
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'StockInfoPrimary',
		components: {
			CustomLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {
			setInfo() {
				return [
					this.$util.formatNumber(this.info.info.open) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.prev_close) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.high) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.low) + ` ` + this.$lang.CURRENCY_UNIT,
					this.$util.formatNumber(this.info.info.volume / 10000),
					this.$util.formatNumber(this.info.info.volume_valued / 10000) + ` ` + this.$lang.CURRENCY_UNIT,
				]
			}
		},

		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				})
				console.log(`result:`, result);
				// uni.showToast({
				// 	title: result.message,
				// 	icon: 'none'
				// });
				this.info.is_collected = this.info.is_collected == 1 ? 0 : 1;
			},
		}
	}
</script>

<style>
</style>