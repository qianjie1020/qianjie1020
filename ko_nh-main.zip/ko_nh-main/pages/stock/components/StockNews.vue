<template>
	<view style="padding: 36rpx;">
		<block v-for="(item,index) in list" :key="index">
			<view @click="open(item.link)" :class="index<list.length-1?'line':''"
				style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;">
				<view style="flex:60%;padding-right: 10px;">
					<view :style="{color:$theme.LOG_VALUE}">{{item.title}}</view>
					<view style="margin:6px;margin-top: 16px;padding: 4px 0;" :style="{color:$theme.LOG_LABEL}">
						{{$util.formatDate(item.dt)}}
					</view>
				</view>
				<image :src="item.image" :style="$theme.setImageSize(200,150)" style="border-radius: 10px;"></image>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "StockNews",
		props: ['code', 'id'],
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList()
		},
		methods: {
			open(url) {
				window.open(url)
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/news`, {
					code: this.code,
					time_index: this.curKLine
				});
				if (!result) return false;
				this.list = result[0];
			},
		},
	}
</script>