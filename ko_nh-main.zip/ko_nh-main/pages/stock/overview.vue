<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{stockTitle}}</text>
			</view>
		</header>

		<view style="padding-bottom: 20px;">
			<template v-if="stockInfo">
				<StockInfoPrimary :info="stockInfo"></StockInfoPrimary>
				<view style="background-color: #ECECEC;height: 4rpx;margin-bottom: 20rpx;"></view>
				<!-- <TabsFourth :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"></TabsFourth> -->
				<view style="display: flex;align-items: center;justify-content:space-between;
						background-color: #EBEDF2;margin:0 40rpx 20rpx 40rpx;">
					<block v-for="(v,k) in $lang.STOCK_OVERVIEW_TABS" :key="k">
						<view @click="changeTab(k)" :style="setStyleTab(curTab ==k)">{{v}}</view>
					</block>
				</view>

				<template v-if="curTab==0">
					<view
						style="margin:28rpx 40rpx 20rpx 40rpx;display: flex;align-items: center;justify-content: space-between;">
						<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key='index'>
							<view :style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
								{{item}}
							</view>
						</block>
					</view>

					<template v-if="isShowKline">
						<StockKLine :list="klineList" :active="curKLine" ref="kline"></StockKLine>
					</template>

					<view class="common_btn" @click="linkBuy"
						style="margin:60rpx auto;width: 80%;background-color: #1C1C1C;color:#FFF;">
						{{$lang.BTN_BUY}}
					</view>
				</template>

				<template v-if="curTab==1">
					<StockDetail :code='code' :id='stockInfo.stock_id'></StockDetail>
				</template>

				<template v-if="curTab==2">
					<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
				</template>
			</template>
		</view>

		<!-- 买入弹层 -->
		<u-popup :show="showBuy" @close="closeBuy" @open="open" :round="10" closeable closeOnClickOverlay>
			<view style="padding:40rpx 20rpx;padding-bottom: 120rpx;">
				<view style="text-align: center;font-size: 32rpx;font-weight: 700;">{{stockInfo? stockInfo.name:''}}
				</view>
				<view style="margin:10rpx 40rpx;">
					<TitleThird :title="$lang.STOCK_BUY_QUANTITY"></TitleThird>
				</view>

				<view style="display: flex;flex-wrap:wrap;padding:10px;">
					<block v-for="(item,index) in quantityList" :key="index">
						<view style="width:max-content;line-height: 1.6;" :style="setStyle(curQuantity==item)"
							@click="chooseQTY(item)">
							{{$util.formatNumber(item)}}
						</view>
					</block>
				</view>

				<view class="common_input_wrapper" style="padding-left: 40rpx;margin: 20rpx 32rpx;">
					<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY"
						@input="handleInput" :placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<!-- 杠杆数组大于1，视为开启杠杆功能 -->
				<template v-if="leverList.length>0">
					<view style="margin:10rpx 40rpx;">
						<TitleThird :title="$lang.LEVER"></TitleThird>
					</view>
					<view style="display: flex;flex-wrap:wrap;padding:10px;">
						<block v-for="(item,index) in leverList" :key="index">
							<view style="width:10%;line-height: 1.6;" :style="setStyle(curLever==item)"
								@click="chooseLever(item)">
								{{item}}
							</view>
						</block>
					</view>
				</template>

				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
					<view :style="{color:$theme.LOG_VALUE}">
						{{$util.formatNumber(quantity)}}
					</view>
					<template v-if="leverList.length>1">
						<view>{{$lang.LEVER}}</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{curLever}}
						</view>
					</template>
				</view>

				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="stockInfo">
							{{$util.formatNumber(stockInfo.current_price*curQuantity/curLever)}}
						</template>
					</view>
				</view>
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;padding:0 40rpx;"
					:style="{color:$theme.LOG_LABEL}">
					<view>{{$lang.STOCK_BUY_FEE}}[{{$lang.CURRENCY_UNIT}}]</view>
					<view :style="{color:$theme.LOG_VALUE}">
						<template v-if="stockInfo">
							{{$util.formatNumber(stockInfo.current_price*curQuantity/curLever*fee)}}
						</template>
					</view>
				</view>

				<view class="common_btn" style="margin:60rpx auto;width: 80%;background-color: #1C1C1C;color:#FFF;"
					@click="placeOrder()">
					{{$lang.BTN_BUY}}
				</view>
			</view>
		</u-popup>
	</view>
</template>

<script>
	// import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import StockDetail from './components/StockDetail.vue'
	import StockNews from './components/StockNews.vue';
	import StockInfoPrimary from './components/StockInfoPrimary.vue';
	import StockKLine from './components/StockKLine.vue';
	import TitleThird from '@/components/title/TitleThird.vue';
	export default {
		components: {
			// TabsFourth,
			StockDetail,
			StockNews,
			StockInfoPrimary,
			StockKLine,
			TitleThird,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，				
				timer: null,
				curKLine: 0, // 当前显示的Kline数据图标
				klineList: [],
				showBuy: false, // 买入弹层
				quantityList: [100, 150, 200, 300, 500], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				quantity: 100, // 数量输入框 
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前选中杠杆值
				fee: 1, // 手续费
			};
		},
		computed: {
			stockTitle() {
				return this.stockInfo && this.stockInfo.name ?
					this.stockInfo.name : this.$lang.STOCK_OVERVIEW_TITLE
			},
			// 图表数据
			klineDataStock() {
				return this.klineList && this.klineList.length > 0 ?
					this.klineList : []
			},
			// 显示图表
			isShowKline() {
				return this.klineDataStock.length > 0
			},
		},

		onLoad(option) {
			this.code = option.code;
		},
		onShow() {
			this.isAnimat = true;
			this.getStockInfo();
			this.getConfig();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.getStockInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			open() {
				console.log('open!');
			},
			closeBuy() {
				this.showBuy = false;
			},
			// 买入
			linkBuy() {
				// uni.navigateTo({
				// 	url: `${this.$CONSTANTS.STOCK_BUY}?code=${this.code}`
				// });
				this.showBuy = true;
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
			},
			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`config result:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.fee = temp.get('TransRate') || this.fee;
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},
			//购买
			async placeOrder() {
				const money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},
			async buy() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.STOCK_BUY_TIP_QUANTITY,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					ganggan: this.curLever,
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					console.log(11);
					uni.switchTab({
						url: this.$CONSTANTS.POSITION,
					});
				}, 1000)
			},
			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				if (result.ganggan) {
					console.log(result.ganggan);
					console.log(this.$util.leverList(result.ganggan));
					this.leverList = this.$util.leverList(result.ganggan);
				}
			},

			changeTab(val) {
				this.clearTimer(); // 每次切换，停止计时器
				console.log('val:', val);
				this.curTab = val;
				if (this.curTab == 0) this.handleShowKLine(0);
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.genKLineData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				this.clearTimer(); // 每次切换，停止计时器
				this.curKLine = val;
				this.getStockInfo();
			},
			// 产品详情
			async getStockInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				if (!result) return false;
				this.stockInfo = result[0];
				if (this.curTab == 0) {
					this.genKLineData();
					this.onSetTimeout(); // 开启计时器
				}
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				if (!result) return false;
				this.klineList = result;
				if (this.isShowKline && this.$refs.kline) {
					// 使图表组件重新渲染
					this.$refs.kline.renderInit();
				}
			},
			// tab样式
			setStyleTab(val) {
				return {
					minWidth: `80rpx`,
					padding: `8rpx 48rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `8rpx`,
					lineHeight: `1.6`,
				}
			},

			// 设置样式
			setStyle(val) {
				return {
					// minWidth: `80rpx`,
					padding: `8rpx 48rpx`,
					color: val ? '#FFFFFF' : '#666666',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? `#1C1C1C` : `#EBEDF2`,
					borderRadius: `8rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>