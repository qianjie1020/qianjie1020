<template>
	<view :class="isAnimat?'fade_in':'fade_out'">

		<view class="right_in" style="margin-top: 10vh;">
			<view style="padding:80rpx;">
				<view style="font-size: 40rpx;font-weight: 700; color:#333333;line-height: 2.4;padding-bottom: 5vh;">
					{{$lang.SIGN_IN_TITLE}}
				</view>
				<view style="">{{$lang.ACCOUNT_NAME}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="user" type="number" :placeholder="$lang.ACCOUNT_NAME" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
				</view>
				<view>{{$lang.ACCOUNT_PASSWORD}}</view>
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;padding-left: 24rpx;">
					<input v-model="password" :password="isMask" :placeholder="$lang.ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					<image :src="`/static/${isMask?'hide':'show'}_dark.png`" mode="aspectFit"
						style="margin-left: auto;padding-right: 24rpx;" :style="$theme.setImageSize(32)"
						@click="toggleMask()">
					</image>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;margin: 40rpx 0;">
					<u-checkbox-group>
						<!-- circle -->
						<u-checkbox shape="circle" :activeColor="$theme.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
							v-model="isRemember" :labelColor="$theme.PRIMARY" labelSize="24rpx" @change="changeRemember"
							:checked="isRemember" iconColor="#FFFFFF"></u-checkbox>
					</u-checkbox-group>
					<!-- <view>{{$lang.FORGOT_PWD}}</view> -->
					<view @click="linkToSignUp()" :style="{color:$theme.PRIMARY}">
						{{$lang.SIGN_UP_TITLE}}
					</view>
				</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 10%;left: 0;right: 0;">
			<view class="common_btn" style="background-color: #1C1C1C;color:#FFF;margin:48rpx auto;width: 80%;"
				@click="signIn()">
				{{$lang.SIGN_IN_TITLE}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				isMask: null, // 掩码
				user: '', // 账户
				password: '', // 密码
				isRemember: true, // 记住密码
			}
		},
		computed: {},
		onLoad() {
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
		},
		onShow() {
			this.isAnimat = true;
			this.isMask = uni.getStorageSync('mask');
			this.changeRemember(this.isRemember);
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			linkToSignUp() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.navigateTo({
					url: this.$CONSTANTS.SIGN_UP
				})
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				return true;
			},
			async signIn() {
				if (!this.checkForm()) return false;
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$CONSTANTS.HOME,
					});
				}, 1000);
			}
		}
	}
</script>

<style>
</style>