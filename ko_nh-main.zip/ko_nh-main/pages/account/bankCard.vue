<!-- 绑定银行卡 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.BIND_BANK_CARD_TITLE}}</text>
			</view>
		</header>

		<view style="margin: 80rpx 36rpx;">
			<TitlePrimary :title="$lang.BIND_BANK_CARD_REAL_NAME"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<!-- <image mode="aspectFit" src="/static/user.png" :style="$theme.setImageSize(40)">
				</image> -->
				<input v-model="info.realName" type="text" :placeholder="$lang.BIND_BANK_CARD_REAL_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.BIND_BANK_CARD_BANK_NAME"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<!-- <image mode="aspectFit" src="/static/bank.png" :style="$theme.setImageSize(40)">
				</image> -->
				<input v-model="info.bankName" type="text" :placeholder="$lang.BIND_BANK_CARD_BANK_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.BIND_BANK_CARD_ID"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;padding-left: 40rpx;">
				<!-- <image mode="aspectFit" src="/static/bank_card_id.png" :style="$theme.setImageSize(40)">
				</image> -->
				<input v-model="info.cardSN" type="text" :placeholder="$lang.BIND_BANK_CARD_ID"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>

			<view class="common_btn" style="margin:60rpx auto;background-color: #1C1C1C;color:#FFF;"
				@click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		components: {
			TitlePrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
			};
		},
		computed: {},
		onLoad() {},
		onShow() {
			this.getAccountInfo()
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 检查表单
			checkForm() {
				if (this.info.realName == '') {
					uni.showToast({
						title: this.$lang.TIP_BIND_BANK_CARD_REAL_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.bankName == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.cardSN == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_CARD,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.bindCard();
				}
			},
			// 换绑银行卡
			async bindCard() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.info.realName,
					bank_name: this.info.bankName,
					card_sn: this.info.cardSN,
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$CONSTANTS.ACCOUNT_CENTER
					});
				}, 1000)
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				// 未有真实姓名，跳转到实名认证
				if (!result.real_name) {
					uni.navigateTo({
						url: this.$CONSTANTS.ACCOUNT_AUTH,
					})
				}
				if (result.bank_card_info) {
					this.info = {
						realName: result.bank_card_info.realname || '',
						bankName: result.bank_card_info.bank_name || '',
						cardSN: result.bank_card_info.card_sn || '',
					}
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>