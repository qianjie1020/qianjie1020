<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #EBEDF2;min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.FLOW_INDEX_TITLE}}</text>
			</view>
		</header>

		<view
			style="margin:0 36rpx;margin-bottom: 28rpx;border-radius: 16rpx;display: flex;align-items: center;justify-content: space-between;background-color: #FFF;padding:0 24rpx;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view style="font-size: 28rpx;text-align: center;line-height: 2.4;"
					:style="{color:curTab==index?`#1C1C1C`:`#959CA0`}" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<view :class="setClass" style="padding:20rpx 0; margin:20rpx 0;">
			<template v-if="curTab==0">
				<TradeRecord :list="tradeList"></TradeRecord>
			</template>
			<template v-if="curTab==1">
				<DepositRecord :list="depList"></DepositRecord>
			</template>
			<template v-if="curTab==2">
				<WithdrawRecord :list="withList"></WithdrawRecord>
			</template>
		</view>
	</view>
</template>

<script>
	import TradeRecord from './components/TradeRecord.vue';
	import WithdrawRecord from './components/WithdrawRecord.vue';
	import DepositRecord from './components/DepositRecord.vue';
	export default {
		components: {
			TradeRecord,
			WithdrawRecord,
			DepositRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				tradeList: [],
				depList: [],
				withList: [],
			};
		},
		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.TRADE_LOG_TRADE,
					this.$lang.TRADE_LOG_DEPOSIT,
					this.$lang.TRADE_LOG_WITHDRAW
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},
		onLoad(opt) {
			this.curTab = Number(opt.code) || 0;
		},
		onShow() {
			this.isAnimat = true;
			if (this.curTab == 0) this.getTradeList();
			if (this.curTab == 1) this.getDepositList();
			if (this.curTab == 2) this.getWithdrawList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			if (this.curTab == 0) this.getTradeList();
			if (this.curTab == 1) this.getDepositList();
			if (this.curTab == 2) this.getWithdrawList();
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getTradeList();
				if (this.curTab == 1) this.getDepositList();
				if (this.curTab == 2) this.getWithdrawList();
			},


			// 
			async getDepositList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/recharge`);
				if (!result) return false;
				console.log('result:', result);
				this.depList = result;
			},

			// 交易记录
			async getTradeList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/finance`);
				if (!result) return false;
				console.log('result:', result);
				this.tradeList = result;
			},

			async getWithdrawList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/withdraw`);
				if (!result) return false;
				console.log('result:', result);
				this.withList = result;
			},

			// 设置样式
			setStyle(val) {
				return {
					minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		}
	}
</script>
<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>