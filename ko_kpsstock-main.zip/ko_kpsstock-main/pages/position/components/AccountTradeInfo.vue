<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<view style="display: flex;justify-content: space-between;margin:30rpx 60rpx;">
			<view :style="setStyle(false)" @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/center_left.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
					<view style="font-size: 32rpx;font-weight: 600;padding-left: 20rpx;">{{$lang.DEPOSIT_TITLE}}</view>
				</view>
			</view>
			<view :style="setStyle(true)" @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/center_right.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
					<view style="font-size: 32rpx;font-weight: 600;padding-left: 20rpx;">{{$lang.WITHDRAW_TITLE}}</view>
				</view>
			</view>
		</view>

		<view style="background-color: #FFFFFF;padding:20rpx 40rpx 10rpx 40rpx;border-radius: 28rpx;margin:0 20rpx">
			<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
				<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
					<view :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_TOTAL_BUY_AMOUNT}}
					</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(userInfo.frozen)}}
					</view>
				</view>
				<view style="flex:1 0 10%;"></view>
				<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
					<view :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_VALUATION_GAIN_LOSS}}
					</view>
					<view style="font-size:32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(userInfo.holdYingli)}}
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
				<view style="flex: 1 0 45%;">
					<view :style="{color:$theme.LOG_LABEL}">
						{{$lang.ACCOUNT_AMOUNT_TOTAL}}
					</view>
					<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(userInfo.totalZichan)}}
					</view>
				</view>
				<view style="flex:1 0 10%;"></view>
				<view style="flex: 1 0 45%;">
					<view :style="{color:$theme.LOG_LABEL}">
						{{$lang.TRADE_TOTAL_GAIN}}
					</view>
					<view style="font-size:32rpx;" :style="{color:$theme.LOG_VALUE}">
						{{$util.formatMoney(userInfo.totalYingli)}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		name: 'AccountTradeInfo',
		components: {
			CardItemThird,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				cardData: {}, // 资产相关数据
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT
				];
			},
			// 是否显示饼图
			isPieChart() {
				return this.cardData && Object.keys(this.cardData).length > 0;
			}
		},
		created() {
			this.getAccountInfo();
		},
		methods: {
			// 入金 提款 按钮样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#F8F8F8' : this.$theme.SECOND,
					borderRadius: `24rpx`,
					padding: `24rpx 0`,
					width: `280rpx`,
				}
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan * 1, // 
					value2: this.userInfo.money, // 
					value3: this.userInfo.freeze, // 
				};
			},
		}
	}
</script>
<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>