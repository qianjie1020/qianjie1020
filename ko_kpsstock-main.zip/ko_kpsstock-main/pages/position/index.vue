<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header style="padding-top: 60rpx;border-bottom: 1px solid #E7E8ED;">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
				<view style="display: flex;margin:0 10rpx;">
					<block v-for="(item,index) in tabs" :key='index'>
						<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
							{{item}}
						</view>
					</block>
				</view>
			</scroll-view>
		</header>

		<template v-if="curTab==0">
			<AccountTradeInfo></AccountTradeInfo>
			<view style="padding:30rpx 40rpx 0 40rpx;">
				<view style="display: flex;flex-wrap: nowrap;align-items: center;line-height: 2;">
					<view style="font-size: 36rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
						{{$lang.TRADE_TITLE}}
					</view>
					<view style="margin-left: auto;">
						<view style="font-size: 13px;" @click="changeTab(1)" :style="{color:$theme.SECOND}">
							{{$lang.MORE}}
							<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
						</view>
					</view>
				</view>
			</view>

			<AccountTradeHoldList ref="hold1"></AccountTradeHoldList>
		</template>

		<template v-else-if="curTab==1">
			<AccountTradeHoldList ref="hold"></AccountTradeHoldList>
		</template>
		<template v-else>
			<AccountTradeSellList ref="sell"></AccountTradeSellList>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import AccountTradeInfo from './components/AccountTradeInfo.vue';
	import AccountTradeHoldList from './components/AccountTradeHoldList.vue';
	import AccountTradeSellList from './components/AccountTradeSellList.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TitlePrimary,
			AccountTradeInfo,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				list: [],
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		// 觸底加載
		onReachBottom() {
			if (this.curTab == 0 && this.$refs.hold1) {
				console.log(this.$refs.hold1);
				if (this.$refs.hold1.curPage < this.$refs.hold1.maxPage) {
					this.$refs.hold1.curPage++;
					this.$refs.hold1.getList();
				}
			}
			if (this.curTab == 1 && this.$refs.hold) {
				console.log(this.$refs.hold);
				if (this.$refs.hold.curPage < this.$refs.hold.maxPage) {
					this.$refs.hold.curPage++;
					this.$refs.hold.getList();
				}
			}
			if (this.curTab == 2 && this.$refs.sell) {
				console.log(this.$refs.sell);
				if (this.$refs.sell.curPage < this.$refs.sell.maxPage) {
					this.$refs.sell.curPage++;
					this.$refs.sell.getList();
				}
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			if (this.$refs.hold1) {
				this.$refs.hold1.curPage = 1;
				this.$refs.hold1.list = [];
				this.$refs.hold1.getList();
			}
			if (this.$refs.hold) {
				this.$refs.hold.curPage = 1;
				this.$refs.hold.list = [];
				this.$refs.hold.getList();
			}
			if (this.$refs.sell) {
				this.$refs.sell.curPage = 1;
				this.$refs.sell.list = [];
				this.$refs.sell.getList();
			}
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>