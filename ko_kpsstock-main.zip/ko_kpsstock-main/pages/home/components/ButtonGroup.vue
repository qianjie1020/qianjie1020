<template>
	<view class="btns " style="">
		<block v-for="(item,index) in btnConfig" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(80)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		computed: {
			btnConfig() {
				// 根据客户需求，调整位置，注释不需要要显示的项
				const temp = [{
						name: this.$lang.TRADE_DAY_TITLE, // 日内交易
						url: this.$paths.TRADE_DAY,
					},
					{
						name: this.$lang.TRADE_LARGE_TITLE, // 大宗交易
						url: this.$paths.TRADE_LARGE,
					},
					{
						name: this.$lang.TRADE_IPO_TITLE, // IPO
						url: this.$paths.TRADE_IPO,
					},
					{
						name: this.$lang.TRADE_VIP_TITLE, // VIP
						url: this.$paths.TRADE_VIP,
					},
					{
						name: this.$lang.TRADE_ISSUANCE_TITLE, // 新股配售
						url: this.$paths.TRADE_ISSUANCE,
					},
					{
						name: this.$lang.DEPOSIT_TITLE, // 入金/充值
						url: this.$paths.ACCOUNT_DEPOSIT,
					}, {
						name: this.$lang.WITHDRAW_TITLE, // 出金/提款
						url: this.$paths.ACCOUNT_WITHDRAW,
					}, 
					// {
					// 	name: this.$lang.AUTH_TITLE, // 实名认证
					// 	url: this.$paths.ACCOUNT_AUTH,
					// }, 
					{
						name: this.$lang.ACCOUNT_SERVICE, // 客服
						url: this.$paths.SERVICE,
					},
				].map((item, index) => {
					return {
						name: item.name,
						icon: `top${index}`,
						url: item.url
					}
				});
				return temp;
			}
		},

		methods: {
			actionEvent(url, index) {
				if(url.includes("/pages/service")){
					uni.$u.toast('고객 서비스 매니저에 연락해주세요.');
					return 
				}
				
				if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px 0;

		.item {
			width: 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #CBCBCF;
			padding: 4px 0;
		}
	}
</style>