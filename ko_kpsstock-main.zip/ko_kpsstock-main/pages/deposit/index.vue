<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond>
		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx;" :style="{color:$theme.SECOND}">
			{{$lang.DEPOSIT_TITLE}}
		</view>

		<DepositPrimary></DepositPrimary>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import DepositPrimary from './components/DepositPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			DepositPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
	}
</script>