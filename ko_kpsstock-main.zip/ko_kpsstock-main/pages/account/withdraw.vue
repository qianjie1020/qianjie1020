<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond>
		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx;" :style="{color:$theme.SECOND}">
			{{$lang.WITHDRAW_TITLE}}
		</view>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<view style="padding:20px;margin-top: 10px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper" style="margin-bottom: 30px;padding-left: 30px;">
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.TIP_WITHDRAW_PWD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
		</view>


		<view style="margin:10px; padding: 20px;" :style="{color:$theme.LOG_LABEL}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?$theme.PRIMARY :$theme.LOG_LABEL}">
					{{item}}
				</view>
			</block>
		</view>

		<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
			<view class="common_btn" style="margin:60rpx auto;width: 80%;" @click="handleWithdraw()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			CardItemThird,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TIP_AMOUNT_WITHDRAW,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				});
				if (!result) return false;
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_TRADE_LOG + `?code=2`,
					})
				}, 1000)

			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.get(`api/user/info`);
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.money || 0, // 可提
					value2: this.userInfo.freeze || 0, // 冻结
					value3: this.userInfo.totalZichan || 0, // 总资产
				};
			},
		},
	}
</script>