<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}" style="font-size: 28rpx;">{{item.goods.code}}</view>
						<view style="color:#121212;">
							{{item.message}}
						</view>
					</view>
					<view :style="{color:$theme.PRIMARY}" style="font-size: 36rpx;">{{item.goods.name}}</view>


					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_LOG_PRICE}}</view>
						<view style="color:#EBBD33;font-size: 32rpx;">
							{{$util.formatNumber(item.price)}}{{` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_LOG_SUCCESS}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.success)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_ISSUANCE_LOG_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.total)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_ISSUANCE_LOG_SN}}</view>
						<view>{{item.order_sn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_ISSUANCE_LOG_DATE}}</view>
						<view>{{item.updated_at}}</view>
					</view>

				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIssuanceLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/goodsscramble/userApplyLog`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				}
			},
		},
	}
</script>