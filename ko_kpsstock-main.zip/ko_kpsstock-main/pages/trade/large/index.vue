<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond>
		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx;" :style="{color:$theme.SECOND}">
			{{$lang.TRADE_LARGE_TITLE}}
		</view>

		<TabsPrimary :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<TradeLargeList></TradeLargeList>
		</template>
		<template v-else>
			<TradeLargeRecord></TradeLargeRecord>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeLargeList from './components/TradeLargeList.vue';
	import TradeLargeRecord from './components/TradeLargeRecord.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeLargeList,
			TradeLargeRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

		},
	}
</script>