<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding: 10px;">
				<block v-for="(item,index) in list" :key="index">
					<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 28rpx;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;">{{item.goods.name}}</view>
						</view>

						<view
							style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
							<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
								<view :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_LARGE_LOG_PRICE}}
								</view>
								<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
								</view>
							</view>
							<view style="flex:1 0 10%;"></view>
							<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
								<view :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_LARGE_LOG_NUM}}
								</view>
								<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
									{{item.num}}
								</view>
							</view>
						</view>

						<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
							<view style="flex: 1 0 45%;border-bottom: 1px solid #F3F3F3;">
								<view :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_LARGE_LOG_LEVER}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
									{{item.double}}
								</view>
							</view>
							<view style="flex:1 0 10%;"></view>
							<view style="flex: 1 0 45%;border-bottom: 1px solid #F3F3F3;">
								<view :style="{color:$theme.LOG_LABEL}">
									{{$lang.TRADE_LARGE_LOG_AMOUNT}}
								</view>
								<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
									{{$util.formatMoney(item.amount)+` ${$lang.CURRENCY_UNIT}`}}
								</view>
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;"
							:style="{color:$theme.LOG_LABEL}">
							<view>{{$lang.TRADE_LARGE_LOG_CREATE_TIME}}</view>
							<text>{{item.created_at}}</text>
						</view>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeRecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
		},
	}
</script>