<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #FFFFFF; padding:10px 16px;border-radius: 8rpx;line-height: 1.8;margin:0 20px 20px 20px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_WITHDRAW_AMOUNT}}
					</view>
					<view :style="{color:$theme.PRIMARY}" style="flex:40%;font-size: 18px;">
						{{$util.formatMoney(item.money)}}
					</view>
					<view style="margin-left: auto;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_ORDER_SN}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DW_DESC}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.reason}}
					</view>
				</view>

				<template v-if="item.status==0">
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<!-- <view :style="item.style"> {{item.text}} </view> -->
						<view style="color:#FC4C76;margin-left: auto;padding:6rpx 16rpx;background-color: #FC4C7611;"
							@click="handleCancel(item.id)">
							{{$lang.BTN_CANCEL}}
							<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
						</view>
					</view>
				</template>
				<template v-else-if="item.status==2">
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<!-- <view :style="item.style"> {{item.text}} </view> -->
						<view style="color:#2D54AB;margin-left: auto;padding:6rpx 16rpx;background-color: #2D54AB11;"
							@click="handleService()">
							{{$lang.BTN_SEND_SERVICE}}
							<!-- <view class="arrow rotate_45" style="border-color: #FC4C76;"
								:style="$theme.setImageSize(12)"></view> -->
						</view>
					</view>
				</template>
				<template v-else>
					<template v-if="item.text">
						<view :style="item.style"> {{item.text}} </view>
					</template>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},

			// 取消提现
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},

			async cancelWithdraw(id) {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'none',
				});
				const result = await this.$http.post(`api/app/qx`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.get(`api/user/withdraw`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map(item => {
					return {
						...item,
						// ...this.$theme.setStatusPrimary(item.status),
						// style: this.$theme.setStatusPrimary(item.status),
					}
				})
				console.log(this.list);
			},
		}
	}
</script>

<style>

</style>