export default {
	LAUNCH_TITLE: 'Online trading platform',
	LAUNCH_PROGRESS_TITLE: 'Loading...',
	TRANSLATE_TITLE: 'Please select language',
	WELCOME: `Welcome`,
	HELLO: '',

	// Check Network
	TIP_NETWORK_TYPE_NONE: 'There is no network or the network status is poor.',

	// API TIP
	API_TOKEN_EXPIRES: 'Login status has expired, please log in again',
	API_HTTP_ERROR: 'Request abnormality, please check your network',
	REQUEST_DATA: 'Request Data',
	API_EMPTY_DATA: 'Empty Data',
	API_EMPTY_CONTENT: 'Empty Content',
	API_SEND_CODE: 'Sending verification code',
	API_SEND_CODE_SUCCESS: 'Verification code sent successfully',
	API_SIGN_IN_NOW: 'Logging in',
	API_SIGN_UP_NOW: 'Registering',
	API_DATA_SUBMIT: 'Submitting',
	API_POST_SUCCESS: 'Success',
	API_GET_ACCOUNT_INFO: 'Get account information',
	API_STATUS_UPLOAD: 'Uploading...',

	// common text 
	COMMON_CANCEL: 'Cancel',
	COMMON_CONFIRM: 'Confirm',
	COMMON_NEXT_STEP: 'Next',
	// 输入值的小数位置最大不可超过设置值
	COMMON_TIP_ENTER_POINT_PREFIX: `Up to `,
	COMMON_TIP_ENTER_POINT_SUFFIX: ` decimal places`,
	COMMON_TOP_ENTER_NUMBER: 'Please enter a valid value',
	COMMON_COPY: 'Copy',
	COMMON_COPY_SUCCESS: 'Copy Success',
	COMMON_MIN_LENGTH: 'Minimum 8 Characters',
	COMMON_MORE: 'More',
	COMMON_BUY: 'Buy',
	COMMON_SELL: 'Sell',


	TABBAR_HOME: `Home`,
	TABBAR_MARKET: 'Market',
	TABBAR_COIN: 'Coin', // coin trade
	TABBAR_CONTRACT: 'Contract', // contract trade
	TABBAR_ACCOUNT: 'Account',

	// access
	SIGN_IN_TITLE: "Sign In",
	SIGN_UP_TITLE: "Create Account",
	BTN_SIGN_IN: 'Sign In',
	BTN_SIGN_UP: 'Create Account',
	BTN_SIMGN_OUT: "Sign Out",
	GO_TO_SIGN_IN: 'Go To The Sign In',
	ACCOUNT_NAME: 'Account',
	ACCOUNT_EMAIL: 'Email',
	ACCOUNT_PASSWORD: 'Password',
	VERIFY_ACCOUNT_PASSWORD: 'Verify Password',
	INVITATION_CODE: 'Invitation Code',
	TIP_REMEMBER_PWD: 'Remember Password',
	TIP_AGREE: 'I agree to',
	TIP_PRVITE_PACT: 'Bitwin Terms of service and privacy policy',
	TIP_VERIFY_CODE: 'Verify COde',
	TIP_ENTER_EMAIL: 'Enter Your Email Account',
	TIP_ENTER_EMAIL_CODE: 'Enter Your Email Code',
	TIP_ENTER_ACCOUNT_NAME: 'Enter Your Account',
	TIP_ENTER_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_VERIFY_ACCOUNT_PASSWORD: 'Enter Your Password',
	TIP_ENTER_INVITATION_CODE: 'Enter Your Invitation Code',
	TIP_PWD_NOEQUAL: 'The password entered twice is inconsistent',
	TIP_CHECK_AGREE: 'Please checked agree',
	TIP_SUCCESS_SIGNIN: 'Sign In Suceesfully',
	TIP_SUCCESS_REGISTER: 'Registration Suceesfully, Please Sign In',
	TIP_SIGN_OUT_SUCCESS: 'Sign Out Suceesfully',


	PRVITE_PACT_TITLE: 'Privte And Pact',
	ABOUT_US_TITLE: 'About US',

	// card label
	CARD_ASSETS_TOTAL: 'Total',
	CARD_ASSETS_AVAIL: 'Avail',
	CARD_ASSETS_FREEZE: 'Freeze',
	// card btn text
	CARD_BTN_TREAD_LOG: 'Record',


	// search
	SEARCH_TITLE: 'Search',
	TIP_SEARCH: 'Enter Coin',
	SEARCH_HISTORY: 'History',
	SEARCH_CLEAR: 'Clear',
	LOADING_SEATCH: 'Searching...',
	SEATCH_RESULT_COUNT: 'Result Count',
	SEATCH_HOT_PICKS: 'Hot Picks',
	
	
	
	// 期权
	Qiquan_name:'Options',
	Qiquan_price:'Please enter amount',
	Qiquan_zhang:'Buy up',
	Qiquan_die:'Buy dip',
	Qiquan_time:'Select expiration time',
	Qiquan_profit:'Profit',
	Qiquan_result:'Trading Results',
	Qiquan_progress:'Trading in progress...',
	Qiquan_name_coin:'Name',
	Qiquan_type:'Type',
	Qiquan_BUY_PRICE:'Buy Price',
	Qiquan_now_PRICE:'Now Price',
	Qiquan_ordersn:'Order sn',
	Qiquan_Amount:'Transaction Amount',
	Qiquan_Amount1:'Amount',
	
	Qiquan_Expected:'Expected profit and loss',
	Qiquan_pl:'Profit and Loss',
	Qiquan_pl_Money:'Profit and Loss Money',
	Qiquan_buytime:'Buy Time',
	Qiquan_ying:'Profit',
	Qiquan_shu:'loss',
	Qiquan_success:'Successful transaction',
	Qiquan_endprice:'End Amount',
	
	
	
	
	// page/market/index
	MARKET_INDEX_TAB_TRACK: 'Track', // 关注
	MARKET_INDEX_TAB_STOCK: 'Market', // 股票市场
	MARKET_INDEX_TAB_HOP: 'Hot', // 热门股票
	MARKET_INDEX_TAB_KPI: 'Index', // 市场指标
	MARKET_INDEX_TAB_RISE: 'Rise', // 
	MARKET_INDEX_TAB_FALL: 'Fall', // 
	MARKET_INDEX_TAB_COIN: 'Coin', // Coin
	// 去市场看看
	MARKET_INDEX_TIP_GO_COIN: 'Go Coin',


	// 个人中心
	ACCOUNT_CENTER_TITLE: 'Account',


	COIN_PRICE_TYPE_MARKET: 'Market',
	COIN_PRICE_TYPE_LIMIT: 'Limit',

	// Coin overview
	COIN_VIEW_TAB_MINUTE: 'Minute',
	COIN_VIEW_TAB_DAILY: 'Daily',
	COIN_VIEW_TAB_MONTHLY: 'Monthly',
	COIN_VIEW_QUANTITY: 'Quantity',
	COIN_VIEW_AVAILABLE_AMOUNT: 'Available Amount',
	COIN_VIEW_PAYMENT_AMOUNT: 'Payment Amount',
	COIN_VIEW_UNIT: 'Unit',
	COIN_VIEW_ENTER_QUANTITY: 'Please Enter Quantity',
	COIN_VIEW_BTN_BUY: 'Buy',
	COIN_VIEW_BTN_SELL: 'Sell',
	COIN_VIEW_OPEN: 'Open',
	COIN_VIEW_CLOSE: 'Close',
	COIN_VIEW_HIGH: 'High',
	COIN_VIEW_LOW: 'Low',
	COIN_VIEW_AMOUNT: 'Trade Amount',

	COIN_VIEW_TAB_DEPTH: 'Depth',
	COIN_VIEW_TAB_TRADE: 'Latest Trade',

	COIN_VIEW_TRADE_TITLE_DATE: 'Date Time',
	COIN_VIEW_TRADE_TITLE_PRICE: 'Price',
	COIN_VIEW_TRADE_TITLE_AMOUNT: 'Quantity',

	COIN_VIEW_DEPTH_TITLE_PRICE: 'Price',
	COIN_VIEW_DEPTH_TITLE_BUY_QTY: 'Buy QTY',
	COIN_VIEW_DEPTH_TITLE_SELL_QTY: 'Sell QTY',

	COIN_BUY_TITLE_PRICE: 'Price',
	COIN_BUY_TITLE_QTY: 'Quantity',

	COIN_BUY_BALANCE: 'Balance',
	COIN_BUY_MAX_QTY: 'Max QTY',
	COIN_BUY_TOTAL_AMOUNT: 'Total',
	COIN_BUY_TIP_ENTER_QTY: 'Enter Quantity',
	COIN_BUY_TIP_ENTER_PRICE: 'Enter Amount',
	COIN_BUY_TIP_ENTER_POINT: 'Up to 4 decimal places',

	COIN_MODAL_COMFIRM: 'Confirm',
	COIN_MODAL_CANCEL: 'Cancel',

	COIN_CUR_ORDER: 'Current Orders',
	COIN_TRADE_RECORD: 'Trade Record',

	COIN_RECORD_TITLE: 'Record',
	COIN_RECORD_CURRENT: 'Current',
	COIN_RECORD_HISTORY: 'History',
	COIN_RECORD_SUCCESS: 'Success',

	COIN_RECORD_TIP_CUR_COIN: 'Only show the current coin',

	COIN_CURRENT_PRICE: 'Price',
	COIN_CURRENT_QTY: 'Quantity',
	COIN_CURRENT_TOTAL: 'Total',
	COIN_CURRENT_BTN_CANCEL: 'Cancel',
	COIN_HISTORY_TRADE_FEE: 'Fee',
	COIN_HISTORY_TRADE_PRICE: 'Trade Price',
	COIN_HISTORY_TRADE_QTY: 'Trade Volume',


	COIN_HISTORY_TIP_CANCEL: 'Cancel',
	COIN_HISTORY_TIP_TRADE: 'Trade',

	// Contract 
	CONTRACT_COUNTDOWN:'Countdown',
	CONTRACT_FEE_RATE:'Fee Rate', // 资金费率
	CONTRACT_DETAIL_BNT_BUY: 'Buy(Long)',
	CONTRACT_DETAIL_BTN_SELL: 'Sell(Short)',
	CONTRACT_PROFIT: 'Profit Amount',
	CONTRACT_LOSS: 'Loss Amount',
	CONTRACT_PROFIT_LOSS_SET: 'Take Profit And Stop Loss(Optional)',
	CONTRACT_LEVER: `Lever`,
	CONTRACT_FEE: 'Fee',
	CONTRACT_DESC_MODAL_TITLE: 'Contract Desc',
	CONTRACT_DESC_BTN: 'OK',
	CONTRACT_DESC_CONTENT: [
		`Contract Deposit: (Purchase Number*Nominal Value)/Multiple, nominal value 1000.`,
		`Number of vacancies: Balance sheet numbers, margins, margin fees.`,
		`Handling Fee: Margin * Currency Handling Rate (0.05%)*Multiple.`,
		`User Rights: User Balance + Total Margin + Position Gain/Loss.`,
		`Risk Ratio: User Privilege/Total Margin 100, generally less than 20% for liquidation.`
	],


	CONTRACT_RECORD_CURRENT: 'Current',
	CONTRACT_RECORD_HOLD: 'Holding',
	CONTRACT_RECORD_HISTORY: 'History',

	CONTRACT_RECORD_TIP_CUR_CONTRACT: 'Only show current contract',

	CONTRACT_HOLD_QUICK_CLOSE: 'All Close',

	CONTRACT_HOLD_BTN_PROFIT_LOSS: 'Take Profit And Stop Loss',
	CONTRACT_HOLD_BTN_CLOSE: 'Close',

	CONTRACT_HOLD_BUY_PRICE: 'Price', // 单价	
	CONTRACT_HOLD_BUY_QTY: 'Buy Quantity', // 购买数量
	CONTRACT_HOLD_BUY_TOTAL: 'Buy Total', // 购买总价

	CONTRACT_HOLD_CURRENT_PRICE: 'Current Price',
	CONTRACT_HOLD_BUY_FEE: 'Fee', // 手续费
	CONTRACT_HOLD_BUY_PL: `Profit or Loss`,

	CONTRACT_HOLD_TAKE_PROFIT: 'Take Profit',
	CONTRACT_HOLD_STOP_LOSS: 'Stop Loss',
	CONTRACT_HOLD_FLOAT_PL: `Float P & L`,

	CONTRACT_PROFIT_LOSS_MODAL_TITLE: 'Take Profit And Stop Loss',

	CONTRACT_TAKE_PROFIT_AMOUNT: 'Take Profit Amount',
	CONTRACT_STOP_LOSS_AMOUNT: 'Stop Loss Amount',
	CONTRACT_CLOSE_QTY: 'Enter Quantity',
	CONTRACT_ESTIMATED_PROFIT: 'Estimated Profit',
	CONTRACT_ESTIMATED_LOSS: 'Estimated Loss',
	CONTRACT_TIP_ENTER_PROFIT_BUY: 'Profit must be greater than price',
	CONTRACT_TIP_ENTER_PROFIT_SELL: 'Profit must be less than price',
	CONTRACT_TIP_ENTER_LOSS_BUY: 'Loss must be less than price',
	CONTRACT_TIP_ENTER_LOSS_SELL: 'Loss must be greater than price',

	// Notify
	NOTIFY_TITLE: 'Announcement',


	// Profile
	PROFILE_AUTH_VERIFIED: 'Verified',
	PROFILE_AUTH_UNVERIFIED: 'Unverified',
	PROFILE_SETTING_TITLE: 'Setting',
	PROFILE_SERVICE_TITLE: 'Service',
	PROFILE_ADDRESS: 'Withdraw Address', // 提现地址
	PROFILE_BANK: 'Bank Account',
	PROFILE_DEFAULT_COIN: 'Default Coin',
	PROFILE_LANGUAGE: 'Language',
	PROFILE_SIGN_IN_PASSWORD: 'Sign In Password',
	PROFILE_PAY_PASSWORD: 'Pay Password',

	PROFILE_QA: `Q & A`,
	PROFILE_PACT: 'Privte And Pact',
	PROFILE_SHARE: 'Share',
	PROFILE_SERVICE: 'Support',
	PROFILE_ABOUT: 'About Us',

	SHARE_LINK: 'Share Link',
	SHARE_COPYLINK:'Copy Share Link',

	// account assets and contract
	ACCOUNT_TAB_ASSETS_TITLE: 'Assets',
	ACCOUNT_TAB_CONTRACT_TITLE: 'Contract',
	ACCOUNT_HIDE_ZERO_DATA: 'Hide Balance 0 Data',

	ASSETS_LIST_BALANCE: 'Balance',
	ASSETS_LIST_USING: 'Using',
	ASSETS_LIST_FREEZE: 'Freeze',

	ASSETS_RECORD_TAB_HOLD: 'Hold',
	ASSETS_RECORD_TAB_SELL: 'Sell',

	ASSETS_RECORD_HOLD_STATUS: 'Hold',

	ASSETS_CONTRACT_RECORD: 'Contract Record',


	// Deposit
	DEPOSIT_TITLE: 'Deposit',
	DEPOSIT_RECORD_TITLE: 'Deposit Record',
	DEPOSIT_ADDRESS: 'Address',
	DEPOSIT_AMOUNT: 'Amount',
	DEPOSIT_ENTER_AMOUNT: 'Enter Amount',
	DEPOSTI_UPLOAD: 'Upload',
	DEPOSIT_RECORD_AMOUNT: 'Trade Amount',
	DEPOSIT_RECORD_SN: 'Order SN',
	DEPOSIT_RECORD_CT: 'Date Time',
	DEPOSIT_RECORD_DESC: 'Desc',
	DEPOSIT_COIN: 'Coin',

	// withdraw
	WITHDRAW_TITLE: 'Withdraw',
	WITHDRAW_ADDRESS: 'Address',
	WITHDRAW_AMOUNT: 'Amount',
	WITHDRAW_ENTER_AMOUNT: 'Enter Amount',
	WITHDRAW_PASSWORD: 'Password',
	WITHDRAW_ENTER_PASSWORD: 'Enter Password',
	WITHDRAW_MIN_AMOUNT: 'Minimum Amount',
	WITHDRAW_AVAILABLE_AMOUNT: 'Available Amount',
	WITHDRAW_FEE_AMOUNT: 'Trading Fee',
	WITHDRAW_RECORD_TITLE: 'Withdraw Record',
	WITHDRAW_RECORD_AMOUNT: 'Trade Amount',
	WITHDRAW_RECORD_SN: 'Order SN',
	WITHDRAW_RECORD_CT: 'Date Time',
	WITHDRAW_RECORD_DESC: 'Trade Desc',
	WITHDRAW_RECORD_FEE: 'Fee',
	WITHDRAW_RECORD_ADDRESS: 'Address',
	WITHDRAW_RECORD_COIN: 'Coin',
	WITHDRAW_COIN: 'Coin',
	WITHDRAW_BANK_CODE: 'Bank Account',
	WITHDRAW_TIP_ADD_ADDRESS: 'Go Add Address',
	WITHDRAW_TIP_ENTER_ADDRESS: 'Enter Address',
	WITHDRAW_TIP_CHOOSE: 'Choose Coin',
	WITHDRAW_MODAL_TITLE: 'Want to cancel a withdrawal?',

	// 劃轉
	TRANSFER_TITLE: 'Transfer',
	TRANSFER_IN_ACCOUNT: 'Transfer In Account',
	TRANSFER_OUT_ACCOUNT: 'Transfer Out Account',
	TRANSFER_TIP: 'The transfer-in account cannot be the same as the transfer-out account',
	TRANSFER_AMOUNT: 'Transfer Amount',
	TRANSFER_BALANCE: 'Balance',
	TRANSFER_ASSETS_TITLE: 'Assets',
	TRANSFER_CONTRACT_TITLE: 'Contract',
	TRANSFER_Options_TITLE: 'Options',
	
	
	TRANSFER_RECORD_TITLE: 'Transfer Record',
	TRANSFER_RECORD_DESC: 'Desc',
	TRASNFER_RECORD_REVIEW: 'Under review', // 审核中
	TRANSFER_RECORD_PASS: 'Passed', // 已通过
	TRANSFER_RECORD_REJECT: 'Rejected', // 已拒绝

	// 变更登入密码、变更支付密码
	PASSWORD_OLD: 'Old Password',
	PASSWORD_NEW: 'New Password',
	PASSWORD_VERIFY: 'Verify New Password',
	PASSWORD_ENTER_OLD: 'Enter Old Password',
	PASSWORD_ENTER_NEW: 'Enter New Password',
	PASSWORD_ENTER_VERIFY: 'Verify New Password',
	PASSWORD_TIP_VERIFY_FAIL: 'New password is different',

	// Address
	ADDRESS_INDEX_TITLE: 'Withdraw Address',
	ADDRESS_ADD_TITLE: 'Add Withdraw Address',
	ADDRESS_TIP_ENTER_ADDRESS: 'Enter Address',
	ADDRESS_CHOOSE_COIN: 'Choose Coin',
	ADDRESS_WALLET_ADDRESS: 'Wallet Address',
	ADDRESS_WALLET_IMAGE: 'Upload Image',

	// TRADE_IPO
	TRADE_IPO_TITLE: 'ICO',
	TRADE_IPO_RECORD_TITLE: 'ICO Record',
	TRADE_IPO_LIST_PRICE: 'Price',
	TRADE_IPO_LIST_TOTAL: 'Total',
	TRADE_IPO_LIST_RC: 'Reserve Capacity',
	TRADE_IPO_LIST_LOCK: 'Lock',
	TRADE_IPO_LIST_DAY: 'Day',
	TRADE_IPO_DETAIL_TITLE: 'Detail',
	TRADE_IPO_PRICE: 'Price',
	TRADE_IPO_CT: 'Date Time',
	TRADE_IPO_SN: 'Order SN',
	TRADE_IPO_RECORD_DESC: 'Desc',
	TRADE_IPO_DETAIL_URL: 'White Paper',
	TRADE_IPO_DETAIL_WEBSITE: 'Website',
	TRADE_IPO_DETAIL_COIN_DESC: 'Coin Desc',
	TRADE_IPO_RECORD_APPLY_AMOUNT: 'Apply Amount',
	TRADE_IPO_RECORD_APPLY: 'Apply',
	TRADE_IPO_RECORD_SUCCESS: 'Success',
	// IPO 交易 申购成功记录
	TRADE_IPO_SUCCESS_SUB: 'Subscription',
	TRADE_IPO_SUCCESS_PRICE: 'Price',
	TRADE_IPO_SUCCESS_QUANTITY: 'Quantity',
	TRADE_IPO_SUCCESS_AMOUNT: 'Success Amount',
	TRADE_IPO_SUCCESS_FREEZE: 'Freeze',
	TRADE_IPO_SUCCESS_CT: 'Date Time',
	TRADE_IPO_SUCCESS_ORDER_SN: 'Order SN',
	TRADE_IPO_SUCCESS_UNPAY_AMOUNT: 'Unpay Amount',

	// Capital flow
	FLOW_TITLE: 'Capital Flow',
	FLOW_AMOUNT_AFTER: 'Amount After',
	FLOW_AMOUNT_BEFORE: 'Amount Before',
	FLOW_AMOUNT: 'Amount',
	FLOW_CT: 'Date Time',
	FLOW_DESC: 'Desc',

	// AUTH
	AUTH_TITLE: 'Auth',
	AUTH_REAL_NAME: 'Real Name',
	AUTH_CARD_ID: 'Card ID',
	AUTH_CARD_F: 'Card Front Image',
	AUTH_CARD_B: 'Card Back Image',

	// 借贷 Borrow
	BORROW_TITLE: 'Credit',
	BORROW_TIP_UPLOAD: 'Please upload your credentials',
	BORROW_TIP_UPLOAD_TIP: 'Upload your credit score',
	BORROW_BTN_UPLOAD: 'Upload',
	BORROW_BTN_NOW: 'Borrow Now',
	BORROW_TIP_SUCCESS: 'Congratulations, the review was successful!',
	BORROW_RECORD: 'Apply Record',
	BORROW_RECORD_AMOUNT: 'Amount',
	BORROW_RECORD_LOANS: 'Loans',
	BORROW_RECORD_STATUS_APPLY: 'Apply',
	BORROW_RECORD_STATUS_PASS: 'Passed',
	BORROW_RECORD_STATUS_FAIL: 'Fail',
	BORROW_LINK_SERVICE: 'Contact Customer Service',
	BORROW_TIP_YOUR_SCORE: 'Your credit score',
	BORROW_REUPLOAD: 'Click Reupload',
	BORROW_TIP_UPLOAD_FAIL: 'Audit failure',
	BORROW_ENTER_AMOUNT: 'Please Enter Amount',
	BORROW_TIP_REVIEW: 'Under Review',
	
}