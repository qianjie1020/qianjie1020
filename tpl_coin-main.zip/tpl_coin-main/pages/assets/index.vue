<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderPrimary isSearch :title="$lang.ACCOUNT_CENTER_TITLE" :color="$theme.SECOND"></HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_4" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemSecond :info="cardData" :labels="cardLabels"></CardItemSecond>
			</view>
		</view>

		<view class="common_block"
			style="display: flex;align-items: center;justify-content: space-between;border-radius: 24rpx;padding:20rpx 60rpx;">
			<view @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top1.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top2.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<view @click="linkTransfer()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.TRANSFER_TITLE}}
				</view>
			</view>

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.PROFILE_SERVICE}}
				</view>
			</view>
		</view>

		<!-- 資金賬戶 合約賬戶 -->
		<view style="display: flex;align-items: center;margin:0 40rpx;">
			<block v-for="(item,index) in setTabs" :key="index">
				<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<AssetsList :list="list" @action="handleType"></AssetsList>
		</template>
		<template v-else>
			<ContractList :list="list" :info="contractData"></ContractList>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import CardItemSecond from '@/components/card/CardItemSecond.vue';
	import AssetsList from './components/AssetsList.vue';
	import ContractList from './components/ContractList.vue';
	export default {
		components: {
			HeaderPrimary,
			CardItemSecond,
			AssetsList,
			ContractList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
				curTab: 0, // assets or contract
				list: [], // 列表数据
				isHideZero: false, // 是否隐藏余额为0的数据
				contractData: {}, // 合约资产
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTabs() {
				return [
					this.$lang.ACCOUNT_TAB_ASSETS_TITLE,
					this.$lang.ACCOUNT_TAB_CONTRACT_TITLE,
					this.$lang.TRANSFER_Options_TITLE
				]
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
			if (this.curTab == 0) this.getAssetsList();
			if (this.curTab == 1) {
				this.getAccountContract();
				this.getContractList();
			}
			
			if (this.curTab == 2) {
				this.getAccountContract();
				this.getContractList();
			}
			
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo();
			if (this.curTab == 0) this.getAssetsList();
			if (this.curTab == 1) {
				this.getAccountContract();
				this.getContractList();
			}
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.list = [];
				this.curTab = val;
				if (this.curTab == 0) this.getAssetsList();
				if (this.curTab == 1||this.curTab == 2) {
					this.getAccountContract();
					this.getContractList();
				}
			},
			// 设置样式
			setStyle(val, w = 120) {
				// const temp = this.curTab == 0 ? this.$theme.RISE : this.$theme.FALL;
				return {
					minWidth: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#F6F8FC',
					color: val ? '#FFFFFF' : '#666666',
					borderRadius: `44rpx`,
				}
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.WITHDRAW_INDEX
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.DEPOSIT_INDEX
				})
			},
			linkTransfer() {
				uni.navigateTo({
					url: this.$paths.TRANSFER_INDEX
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			handleType(val) {
				this.isHideZero = val;
				this.getAssetsList();
			},

			async getAssetsList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/assets`, {
					type: 2, // 2:assets 1:contract
					hide_money: this.isHideZero ? 1 : 0,
				});
				if (!result) return false;
				console.log(`assets:`, result);
				this.list = result;
			},

			async getContractList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/finance`, {
					type: this.curTab+1,
					name: 'USDT',
				});
				if (!result) return false;
				console.log(`contract:`, result);
				this.list = result;
			},

			async getAccountContract() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.post(`api/user/assets`, {
					type: this.curTab==1?1:3, // 合約賬戶
					name: 'USDT',
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.contractData = {
					value1: result[0].money,
					value2: result[0].zong_money,
					value3: result[0].freeze,
				}
			},
				
			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.post(`api/user/account`, {
					type: 1
				});
				if (!result) return false;
				this.cardData = {
					value1: result.money || 0,
					value2: result.zong_money || 0,
					value3: result.freeze || 0,
				};
			},
		},
	}
</script>