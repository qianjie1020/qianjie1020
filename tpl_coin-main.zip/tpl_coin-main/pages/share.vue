<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<HeaderSecond :title="$lang.PROFILE_SHARE" :color="$theme.SECOND"></HeaderSecond>

		<view style="padding:40rpx;">
			<view style="font-size: 32rpx;font-weight: 700; line-height: 2.4;margin-top: 20rpx;"
				:style="{color:$theme.SECOND}">
				{{$lang.SHARE_LINK}}
			</view>

			<view style="padding:80rpx 40rpx;border: 1px solid #E8EAF3;border-radius: 16rpx;">
				<template v-if="info">
					<view style="display: flex;align-items: center;">
						<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
						<view style="padding-left: 40rpx;">
							<view style="font-size: 36rpx;" :style="{color:$theme.SECOND}">{{info.real_name}}</view>
							<view :style="{color:$theme.LOG_LABEL}">{{info.p_mobile}}</view>
						</view>
						<!-- <view style="margin-left: auto;">
					<view class="common_tag" :style="setStyle()">{{curAuth}}</view>
				</view> -->
					</view>
				</template>

				<view style="display: flex;align-items: center;margin:10px;padding-bottom: 10px;" @click="handleCopy()">

				</view>
				<view style="display: flex;align-items: center;justify-content: center;">
					<canvas id="qrcode" canvas-id="qrcode" style="width: 500rpx;height: 500rpx;"></canvas>
				</view>

				<view class="common_btn" style="margin:80rpx auto;width: 80%;" @click="handleCopy()">
					{{$lang.SHARE_COPYLINK}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import UQRCode from 'uqrcodejs';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: null,
				borrowInfo: null,
				imgUrl: null, // 二维码转为图片的 base64 
			};
		},

		computed: {
			// 二维码内容
			shareLink() {
				if (this.info) {
					const temp = window.location.origin + `/#`;
					// return temp + this.$paths.ACCOUNT_ACCESS +`?code=${this.info.code}`; 
					return temp
				}
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 成为文件
			// async genCanvasToFile() {
			// 	const result = await uni.canvasToTempFilePath({
			// 		canvasId: 'qrcode',
			// 		fileType: 'png',
			// 		width: 250,
			// 		height: 250,
			// 		// success: res => {
			// 		// 	// console.log(res);
			// 		// },
			// 		// fail: err => {
			// 		// 	console.log(err);
			// 		// }
			// 	});
			// 	console.log(`result:`, result);
			// 	this.imgUrl = result[1].tempFilePath;
			// },

			genQRCode() {
				// 获取uQRCode实例
				let qr = new UQRCode();
				// 设置二维码内容
				qr.data = this.shareLink;
				// 设置二维码大小，必须与canvas设置的宽高一致
				qr.size = 250;
				// 调用制作二维码方法
				qr.make();
				// 获取canvas上下文
				let canvasContext = uni.createCanvasContext('qrcode', this); // 如果是组件，this必须传入
				// 设置uQRCode实例的canvas上下文
				qr.canvasContext = canvasContext;
				// 调用绘制方法将二维码图案绘制到canvas上
				qr.drawCanvas();
				// 通过uni.createCanvasContext方式创建绘制上下文的，对应导出API为uni.canvasToTempFilePath
				// 调用完ctx.draw()方法后不能第一时间导出，否则会异常，需要有一定的延时
				// setTimeout(() => {
				// 	// this.genCanvasToFile();
				// }, 300);
			},


			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				this.genQRCode();
			},

			// 点击复制邀请链接
			async handleCopy() {
				const result = await uni.setClipboardData({
					data: this.shareLink, //要被复制的内容
				});
				console.log(this.shareLink)
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 1000,
						icon: 'success'
					})
				}
			}
		}
	}
</script>


<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}

	.qrcode {
		height: 420rpx;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		align-items: center;
	}

	.qrcode>canvas {
		width: 420rpx;
		height: 420rpx;
	}
</style>