<template>
	<header class="common_header">
		<image src="/static/user.png" mode="aspectFit" :style="$theme.setImageSize(48)" style="padding-right: 30rpx;"
			@tap="linkAccount()">
		</image>
		<view style="font-weight: 500;font-size: 28rpx;" :style="{color:$theme.SECOND}">{{title}} </view>
		<view style="margin-left: auto;">
			<view style="display: flex;align-items: center;">
				<image mode="aspectFit" src="/static/search.png" :style="$theme.setImageSize(40)" @click="linkSearch()">
				</image>
				<image mode="aspectFit" src="/static/notify.png" :style="$theme.setImageSize(40)" @click="linkNotify()"
					style="padding-left: 30rpx;"></image>
			</view>
		</view>

	</header>
</template>

<script>
	export default {
		name: 'HeaderPrimary',
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
		},
		methods: {
			linkAccount() {
				this.$emit(`action`, true);
			},
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},
			// 跳转到通知页面
			linkNotify() {
				uni.navigateTo({
					url: this.$paths.NOTIFIY_INDEX
				})
			},
		}
	}
</script>

<style>
	.common_header {
		padding: 60rpx 40rpx 20rpx 40rpx;

		display: flex;
		align-items: center;
	
	}
</style>