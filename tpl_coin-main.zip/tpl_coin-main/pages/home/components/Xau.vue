<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;" @click="linkInfo(item.code)">
					<template v-if="item.logo">
						<view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
					</template>
					<view style="padding-left: 30rpx;flex:auto">
						<view style="display: flex;align-items: center;">
							<view style="padding-right: 60rpx;font-weight: 700;font-size: 28rpx;"
								:style="{color:$theme.SECOND}">{{item.name}}</view>
							<view style="font-weight: 500;font-size: 32rpx;color: #333333;margin-left: auto;">
								{{item.current_price}}
							</view>
							<view style="margin-left: auto;" :style="$theme.setStockRiseFall(item.rate>0)">
								{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
						<!-- <view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;line-height: 1.6;">
							{{`24H ` +item.vol}}</view> -->
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'Xau',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				gpIndex: 0,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
			};
		},

		created() {
			this.getList();
		},

		deactivated() {
			this.disconnect();

		},
		methods: {
			// 跳转到详情
			linkInfo(code) {
				uni.navigateTo({
					url: this.$paths.COIN_INDEX + `?code=${code}`
				});
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_XAU_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {},
					fail: (res) => {}
				})
				if (this.socket) {
					// 监听WebSocket连接打开事件
					this.socket.onOpen((res) => {
						console.info("监听WebSocket连接打开事件", res)
					});

					// 监听WebSocket错误
					uni.onSocketError((res) => {
						console.info("监听WebSocket错误" + res)
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {
							// this.list[data.market].current_price = data.lastPrice;
							// this.list[data.market].rate = data.rate || 0;
							// this.list[data.market].vol = data.vol || 0;
							// this.xau.current_price = data.last_numeric
							// this.xau.rate = data.pcp
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info`, {
					code: "xau",
					time_index: 1
				});
				console.log(`xau result:`, result);
				if (!result) return false;
				this.list = result;
				this.list.forEach(item => item.logo = window.location.origin + item.logo);

				// this.connect(); // 启动 websocket链接
			}
		}
	}
</script>

<style>
</style>