<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #F1F2F7;">
		<view style="background-image: url(/static/home_top.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;height: 300px;top: 0;"></view>
		
		<HeaderPrimary :title="setToday" @action="handleProfile" style="margin-top: -300px;"> </HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<view style="color:#FFFFFF;font-size: 40rpx;font-weight: 900;line-height: 1.8;">Coin Exchange </view>
				<view style="color:#FFFFFF;font-size: 32rpx;line-height: 1.8;">{{$lang.LAUNCH_TITLE}}</view>
			</view>
		</view>

		<!-- <view>
			<NotifyPrimary ref="notify"></NotifyPrimary>
		</view> -->
		<view class="common_block" style="padding:0;">
			<ButtonGroup @action="handleProfile"></ButtonGroup>
		</view>

		<!-- <view style="margin:0 40rpx;">
			<TitlePrimary :title="$lang.MARKET_NEWS_TITLE">
				<view style="font-size: 13px;margin-left: auto;" @click="linkMarketNews()"
					:style="{color:$theme.SECOND}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view> -->
		
		
		
		
		
		<CoinList ref="coin"></CoinList>

		<!-- account center modal -->
		<template v-if="isShowModal">
			<ProfileModal @action="handleClose"></ProfileModal>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from './components/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import NotifyPrimary from '../notify/components/NotifyPrimary.vue';
	import CoinList from './components/CoinList.vue';
	// import Xau from './components/Xau.vue';
	import ProfileModal from '../profile/components/ProfileModal.vue';
	export default {
		components: {
			HeaderPrimary,
			ButtonGroup,
			NotifyPrimary,
			CoinList,
			ProfileModal,
			// Xau,
		},
		data() {
			return {
				isAnimat: false, // 页面动画	
				// cardInfo: {}, // 资产卡
				isShowModal: false, // 显示账户信息
			}
		},
		computed: {
			// cardLabels() {
			// 	return [this.$lang.CARD_ASSETS_TOTAL,
			// 		this.$lang.CARD_ASSETS_AVAIL,
			// 		this.$lang.CARD_ASSETS_FREEZE
			// 	]
			// },
			// 今日
			setToday() {
				return this.$util.formatToday(new Date());
			}
		},

		onLoad() {
			this.$util.setAppLang();
			this.$util.switchTabBar();
		},
		onShow() {
			// this.getAccountInfo();
			this.isAnimat = true;
			// console.log(this.cardLabels);
			if (this.$refs.coin) this.$refs.coin.getList();
			if (this.$refs.notify) this.$refs.notify.getList();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			// 打开 profile
			handleProfile(val) {
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowModal = true;
			},
			// 
			handleClose() {
				this.isShowModal = false;
				uni.showTabBar(); // 显示tabBar
			},

			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$paths.MARKET_INDEX + `?type=0`,
				})
			},
		},
	}
</script>