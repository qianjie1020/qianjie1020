import en from '@/locale/en.js';
import zh from '@/locale/zh-hans.js';
import ja from '@/locale/ja.js';
import ko from '@/locale/ko.js';

// LANGUAGES

export default {
	en,
	zh,
	ja,
	ko,
};