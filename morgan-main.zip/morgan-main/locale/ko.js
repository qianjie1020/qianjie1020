// 底部导航组
const TABBAR = {
	TABBAR_HOME: " 거래소 ",
	TABBAR_FOLLOW: " 관심 종목 ",
	TABBAR_MARKET: '최신 소식',
	TABBAR_TRADE: '최신소식',
	TABBAR_TRADE_D: '보유현황',
	TABBAR_ACCOUNT: ' 내정보 ',
};

// 账户管理相关 登入、注册
const ACCESS = {
	SIGN_IN: "로그인",
	SIGN_UP: "회원가입",
	SIMGN_OUT: "로그아웃",
	GO_TO_SIGN_IN: '로그인페이지',
	USER_NAME: '전화번호를',
	ENTER_USER_NAME: '아이디',
	PASSWORD: '비밀번호를',
	ENTER_PASSWORD: '비밀번호',
	VERIFY_PASSWORD: '비밀번호 재입력',
	ENTER_VERIFY_PASSWORD: '비밀번호 재입력',
	INVITATION_CODE: '초대 코드 입력',
	ENTER_INVITATION_CODE: '초대 종목코드 입력',
	TIP_PWD_NOEQUAL: '두 개의 비밀번호가 일치하지 않습니다',
	TIP_SUCCESS_SIGNIN: '로그인 완료',
	TIP_SUCCESS_REGISTER: '등록이 완료되었습니다. 로그인하세요.',
	TIP_SIGNIN_ING: '로그인 중',
	TIP_SIGNUP_ING: '등록 중',
	TIP_REMEMBER_PWD: '로그인 상태 유지',
	API_TOKEN_EXPIRES: '로그인 상태가 잘못되었습니다. 다시 로그인해 주세요.',
	TIP_SIGN_OUT_SUCCESS: '로그아웃 완료',
	TIP_AGREE: '동의',
	TIP_PRVITE_PACT: '개인 정보 보호 계약',
	TIP_CHECK_AGREE: '사용자 개인정보 보호 계약에 동의하려면 확인란을 선택하세요.',
};

// 变更登入密码、变更支付密码、变更账户信息
const ACCOUNT = {
	TIP_OLD_PWD: '이전 비밀번호를 입력해주세요',
	TIP_NEW_PWD: '새 비밀번호를 입력 해주세요',
	TIP_NEW_PWD_VERIFY: '새 비밀번호를 다시 입력 해주세요',
	// 个人信息修改页面
	PAGE_TITLE_AVATAR: '설정',
	AVATAR_TIP_NICK_NAME: '닉네임 설정',
	BTN_AVATAR: '신청하기',
};

// 绑定银行卡
const BIND_BANK_CARD = {
	REAL_NAME: '성함',
	TIP_REAL_NAME: '예금주를 입력해주세요',
	BANK_NAME: '개설은행',
	TIP_BANK_NAME: '계좌 개설 은행을 입력하거나 선택하세요',
	BANK_CARD: '계좌번호',
	TIP_BANK_CARD: '계좌번호를 입력해주세요',
	BTN_CHANGE_BANK_CARD: '확인',
	BTN_BANK_SELECTED: '은행 선택',
};

// 提款页面
const WITHDRAW = {
	PAGE_TITLE_WITHDRAW: '출금',
	WITHDRAW_AMOUNT: '출금신청',
	WITHDRAW_TITLE: "자금인출",
	TIP_AMOUNT_AVAIL: '쓸 수 있는',
	WITHDRAW_WITH_AMOUNT: '출금금액',
	TIP_AMOUNT_WITHDRAW: '출금 금액 입력',
	WITHDRAW_PAY_PWD: '비밀번호',
	TIP_WITHDRAW_PWD: '비밀번호 6자리 입력',
	WITHDRAWING_POST_TIP: '처리....',
	BTN_WITHDRAW: '출금신청',
	// 提款说明
	WITHDRAW_TIP_TEXT: [`1. 현재 보유주식 매도전에는 출금이 불가능합니다.`, `2. 출금을 위해서는 실명인증 및 본인 계좌 확인 후 출금 진행이 됩니다.`,
		`3. 출금 거래 가능 시간 : 평일 오전 09시 ~ 오후 15시30분 (*주말, 대체공휴일 출금 불가)`, `4. 각 현금 인출의 최소 금액은 10,000단위 입니다.`,
		`5. 출금 신청 후 영업일 기준 2일 이내 입금됩니다. `, `※ 최대 2 영업일 (48시간) 이내로 입금이 완료됩니다.`
	],
};

// 入金页面
const DEPOSIT = {
	PAGE_TITLE_DEPOSIT: '입금',
	DEPOSIT_TIP_DEPOSIT_AMOUNT: '충전금액을 입력하세요',
	DEPOSIT_TIP_LOW_AMOUNT: '최소충전1000000',
	DEPOSIT_POST_TIP: '처리....',
	DEPOSIT_TIP_TITLE: '친절한 팁',
	DEPOSIT_TIP_TEXT: [`입금 가능시간:평일 9:00-18:00. 공휴일 휴무.`,
		`귀하의 정상적인 입금을 위하여 입금하려는 계좌가 고객센터에서 알려주신 최신 계좌인지 확인하시기 바랍니다.`,
		`매번 입금하실때 고객센터에 계좌 확인하시고 최신계좌가 아닌 다른계좌로 입금하여 발생하시는모든 손실에 대해서는 본인이 책임져야합니다.`
	],
};

// 个人中心页面
const ACCOUNT_CENTER = {
	// 个人中心 认证状态
	ACCOUNT_AUTH_STATUS: ['확인됨[인증되지 않음]', '확인됨[검토중]', '확인됨[감사 실패]'],
	ACCOUNT_CHANGE_PWD: '로그인 비밀번호 변경',
	ACCOUNT_CHANGE_PWDDD: '비밀번호 재설정',
	ACCOUNT_CHANGE_PAY_PWD: '결제비밀번호 변경',
	ACCOUNT_CARD_MANAGEMENT: '연계은행 계좌',
	ACCOUNT_TRADE_LOG: '입출금 내역',
	ACCOUNT_SERVICE: '고객센터',
	ACCOUNT_AMOUNT_TOTAL: '운용 자금',
	ACCOUNT_AMOUNT_AVAILABLE: '총자산',
	ACCOUNT_MORE_FEATURES: '더 많은 기능',
	ACCOUNT_COLD_AMOUNT: 'AI 계정',
	ACCOUNT_REPAY: '반품',
	ACCOUNT_TOTAL_PROFIT: '총이윤'
};

// 实名认证页面
const AUTH = {
	PAGE_TITLE_AUTH: '실명 인증',
	AUTH_TIP_ID_CARD: '올바른 주민등록번호를 입력해주세요',
	AUTH_TIP_CARD_F: '전면을 클릭하여 추가',
	AUTH_TIP_CARD_B: '뒷면을 클릭해서 추가했어요',
	AUTH_ID_CARD: '주민등록번호',
	AUTH_CARD_F: '주민등록증 앞면',
	AUTH_CARD_B: '주민등록증 뒷면',
	AUTH_TIP_TEXT: '※본인이 아닐경우, 이용에 불이익을 받으실 수있습니다.',
};

// 交易记录页面
const TRADE_LOG = {
	TRADE_LOG_BTNS: ['입출금세부내역', '입금 내역', '출금 내역'],
	TRADE_LOG_TIP_MODAL_TITLE: '출금신청을 취소하시겠습니까?',
	TRADE_LOG_WITHDRAW_STATUS: ['심사중', '성공적으로 출금됨', '실패하다', '취소 된'],
	LOG_TRADE_AMOUNT_AFTER: '잔액',
	LOG_TRADE_AMOUNT_BEFORE: '거래전 잔액',
	LOG_TRADE_DW: '금액',
	LOG_TRADE_CREATE_TIME: '날짜 시간',
	LOG_TRADE_DESC: '상세내역',
	LOG_TRADE_ORDER_SN: '주문 번호',
	LOG_TRADE_DW_DESC: '거부 이유',
	LOG_WITHDRAW_AMOUNT: '출금',
	LOG_STATUS: '상태',
};

// 交易页面
const ACCOUNT_TRADE = {
	TRADE_TITLE: '투자 결과',
	TRADE_TABS: ['종목 보유 현황', '매매 내역'],
	TRADE_TOTAL_BUY_AMOUNT: '매입금액',
	TRADE_VALUATION_GAIN_LOSS: '평가수익금',
	TRADE_VALUATION_GAIN_LOSS_AMOUNT: '총 수익',
	TRADE_RATE_RESPONSE: '평가수익률',
	TRADE_TOTAL_GAIN: '총 이윤',
	// 持仓和卖出的记录 表头
	TRADE_LIST_THEAD: ['종목명', '평가수익률', '수량', '평가수익금', '총매수가', '현재가'],
	TRADE_LABEL_LAST_PR: '매수가',
	TRADE_MOADL_TITLE: '주식주문',
	// 订单的label组
	TRADE_MODAL_LABELS: ['종목', '매수시간', '매도시간', '현재손익', '레버리지', '총손익', '매입가', '수량', '수수료', '총 매입가', '종목코드'],
	// 卖出的二次确认
	SELL_TIP: '매도를 확인하시겠습니까?',
	// 记录列表 Label
	TRADE_LABEL_BUY_PRICE: '매수가',
	TRADE_LABEL_SELL_PRICE: '판매가격',
	TRADE_LABEL_LAST_PRICE: '현재가',

};

// AI交易
const TRADE_AI = {
	PAGE_TITLE_TRADE_AI: 'AI 거래',
	TRADE_AI_TABS: ['AI트레이딩', '매매 내역'],
	TRADE_AI_AMOUNT: 'AI투자 금액',
	TRADE_AI_AMOUNT_TOTAL: 'AI 총자산',
	TRADE_AI_TRANSFER: ['신청', '출금'],
	TRADE_AI_PROFIT: 'AI 수익',
	TRADE_AI_LOG: ['보류 중', '통과', '기각'],
	TRADE_AI_CYCLE_TITLE: '기간을 선택하세요',
	TRADE_AI_TRADE_VOL: '거래량',
	TRADE_AI_BALANCE: '균형',
	TRADE_AI_TYPE: '거래 유형',
	TRADE_AI_CYCLE_DAY: '주기',
	TRADE_AI_DEPOSIT_BTN: '입금',
	TRADE_AI_ORDER_TABS: ['보유 종목', '거래 내역'],
	TRADE_AI_LIST_THEAD: ['종목명', '평가손익', '수익률', '매입수량', '평가금액', '평균단가', '매도가격'],
}

// 日内交易
const TRADE_DAY = {
	PAGE_TITLE_TRADE_DAY: '당일거래',
	TRADE_DAY_TABS: ['당일거래', '신청상태', '매매 내역'],
	TRADE_DAY_BUY: '신청',
	TRADE_DAY_TIP: '공지사항',
	TRADE_DAY_TIP_TEXT: ['단타급등주란 당일 주식을 매매해서 거래차익을 남기는 매매기법입니다.',
		'매수후 이익이 발생하면 “거래내역”에서 매도를 선택하실수 있습니다.',
		'당일거래 수익 및 기밀유지를 위해 매수기간 동안 종목코드와 세부정보를 제공하지 않습니다.',
	],
	TRADE_DAY_BUY_AMOUNT: '금액',
	TRADE_DAY_SUCCESS_AMOUNT: '승인금액',
	TRADE_DAY_BUY_PRICE: '구매금액',
	TRADE_DAY_ORDER_SN: '주문 번호',
	TRADE_DAY_CREATE_TIME: '날짜 시간',
	TRADE_DAY_ORDER_STATUS: '주문 상태',
	TRADE_DAY_MODAL_CONTENT: '주문 확인 하시겠습니까?',
	TRADE_DAY_TIP_INPUT_AMOUNT: '금액을 입력하세요',
};

// 大宗交易
const TRADE_LARGE = {
	PAGE_TITLE_TRADE_LARGE: '블록딜',
	TRADE_LARGE_TABS: ['종목 목록', '매매 내역', ],
	TRADE_LARGE_TAB1_TITLES: ['구매 내역', '할당 수량'],
	TRADE_LARGE_PRICE: '매입 가격',
	TRADE_LARGE_RATE: '증가율',
	TEADE_LARGE_RATE_AMOUNT: '증가량',
	TRADE_LARGE_MIN_QTY: '최소 구매 수량',
	TRADE_LARGE_MAX_QTY: '최대 구매 수량',
	TRADE_LARGE_MIN_DAY: '최소 보유 일수',
	TRADE_LARGE_ITEM_LABELS: ['가격', '증가율'],
	TRADE_LARGE_ORDER_TITLE: '청약 신청 주문',
	TRADE_LARGE_BUY_AMOUNT: '매입 가격',
	TRADE_LARGE_TIP_BUY_COUNT: '매입 수량을 입력하세요',
	TRADE_LARGE_ORDER_AMOUNT: '매입금액',
	TRADE_LARGE_TIP_BUY_PWD: '거래 비밀번호 6자리 입력해주세요',
	TRADE_LARGE_LOG_FINISH: '매수완료',
	TRADE_LARGE_LOG_PRICE: '매수가격',
	TRADE_LARGE_LOG_NUM: '당첨수량',
	TRADE_LARGE_LOG_AMOUNT: '매수금액',
	TRADE_LARGE_LOG_LEVER: '레버리지',
	TRADE_LARGE_LOG_CREATE_TIME: '매수시간',
	TRADE_LARGE_BUY_TOTAL_AMOUNT: '매입 가격',
};

// IPO 交易
const TRADE_IPO = {
	PAGE_TITLE_TRADE_IPO: 'IPO',
	TRADE_IPO_TABS: ['종목', '청약내역', '청약 성공'],
	TRADE_IPO_MODAL_TITLE: 'IPO 신청',
	TRADE_IPO_MODAL_CONTENT: '청약신청을 원하시면 확인을 클릭하세요',
	TADE_IPO_SUB_PRICE: '구독 금액',
	TRADE_IPO_PE_RATE: '주가수익비율',
	TRADE_IPO_SUB_CT: '구독 시간',
	TRADE_IPO_POST_QTY: '순환',
	TRADE_IPO_RAISE_MONEY: '기금 모금',
	TRADE_IPO_LOG_LABELS: ['공모가', '청약 총금액', '거래 코드', '청약일자','청약 수량'],
	TRADE_IPO_SUCCESS_TITLE: 'IPO 청약 성공기록',
	TRADE_IPO_SUCCESS_APPLY_AMOUNT: '구독 수량',
	TRADE_IPO_SUCCESS_AMOUNT: '당첨 수량',
	TRADE_IPO_SUCCESS_NUM_AMOUNT: '구독 금액',
	TRADE_IPO_SUCCESS_ORDER_SN: '주문 번호',
	TRADE_IPO_SUCCESS_CT: '날짜 시간',
}

// 股权 交易
const TRADE_EQUITY = {
	PAGE_TITLE_TRADE_EQUITY: '기관 배정',
	TRADE_EQUITY_SURPLUS: '남은',
	TRADE_EQUITY_PRICE: '신청가격',
	
	TRADE_EQUITY_QTY: '신청수',
	TRADE_EQUITY_TOTAL: '총 신청 금액',
	TRADE_EQUITY_SUCCESS_QTY: '합격 수량',
	TRADE_EQUITY_SUCCESS_TOTAL: '합격 합계',
	TRADE_EQUITY_SUB_AMOUNT: '구독 금액',
	TRADE_EQUITY_DEF_AMOUNT: '체불금액',
	TRADE_EQUITY_DEF_BTN: '상환',
	TRADE_EQUITY_DEF_AMOUNT_TIP: '미납금액을 입력하세요',
	TRADE_EQUITY_DEF_BTN_ALL: '모두',
};

// EA交易
const TRADE_EA = {
	TRADE_EA_TITLE: 'EA',
	TRADE_AI_TITLE: 'AI 트레이딩',
	TRADE_EA_TABS: ['소개', '시장', '매매 내역'],
	// 是否卖出
	TRADE_EA_MODAL_CONTENT: '정말로 판매하시겠습니까?',
	// 买入弹层
	TRADE_EA_HIGHEST_RETURN: '최고 수익률',
	TRADE_EA_BUY_AMOUNT: '수량을 입력하세요',
	TRADE_EA_CYCLE_TIP: '주기를 선택하세요',
	// order列表
	TRADE_EA_ORDER_AMOUNT: '구매 금액',
	TRADE_EA_ORDER_PERIOD: '기간',
	TRADE_EA_ORDER_CYCLE: '주기',
	TRADE_EA_ORDER_DATE: '시작 시간',
	TRADE_EA_ORDER_END_DATE: '종료 시간',
	TRADE_EA_ORDER_SN: '거래 ID',
	TRADE_EA_ORDER_LEVER: '마진(레버리지)',
	TRADE_EA_ORDER_RATE: '수익률',
};

// 新股配售
const TRADE_ISSUANCE = {
	TRADE_ISSUANCE_TITLE: '발행',
	TRADE_ISSUANCE_TABS: ['상품', '기록'],
	TRADE_ISSUANCE_MODAL_0: '가격',
	TRADE_ISSUANCE_MODAL_1: '발행 가격',
	TRADE_ISSUANCE_MODAL_2: '푸시 금액',
	TRADE_ISSUANCE_MODAL_3: '적용 날짜',
	TRADE_ISSUANCE_MODAL_4: '발표 날짜',
	TRADE_ISSUANCE_MODAL_5: '만료일',
	TRADE_ISSUANCE_MODAL_6: '푸시 날짜',
	TRADE_ISSUANCE_MODAL_NULL_DATE: '예고되지 않음',
	TRADE_ISSUANCE_LOG_PRICE: '가격',
	TRADE_ISSUANCE_LOG_SUCCESS: '구독 수량',
	TRADE_ISSUANCE_LOG_AMOUNT: '구독 금액',
	TRADE_ISSUANCE_LOG_DATE: '구독 날짜',
	TRADE_ISSUANCE_LOG_SN: '주문 SN',
};

// VIP 交易
const TRADE_VIP = {
	TRADE_VIP_TITLE: 'VIP',
	TRADE_VIP_TABS: ['Goods', 'Record'],
}


// 单股详情页面
const STOCK_INFO = {
	PAGE_TITLE_STOCK_OVERVIEW: '주식세부정보',
	// 股票最新数值
	STOCK_INFO_TITLES: ['시가', '고가', '저가', '전날 종가', '거래량', '거래대금'],
	// 股票详情 一级TABS
	STOCK_OVERVIEW_TABS: ['최신 소식', '요약', '이슈'],
	// 股票KLine TABS
	STOCK_OVERVIEW_KLINE_TABS: ['분', '일', '주', '월'],
	// 单股购买页面
	STOCK_BUY_QUANTITY: '수량',
	STOCK_BUY_TIP_QUANTITY: '수량을 입력해주세요',
	STOCK_BUY_AMOUNT: '주문총액',
	STOCK_BUY_FEE: '매수',
	STOCK_BUY_CONFIRM: '매수 확인',
	// 单股概览 概览信息
	STOCK_BASE_INFO: ['기업순위', '평가금액', '주식수', '외국인비중', '산업군', '세부산업군', '52주 최고', '52주 최저'],
	STOCK_KOSDAQ: '코스닥', // '科斯达克', 
	// 概览 
	STOCK_COMPANY: '기업개요',
	STOCK_SALES: '분기매출',
	STOCK_SALES_TABS: ['분기매출', '연간매출'],
	// 销售额三块数据
	STOCK_SALES_TITLE: ['최근 매출액', '최근 영업이익', '최근 순이익'],
	// 销售额折线上方的三个选项
	STOCK_SALES_KLINE_TABS: ['매출액', '영업이익', '순이익'],
	// 投资者交易趋势
	STOCK_TRADE_TREND_TITLE: '투자자별 매매동향',
	STOCK_TRADE_TREND_BUY_AMOUNT: ['순매수량', '누적순매수량'],
	STOCK_TRADE_TREND_INFO_TITLE: ['개인', '기관', '외인'],
	STOCK_TRADE_TREND_RECENT_TITLE: '최근 거래 동향',
	STOCK_TRADE_TREND_RECENT_LABELS: ['날짜', '개인', '기관', '외인'],
	// 饼图的title
	STOCK_TRADE_TREND_PIE_TITLE: '매매동향',
	STOCK_TRADE_SELL_EMPTY_TITLE: '공매도 거래량',
	// 卖空量两组数据的Title
	STOCK_TRADE_SELL_EMPTY_ITEM_TITLES: ['공매도 거래량', '공매도 잔고'],
	STOCK_TRADE_SELL_EMPTY_ITEM_DESC: ['전체 거래량 대비', '시가총액 대비'],
	// 行业内比较
	STOCK_INDUSTRY_TITLE: '업종 내 비교',
	STOCK_INDUSTRY_DESC: '자동차부품',
	STOCK_INDUSTRY_DESC_SUFFIX: '개중',
	STOCK_INDUSTRY_DATA_TITLES: ['현 종목', '업종평균'],
	STOCK_INDUSTRY_DATA_LABELS: ['업종내순위', '순이익증가율', '부채비율', 'PER', 'PBR', 'ROE'],
};

// 市场页面
const MARKET = {
	MARKET_TABS: ['전체요약', '인기종목', '시장지표', '시장이슈'],
	// 市场概况：
	MARKET_OVERVIEW_SELF_TITLE: '시장이슈',
	//国内、国外、虚拟货币
	MARKET_OVERVIEW_SELF_TABS: ["국내", "해외", "가상화폐"],
	MARKET_MORE_HOT_TITLE: '인기종목 더보기',
	MARKET_NEWS_TITLE: '시장이슈',
	MARKET_OVERVIEW_THEAD: ["상승률", "하락률", "신고가", "거래량", '거래대금'],
	// 热门股票：
	MARKET_HOT_TABS: ['상승률', '하락률', '신고가', '거래량 상위/하위', '거래대금 상위/하위', '외국인 순매수', '기관 순매수', '신규상장', '공매도 비중'],
	// 热门股票过滤
	MARKET_HOT_FILTER: ['당일', '1주일', '1개월', '3개월', '6개월'],
	MARKET_HOT_THEAD: ['종목명', '현재가', '등락률', '현재 지수'],
	// 市场指标
	MARKET_INDEX_TABS: ['지수', '환율', '원자재', '가상화폐'],
	MARKET_NEWS_TABS: ['뉴스', '시장', '경제', '산업', '채권', '파생', '기업', '투자'],
	MARKET_NEWS_TIP: '인기종목은 총 100위까지 순위만 제공합니다. ',
};

// 首页中签弹层
const DIALOG_IPO_SUCCESS = {
	DIALOG_IPO_SUCCESS_TIP_TITLE: '축하합니다',
	DIALOG_IPO_SUCCESS_TIP_TEXT: '공모주청약 당첨되었습니다.',
	DIALOG_IPO_SUCCESS_LABEL_QTY: '당첨 수량',
	DIALOG_IPO_SUCCESS_LABEL_TOTAL: '일시금',
}

export default {
	TRANSLATE_TITLE: '당신의 언어를 고르시 오',
	LAUNCH_TITLE: '주식 온라인 거래 플랫폼',
	...TABBAR,
	...ACCESS,
	...ACCOUNT,
	...BIND_BANK_CARD,
	...WITHDRAW,
	...DEPOSIT,
	...ACCOUNT_CENTER,
	...AUTH,
	...TRADE_LOG,
	...ACCOUNT_TRADE,
	...TRADE_AI,
	...TRADE_DAY,
	...TRADE_LARGE,
	...TRADE_IPO,
	...TRADE_EA,
	...TRADE_EQUITY,
	...TRADE_ISSUANCE,
	...TRADE_VIP,
	...STOCK_INFO,
	...MARKET,
	...DIALOG_IPO_SUCCESS,
	LEVER: '레버리지를 선택하세요',
	STOCK_ALL: '인기종목',
	STOCK_FOLLOW: '집중하다',
	// 首页股票列表表头
	STOCK_THEAD: ['주식', '최신 가격', '등락률'],
	PAGE_TITLE_NOTIFICATION: '할인 거래',
	PAGE_TITLE_SEARCH: '검색',
	TIP_SEARCH: '종목코드검색',
	SEARCH_HISTORY: '기록',
	SEARCH_CLEAR: '기록 지우기',
	// 折价交易
	PAGE_TITLE_TRADE_DISCOUNT: 'ETF',
	TIP_POST_SUCCESS: '성공적인 운영',
	ABOUT_US: '회사 소개',
	CURRENCY_UNIT: '원',
	QUANTITY_UNIT: '주',
	UNIT_BILION: '억',
	UNIT_POS: '위',
	UNIT_DAY: '하늘',
	MORE: '기업개요',
	BRIEF: '간략히',
	EMPTY_NOTIFIY: '메시지 없음',
	EMPTY_DATA: '기록 없음',
	BTN_CONFIRM: '확인',
	BTN_CANCEL: '취소',
	BTN_SEND_SERVICE: '서비스센터에 문의하세요',
	BTN_SERVICE: '고객센터',
	BTN_DETAIL: '매수',
	BTN_BUY: '주문',
	BTN_SELL: '매도',
	BTN_DETAIL_NOW: '바로보기',
	STATUS_LOADING: "로딩 중",
	STATUS_SUBMIT: '제출 중',
	STATUS_REQUEST: '데이터 검색',
	STATUS_HTTP_ERROR: '재시도 중',
	STATUS_UPLOAD: '업로드 중',
	SERVICE_MODAL_CONTENT: '원하시는 SNS를 선택하세요',
}