<!-- 新股申购 -->
<template>
	<view :style="$theme.setBGSize('480rpx')" style="min-height: 100vh;">

		<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_IPO" color="#FFFFFF"></HeaderSecond>

		<view style="margin:0 10px;padding:10rpx;background-color: #FFFFFF;">
			<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>
		</view>

		<template v-if="curTab==0">
			<view style="padding: 10px;background-color: #FFFFFF;margin:20rpx;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="margin-bottom: 20rpx;padding: 10px;border-bottom: 1px solid #E5E5E5;">
						<TradeIPOItem :item="item" @action="handleDetail"></TradeIPOItem>
					</view>
				</block>
			</view>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPOLog></TradeIPOLog>
		</template>
		<template v-else>
			<TradeIPOSuccessLog></TradeIPOSuccessLog>
		</template>

		<u-modal :show="show" :title="$lang.TRADE_IPO_MODAL_TITLE" @cancel="cancel" @confirm="confirm()"
			:showCancelButton='true' :content='$lang.TRADE_IPO_MODAL_CONTENT' :cancelText="$lang.BTN_CANCEL"
			:confirmText="$lang.BTN_CONFIRM">
		</u-modal>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeIPOLog from '@/components/trade/TradeIPOLog.vue';
	import TradeIPOItem from '@/components/trade/ipo/TradeIPOItem.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOSuccessLog from '@/components/trade/TradeIPOSuccessLog.vue';

	export default {
		components: {
			HeaderSecond,
			EmptyData,
			TradeIPOLog,
			TradeIPOItem,
			TabsPrimary,
			TradeIPOSuccessLog,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
				list: [],
				curId: '', // 当前选中数据的ID值
				show: false, // 购买前二次确认的弹层
			};
		},
		onLoad(opt) {
			this.curTab = Number(opt.type) || 0;
		},
		onShow() {
			this.getList();
		},

		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) {
					this.getList();
				}
			},

			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.curId = val;
				this.show = true;
			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase()
				this.show = false;
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.curId,
					// price: this.price
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						this.changeTab(1);
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			async getList() {
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: this.curTab + 1, // 传参 1或2
				})
				if (result.code == 0) {
					if (result.data.length > 0) {
						this.list = result.data.map(item => {
							return {
								id: item.id,
								logo: item.goods.logo,
								name: item.goods.name,
								code: item.goods.code,
								price: item.price,
								shengou_date: item.shengou_date,
								fa_amount: item.fa_amount,
								min_num: item.min_num,
								max_num: item.max_num,
							}
						})
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>