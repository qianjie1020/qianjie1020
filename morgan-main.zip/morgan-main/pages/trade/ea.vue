<template>
	<view :style="$theme.setBGSize('480rpx')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.TRADE_EA_TITLE" color="#FFFFFF"></HeaderSecond>

		<view style="margin:0 10px;padding:10rpx;background-color: #FFFFFF;">
			<!-- 韩国似乎没有EA介绍 -->
			<TabsPrimary :tabs="$lang.TRADE_EA_TABS.slice(1,3)" @action="changeTab" :acitve="curTab"></TabsPrimary>
		</view>

		<!-- <template v-if="curTab ==0">
			<EaIntroduce></EaIntroduce>
		</template> -->

		<template v-if="curTab==0">
			<EaMarket></EaMarket>
		</template>
		<template v-else>
			<EaOrder></EaOrder>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import EaIntroduce from '@/components/trade/ea/EaIntroduce.vue';
	import EaMarket from '@/components/trade/ea/EaMarket.vue';
	import EaOrder from '@/components/trade/ea/EaOrder.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			EaIntroduce,
			EaMarket,
			EaOrder,
		},
		data() {
			return {
				curTab: 0, // 默认放在产品列表，即右边
			};
		},
		onLoad(opt) {
			this.curTab = Number(opt.type) || 0;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
		}
	}
</script>

<style>
</style>