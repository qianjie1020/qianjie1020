<!-- 下单 -->
<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderSecond :title="!stockInfo?'': stockInfo.name" color="#FFFFFF"></HeaderSecond>

		<view style="display: flex;align-items: center;justify-content: center;margin: 30rpx 0;">
			<view class="home_card_bg home_card_bg_1" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view class="common_block" style=";margin-top: 20px;padding:20px 10px;border-radius: 0;">
			<template v-if="stockInfo">
				<view style="display: flex;align-items: center;padding-bottom: 30rpx;">
					<view style="width: 90rpx;text-align: center;">
						<template v-if="!stockInfo.logo || stockInfo.logo==''">
							<view :style="$theme.setImageSize(80)"
								style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 8px;font-size: 18px;">
								{{stockInfo.name.slice(0,1)}}
							</view>
						</template>
						<template v-else>
							<image mode="aspectFit" :src="$util.setLogo(stockInfo.logo)"
								:style="$theme.setImageSize(80)" style="border-radius: 8px;"></image>
						</template>
					</view>
					<view style="flex: 0 0 40%;padding-left: 6px;" :style="{color:$theme.TITLE}">
						<view :style="{color:$theme.STOCK_NAME}" style="font-size: 32rpx;">{{stockInfo.name}}</view>
						<view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{stockInfo.code}}</view>
					</view>

					<view style="margin-left: auto;">
						<view :style="{color:$theme.TEXT}" style="font-size: 36rpx;">
							{{$util.formatNumber(stockInfo.current_price)}} {{` ${$lang.CURRENCY_UNIT}`}}
						</view>
						<view :style="$theme.setStockRiseFall(stockInfo.rate>0)">
							<image :src="`/static/arrow_${stockInfo.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(24)"></image>
							{{($util.formatNumber($util.formatMathABS(stockInfo.rate),2))}}%
						</view>
					</view>
				</view>
			</template>

			<CustomTitle :title="$lang.STOCK_BUY_QUANTITY"></CustomTitle>
			<view
				style="display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between; margin:0 10px;padding:10rpx;">
				<block v-for="(item,index) in quantityList" :key='index'>
					<view @click="chooseQTY(item)"
						style="margin:10rpx; padding: 8rpx 10rpx; width: 25%;text-align: center;border-radius: 2rpx;font-size: 28rpx;line-height: 1.8;"
						:style="setStyle(curQuantity ==item)">{{item}}</view>
				</block>
			</view>

			<view class="common_input_wrapper" style="background-color:#FFFFFF;border: 1px solid #E8EAF3;">
				<view style="width: 20px;"></view>
				<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY" @input="handleInput"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>

			<!-- 杠杆数组大于1，视为开启杠杆功能 -->
			<!-- <template v-if="leverList.length>1">
				<CustomTitle :title="$lang.LEVER"></CustomTitle>
				<view
					style="display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between; margin:0 10px;padding:10rpx;">
					<block v-for="(item,index) in leverList" :key='index'>
						<view @click="chooseLever(item)"
							style="margin:10rpx; padding: 8rpx 10rpx; width: 25%;text-align: center;border-radius: 2rpx;font-size: 28rpx;line-height: 1.8;"
							:style="setStyle(curLever ==index)">{{item}}</view>
					</block>
				</view>
			</template> -->

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(quantity)}}
				</view>
			</view>

			<!-- <template v-if="leverList.length>1">
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
					:style="{color:$theme.TEXT}">
					<view>{{$lang.LEVER}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{curLever}}
					</view>
				</view>
			</template> -->
			<template v-if="stockInfo">
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
					:style="{color:$theme.TEXT}">
					<view>{{$lang.STOCK_BUY_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(stockInfo.current_price*curQuantity)}}
					</view>
				</view>
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
					:style="{color:$theme.TEXT}">
					<view>{{$lang.STOCK_BUY_FEE}}[{{$lang.CURRENCY_UNIT}}]</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(stockInfo.current_price*curQuantity*fee)}}
					</view>
				</view>
			</template>
		</view>
		<view :style="$theme.btnCommon(true)" style="margin:20px auto; width: 90%;" @click="placeOrder()">
			{{$lang.BTN_BUY}}
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			CardItemPrimary,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [50, 100, 150, 200, 250, 300], // 预置数量
				curQuantity: 50, // 当前选中预置数量
				quantity: 50, // 数量输入框 
				leverList: [], // 杠杆值数组
				// curLever: 1, // 当前选中杠杆值
				show: false,
				stockInfo: null,
				userInfo: {},
				cardData: {},
				fee: 1, // 手续费
			};
		},

		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE];
			},
		},

		onLoad(option) {
			this.getStockDetail(option.code)
			this.getconfig();
			this.getUserInfo()
		},
		methods: {
			// 设置样式
			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.PRIMARY : '#F1F1F1',
					color: val ? '#FFFFFF' : '#121212',
				}
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			// 选择杠杆
			chooseLever(val) {
				// this.curLever = val;
			},

			// 获取配置
			async getconfig() {
				const result = await this.$http.get(`api/app/config`);
				console.log(result);
				if (result.code == 0) {
					const temp = result.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async getStockDetail(code) {
				const result = await this.$http.get(`api/product/info`, {
					code: code,
				})
				this.stockInfo = result.data[0]
			},
			//购买
			placeOrder() {
				const _this = this;
				let money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
					success: (res) => {
						if (res.confirm) {
							_this.buy()
						} else {}
					}
				})
			},
			async buy() {
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity || 0,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					// ganggan: this.curLever,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 获取账户信息
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.money,
					};
					if (result.data.ganggan) {
						const temp = result.data.ganggan.map(item => Number(item));
						this.leverList = temp;
					}
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		},
	}
</script>