<!-- 绑定银行卡 -->
<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderSecond :title="$lang.ACCOUNT_CARD_MANAGEMENT" color="#FFFFFF"></HeaderSecond>
		<view style="background-color: #FFFFFF;padding: 20rpx;margin: 20rpx;">
			<!-- <TitleSecond :title="$lang.REAL_NAME" color="#121212"></TitleSecond> -->

			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="realname" type="text" :placeholder="$lang.TIP_REAL_NAME"
						:placeholder-style="$theme.setPlaceholder()" style="padding-left: 40rpx;"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#121212;">
						{{info.realname ||''}}
					</view>
				</template>
			</view>

			<!-- <TitleSecond :title="$lang.BANK_NAME" color="#121212"></TitleSecond> -->

			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="bank_name" type="text" :placeholder="$lang.TIP_BANK_NAME"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;padding-left: 40rpx;"></input>
					<view @click="handleShowBankList()"
						style="width:80px;height: 23px;line-height: 23px; background-color:#fff3c7;text-align: center;margin-right: 3px;border-radius: 6px;">
						{{$lang.BTN_BANK_SELECTED}}
					</view>
					<u-picker :show="showBankList" :columns="bankList" @cancel="showBankList = false"
						@confirm="handleConfirmBank" :cancelText="$lang.BTN_CANCEL"
						:confirmText="$lang.BTN_CONFIRM"></u-picker>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#121212;">
						{{info.bank_name ||''}}
					</view>
				</template>
			</view>

			<!-- <TitleSecond :title="$lang.BANK_CARD" color="#121212"></TitleSecond> -->
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="card_sn" type="text" :placeholder="$lang.TIP_BANK_CARD"
						:placeholder-style="$theme.setPlaceholder()" style="padding-left: 40rpx;"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#121212;">
						{{info.card_sn}}
					</view>
				</template>
			</view>

			<template v-if="isRenewal">
				<view
					style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;padding-bottom: 30rpx;">
					<view :style="$theme.btnCommon(true)" style="width: 30%;" @click="handleCancel()">
						{{$lang.BTN_CANCEL}}
					</view>
					<view :style="$theme.btnCommon(false)" style="width: 30%;" @click="replaceBank()">
						{{$lang.BTN_CONFIRM}}
					</view>
				</view>
			</template>
			<template v-else>
				<view :style="$theme.btnCommon(true)" @click="renewal()">
					{{$lang.BTN_CHANGE_BANK_CARD}}
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER,
		ACCOUNT_AUTH
	} from '@/common/paths';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	// import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			// TitleSecond,
		},
		data() {
			return {
				showBankList: false, // 是否显示银行备选列表
				info: {},
				isRenewal: false,
				realname: '', // 开户人
				bank_name: '', // 银行名称
				card_sn: '', // 卡号
			};
		},
		computed: {
			// 银行备选列表， u-picker中需要套一层数组
			bankList() {
				return [
					[
						"NH농협은행",
						"KB국민은행",
						"신한은행",
						"우리은행",
						"IBK기업은행",
						"KEB하나은행",
						"카카오뱅크",
						"대구은행",
						"부산은행",
						"MG새마을금고",
						"우체국",
						"광주은행",
						"경남은행",
						"신협중앙회",
						"수협",
						"SC제일은행",
						"케이뱅크",
						"KDB산업은행",
						"제주은행",
						"전북은행",
						"토스뱅크",
					]
				];
			}
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleShowBankList() {
				this.showBankList = true;
			},
			handleConfirmBank(e) {
				console.log('e:', e);
				this.bank_name = e.value[0];
				this.showBankList = false;
			},
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				this.replaceBank();
			},
			// 换绑银行卡
			async replaceBank() {
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			//用户信息
			async gaint_info() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				console.log(result);
				if (result.code == 0) {
					// 未有真实姓名，跳转到实名认证
					if (!result.data.real_name) {
						uni.navigateTo({
							url: this.$paths.ACCOUNT_AUTH,
						})
					}
					// 未有银行卡信息，自动切换到绑卡状态
					if (!result.data.bank_card_info) {
						this.isRenewal = true;
					} else {
						this.info = result.data.bank_card_info;
					}
				}
				uni.hideLoading();
			},
		},
	}
</script>