<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderSecond :title="$lang.ACCOUNT_TRADE_LOG" color="#FFFFFF"></HeaderSecond>
		
		<view style="margin:0 10px;padding:10rpx;background-color: #FFFFFF;">
			<TabsPrimary :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsPrimary>
		</view>

		
		<!-- 	<TabsSecond :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsSecond>
				<TabsThird :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsThird>
				<TabsFourth :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsFourth>
				<TabsFifth :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsFifth>
				<TabsSixth :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsSixth> -->

		<view style="background-color: #FFFFFF;padding: 20rpx;margin: 20rpx;min-height: 100vh;">
			<view style="padding: 20px 0;">
				<template v-if="curTab == 0">
					<LogTrade></LogTrade>
				</template>

				<template v-if="curTab == 1">
					<LogDeposit></LogDeposit>
				</template>

				<template v-if="curTab == 2">
					<LogWithdraw></LogWithdraw>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	// import TabsSecond from '@/components/tabs/TabsSecond.vue';
	// import TabsThird from '@/components/tabs/TabsThird.vue';
	// import TabsFourth from '@/components/tabs/TabsFourth.vue';
	// import TabsFifth from '@/components/tabs/TabsFifth.vue';
	// import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			// TabsSecond,
			// TabsThird,
			// TabsFourth,
			// TabsFifth,
			// TabsSixth,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>