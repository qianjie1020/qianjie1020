<template>
	<view :style="$theme.setBGSize('800rpx')" style="min-height: 100vh;">
		<!-- <view class="auth_header"> -->
		<HeaderSecond :title="$lang.PAGE_TITLE_AUTH" color="#FFFFFF"></HeaderSecond>
		<!-- </view> -->

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 30rpx;">
			<image src="/static/auth_header.png" mode="aspectFit" :style="$theme.setImageSize(480,320)"></image>
		</view>


		<view style="background-color: #FFFFFF;padding: 20rpx;margin: 20rpx;">

			<TitleSecond :title="$lang.REAL_NAME" color="#121212"></TitleSecond> 

			<view style="margin:0 40rpx;">
				<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;margin-top: 0;">
					<input v-model="realName" type="text" placeholder="이름을 입력해주세요" style="width: 80%;"
						placeholder-style="font-size:11px"></input>
				</view>
			</view>

			<TitleSecond :title="$lang.AUTH_ID_CARD" color="#121212"></TitleSecond>
			<view style="margin:0 40rpx;">
				<view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;margin-top: 0;">
					<!-- 韩国专用证件号码输入校验 -->
				<!-- 	<input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD" maxlength=14
				placeholder-style="font-size:11px" @input="inputChange" style="width: 86%;"></input> -->
					<!-- 非校验 -->
					<template v-if="showPwd">
						<!-- <input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"></input> -->
							<input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD" maxlength=14
							placeholder-style="font-size:11px" @input="inputChange" style="width: 86%;"></input>
					</template>
					<template v-else>
						<input v-model="cardNo" type="password" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"></input>
					</template>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}_dark.png`" @click="handleShowPwd"
						:style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>

			<TitleSecond :title="$lang.AUTH_CARD_F" color="#121212"></TitleSecond>
			<view
				style="display: flex;align-items: center;justify-content: center;padding: 24px;border-radius: 8rpx;margin: 30rpx;background-color: #F7F9FF;">
				<image :src="!formData.obverseUrl?`/static/card_f.png`:formData.obverseUrl" @click="obverse_btn"
					style="margin: 10px;width: 220px;height: 120px;"></image>
			</view>

			<TitleSecond :title="$lang.AUTH_CARD_B" color="#121212"></TitleSecond>
		<view
			style="display: flex;align-items: center;justify-content: center;padding: 24px;border-radius: 8rpx;margin: 30rpx;background-color: #F7F9FF;">
			<image :src="!formData.reverseUrl?`/static/card_b.png`:formData.reverseUrl" @click="reverse_btn"
				style="margin: 10px;width: 220px;height: 120px;"></image>
		</view>

			<view :style="$theme.btnCommon(true,{padding:'11px 26px'})" @click="gain_aouonym()"
				style="margin:40rpx 80rpx;">
				{{$lang.BTN_CONFIRM}}
			</view>
			<view style="margin: 10px;padding-bottom: 30px; text-align: center;color:#55555;">
				{{$lang.AUTH_TIP_TEXT}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
		},
		data() {
			return {
				realName: '', // 姓名 이정현
				cardNo: '', // 证件号码
				showPwd: false, // 是否显示完整证件号
				fullCardNo: '', // 证件号码完整值

				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				userinfo: {},
			};
		},
		onLoad() {
			this.userInfo()
		},
		computed: {
			// 计算性别
			// calcSex() {
			// 	return this.fullCardNo.length < 7 ? '' : this.fullCardNo[7] == '1' ? '남성' : this.fullCardNo[7] == '2' ?
			// 		'여성' : '';
			// },
		},

		methods: {
			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
				// this.formatCardNo(this.fullCardNo);
			},

			// // 证件号码格式化
			// formatCardNo() {
			// 	this.cardNo = this.showPwd ? this.fullCardNo : this.fullCardNo.substring(0, 8) + `******`;
			// },

			// // ID号输入值变动
			// inputChange(val) {
			// 	const temp = val.detail.value;
			// 	if (/^[0-9\-\\*]*$/.test(temp)) {
			// 		this.fullCardNo = temp;
			// 		if (temp.length >= 6 && temp.length <= 14) {
			// 			this.cardNo = `${temp.slice(0,6)}-${temp.slice(7,temp.length-7)}`;

			// 			// if (temp.length > 8) {
			// 			// 	// this.cardNo = temp.substring(0, 8) + `*`.repeat(temp.length - 8); // 逐字符替换为*
			// 			// 	// this.cardNo = temp.substring(0, 8) + `******`; // 超出后，一次性替换为******
			// 			// 	// console.log('1', this.cardNo)
			// 			// 	 this.cardNo = this.formatCardNo(temp);
			// 			// }
			// 		}
			// 	} else {
			// 		uni.$u.toast(this.$lang.AUTH_TIP_ID_CARD);
			// 		// 解决数据不更新问题，此处必须这样写。
			// 		setTimeout(() => {
			// 			this.cardNo = "";
			// 			this.fullCardNo = "";
			// 		}, 0);
			// 	}
			// 	console.log('full:', this.fullCardNo);
			// },
			obverse_btn() {
				if (this.obverseUrl) {
					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast(this.$lang.AUTH_TIP_CARD_F);
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast(this.$lang.AUTH_TIP_CARD_B);
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB

						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],
				});
			},
			// // 删除
			// del_btn(name) {
			// 	this.$emit('del', {
			// 		name
			// 	});
			// },

			// 认证
			async gain_aouonym() {
				// this.fullCardNo 提交时，提交完整证件号码 各别项目需求严格校验身份证，及号码段位隐藏
				const tempCardNo = this.cardNo;
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName,
					// sex: this.calcSex,
					idno: tempCardNo,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				});

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.HOME
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			async userInfo() {
				const result = await this.$http.get(`api/user/fastInfo`);
				if (result.code == 0) {
					this.realName = result.data.real_name;
					this.cardNo = result.data.idno;
					// this.fullCardNo = result.data.idno;
					// this.formatCardNo(this.fullCardNo);
					this.userinfo = result.data
					this.formData.obverseUrl = result.data.front_image
					this.formData.reverseUrl = result.data.back_image
				} else {
					uni.$u.toast(result.message);
				}
			},

			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
				var that = this;

				let mdd = md5("XPFXMedS" + Request + str_url + time)

				uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',

					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data, type, data[0].url)
						if (type == 1) {
							that.formData.obverseUrl = data[0].url;
						} else {
							that.formData.reverseUrl = data[0].url;
						}
					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222, e)
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
	};
</script>