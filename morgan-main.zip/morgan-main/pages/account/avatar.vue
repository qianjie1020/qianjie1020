<template>
	<view :style="$theme.setBGSize('480rpx')" style="min-height: 100vh;">
		<HeaderSecond :title="$lang.PAGE_TITLE_AVATAR" color="#FFFFFF"></HeaderSecond>

		<view
			style="background-color: #FFFFFF;display: flex;flex-direction: column;justify-content: center;align-items: center;margin:20rpx;padding-top: 30rpx;">
			<u-upload @afterRead="afterRead" @delete="deletePic" name="6" :maxCount="1" width="240rpx" height="240rpx">
				<image :src="imgUrl" mode="scaleToFill" :style="$util.setImageSize(240)"> </image>
			</u-upload>

			<view style="width: 80%;padding:20px;">
				<view class="common_input_wrapper" style="margin-bottom: 60rpx;">
					<image mode="aspectFit" src="/static/user.png" :style="$theme.setImageSize(28)">
					</image>
					<input v-model="nick_name" type="text" :placeholder="$lang.AVATAR_TIP_NICK_NAME"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<view :style="$theme.btnCommon(true,{padding:'11px 26px'})" @click="submit_list">
					{{$lang.BTN_AVATAR}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				fileList6: [],
				is_url: "",
				imgUrl: '',
				nick_name: "",
			};
		},
		created() {
			this.userInfo()
		},
		methods: {
			async submit_list() {
				const result = await this.$http.post(`api/user/updateAvatar`, {
					avatar: this.is_url,
					nickname: this.nick_name,

				})
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.ACCOUNT_CENTER
						});
						// 登录成功之后强制刷新页面
						this.$router.go(0)
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 回调参数为包含columnIndex、value、values
			async userInfo() {
				const result = await this.$http.get(`api/user/fastInfo`);
				this.imgUrl = result.data.avatar ? result.data.avatar : `/static/avatar.png`;
				this.nick_name = result.data.nick_name
			},
			confirm(e) {
				this.title = e.value[0]
				this.show = false
			},
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
				this.src = this.fileList6[0].thumb
			},
			uploadFilePromise(url) {
				console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						this.imgUrl = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
		},
	}
</script>