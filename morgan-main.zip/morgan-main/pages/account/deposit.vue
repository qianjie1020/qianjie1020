<!-- 银转证  存款 -->
<template>
	<view class="deposit_bg">
		<HeaderSecond :title="$lang.PAGE_TITLE_DEPOSIT" color="#FFFFFF"></HeaderSecond>

		<view style="margin:60rpx;">
			<view style="text-align: center;color:#FFFFFF;font-size: 28rpx;line-height: 2;">
				{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`" @click="handleShowAmount"
					:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
				</image>
			</view>

			<view style="font-size: 48rpx;color:#FFFFFF;font-weight: 700;text-align: center;line-height: 2;">
				{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
			</view>
		</view>

		<view style="padding:40rpx;background-color: #FFFFFF;margin:20rpx 30rpx;margin-top: -40px;">
			<!-- <TitleSecond :title="$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT" color="#121212"></TitleSecond>
			<view class="common_input_wrapper">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;margin-left: 20px;"></input>
			</view> -->

			<!-- <view style="display: flex;flex-wrap:wrap;align-items: center;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="padding:10px;margin: 10rpx; border-radius: 6px;line-height: 1.6;flex:25%;text-align: center;"
						:style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatNumber(item)}}
					</view>
				</block>
			</view> -->
			<view class="bold text-center" style="padding: 20px; font-size: 20px;">충전하려면 아래 온라인 고객센터를 클릭하세요.</view>
			<view style="padding: 0px 50px;">
				<view  @click="kefu()" class="text-center" style="margin-top: 30rpx;background-color: #03b7f2;padding: 10px;border-radius: 5px;">
					고객 서비스
				</view>
			</view>
			

			<view style="padding: 40rpx 0;">
				<!-- <view style="font-size: 14px;font-weight: 700;text-align: center;color:#FFFFFF;">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view> -->
				<!-- <block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
					<view style="padding-bottom:6px;color:#555555;line-height: 1.6;">{{item}}</view>
				</block> -->
			</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
			AccountAssets,
			CardItemPrimary,
			TitleSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
				userInfo: {}, //
				cardThird: {},
			};
		},
		computed: {
			cardThirdLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];
			}
		},
		onLoad(option) {
			this.gaint_info()
			this.amount = this.amountList[0];
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? '#E8EDFF' : '#F5F5F5',
					color: val ? this.$theme.PRIMARY : '#585858',
				}
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			kefu(){
				uni.navigateTo({
					url:'/pages/service'
				})
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});

				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},

			//个人信息
			async gaint_info() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardThird = {
						value1: this.userInfo.money, // 可提
						value2: this.userInfo.freeze, // 冻结
						value3: this.userInfo.totalYingli, // 总盈利
					};
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},
		},
	}
</script>