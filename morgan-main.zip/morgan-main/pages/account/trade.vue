<template>
	<view :style="$theme.setBGSize('640rpx')">
		<HeaderPrimary isSearch isAccount></HeaderPrimary>

		<view style="display: flex;align-items: center;justify-content: center;margin: 30rpx 0;">
			<view class="home_card_bg home_card_bg_2" style="width: 300px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>


		<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 20rpx;margin:20rpx;">
			<view :style="$theme.btnCommon(false)" style="width: 30%;margin:0 20rpx;" @click="linkDeposit()">
				{{$lang.PAGE_TITLE_DEPOSIT}}
			</view>
			<view :style="$theme.btnCommon(true)" style="width: 30%;margin:0 20rpx;background-color: #569CFA;" @click="linkWithdraw()">
				{{$lang.PAGE_TITLE_WITHDRAW}}
			</view>
		</view>

		<view style="background-color: #FFFFFF;padding:6px;margin:30rpx;">
			<TitleSecond :title="$lang.TRADE_TITLE" color="#121212"></TitleSecond>
			<view
				style="display: flex;align-items: center;justify-content: space-between;line-height:1.2;border-bottom: 1px solid #F1F1F1;">
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;">
					<view style="color:#999">{{$lang.TRADE_TOTAL_BUY_AMOUNT}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(userInfo.frozen)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;border-left: 1px solid #F1F1F1;">
					<view style="color:#999">{{$lang.TRADE_VALUATION_GAIN_LOSS}}</view>
					<view :style="{color:$theme.TEXT}">
						{{$util.formatNumber(userInfo.holdYingli)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;justify-content: space-between;line-height:1.2;border-bottom: 1px solid #F1F1F1;">
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;">
					<view style="color:#999">평가 금액</view>
					<view :style="{color:$theme.TEXT}">
						{{$util.formatNumber(userInfo.guzhi)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;border-left: 1px solid #F1F1F1;">
					<view style="color:#999">{{$lang.TRADE_RATE_RESPONSE}}</view>
					<view :style="{color:$theme.TEXT}">
						{{userInfo.huibao}}%
					</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.2;">
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;">
					<view style="color:#999">{{$lang.ACCOUNT_AMOUNT_TOTAL}}</view>
					<view :style="{color:$theme.TEXT}">
						{{$util.formatNumber(userInfo.totalZichan)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
				<view style="margin:0 6px;padding:10px;text-align: center;flex:0 0 40%;border-left: 1px solid #F1F1F1;">
					<view style="color:#999">실현손익</view>
					<view :style="$theme.setStockRiseFall(userInfo.totalYingli>0)">
						{{$util.formatNumber(userInfo.totalYingli)}}{{$lang.CURRENCY_UNIT}}
					</view>
				</view>
			</view>
		</view>

		<view style="background-color: #FFFFFF;padding:6px;margin:30rpx;">
			
			<view style="margin:0 30rpx;padding:10rpx;background-color: #FFFFFF;">
				<TabsPrimary :tabs="$lang.TRADE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>
			</view>
			
			<template v-if="list && list.length<=0">
				<EmptyData></EmptyData>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:20rpx 40rpx;border-bottom: 1px solid #F1F1F1;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
							<view style="color: #333333;font-size: 28rpx;font-weight: 700;"> {{item.goods_info.name}}
							</view>
							<view style="padding: 2px 20rpx;font-size: 24rpx;"
								:style="{color:$theme.PRIMARY,border:`1px solid ${$theme.PRIMARY}`}"
								@tap="handleShowModal(item)">
								{{isHold? $lang.BTN_SELL:$lang.BTN_DETAIL}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;margin-top: 20rpx;">
							<view style="color:#666666;"> {{$lang.TRADE_LIST_THEAD[3]}}</view>
							<template v-if="isHold">
								<view :style="$theme.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
									{{$util.formatNumber(item.order_buy.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
								</view>
							</template>
							<template v-else>
								<template v-if="item.order_sell">
									<view :style="$theme.setStockRiseFall(item.order_sell.yingkui*1>0)">
										{{$util.formatNumber(item.order_sell.yingkui*1)}}
									</view>
								</template>
							</template>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;"> {{isHold?$lang.TRADE_LIST_THEAD[1] :'손익률'}}</view>
							<template v-if="isHold">
								<view :style="$theme.setStockRiseFall(item.order_buy.float_yingkui*1>0)">
									<!-- 持仓盈利率 =（最终价 - 买入价） / 买入价 *100% -->
									{{$util.formatNumber(((item.goods_info.current_price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
								</view>
							</template>
							<template v-else>
								<template v-if="item.order_sell">
									<view :style="$theme.setStockRiseFall(item.order_sell.yingkui*1>0)">
										<!-- 买入，卖出，盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% -->
										{{$util.formatNumber(((item.order_sell.price*1-item.order_buy.price*1)/item.order_buy.price*100),2)}}%
									</view>
								</template>
							</template>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;"> {{isHold?$lang.TRADE_LIST_THEAD[2]:'매도수량'}}</view>
							<view :style="{color:$theme.TEXT}">
								{{$util.formatNumber(item.order_buy.num)}}주
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;" v-if="isHold"> {{$lang.TRADE_LIST_THEAD[4]}}</view>
							<view style="color:#666666;" v-if="!isHold"> 매도총액</view>
							<template v-if="isHold">
								<view :style="{color:$theme.TEXT}">
									{{$util.formatNumber(item.order_buy.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
								</view>
							</template>
							<template v-else>
								<template v-if="item.order_sell">
									<view :style="{color:$theme.TEXT}">
										{{$util.formatNumber(item.order_sell.price*1*item.order_buy.num)}}{{$lang.CURRENCY_UNIT}}
									</view>
								</template>
							</template>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;"> {{isHold?$lang.TRADE_LABEL_BUY_PRICE:'매수가'}}</view>
							<view :style="{color:$theme.TEXT}">
								{{$util.formatNumber(item.order_buy.price)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">
								{{isHold?$lang.TRADE_LABEL_LAST_PRICE: '매도가'}}
							</view>
							<template v-if="isHold">
								<view style="" :style="{color:$theme.RISE}">
									{{$util.formatNumber(item.goods_info.current_price)}}{{$lang.CURRENCY_UNIT}}
								</view>
							</template>
							<template v-else>
								<template v-if="item.order_sell">
									<view style="" :style="{color:$theme.RISE}">
										{{$util.formatNumber(item.order_sell.price)}}{{$lang.CURRENCY_UNIT}}
									</view>
								</template>
							</template>
						</view>
					</view>
				</block>
			</template>
		</view>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup"
					style="min-height:35vh;margin:auto;padding-bottom: 20px;border-radius: 0;">
					<view class="popup_header" style="background-color: #FFFFFF;border-radius: 0;">
						<text style="text-align: center;font-size: 36rpx;color:#121212;">{{info.goods_info.name}}</text>
						<image src="/static/close.png" :style="$theme.setImageSize(36)" @click="isShow=false"
							style="position: absolute;right: 20px;top:15px;"></image>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[1]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{info.order_buy.created_at}}
						</view>
					</view>
					<template v-if="!isHold">
						<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
							<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[2]}}
							</view>
							<template v-if="info.order_sell">
								<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
									{{info.order_sell.created_at}}
								</view>
							</template>
						</view>
					</template>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[3]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(
							isHold?info.order_buy.float_yingkui*1
							:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>

					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[5]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[6]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(info.order_buy.price)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[7]}}
						</view>
						<view style="flex: 30%;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(info.order_buy.num)}}
						</view>
						<view style="flex: 20%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[4]}}
						</view>
						<view style="flex: 20%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{info.order_buy.double}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[8]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[9]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;padding:6px;margin:0 10px;line-height: 1.8;">
						<view style="flex: 30%;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_MODAL_LABELS[10]}}
						</view>
						<view style="flex: 70%;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{info.goods_info.number_code}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
						v-if="isHold">
						<view class="trade_modal_btn" style="background-color:#03b7f2;"
							@tap="handleStockDetail(info.goods_info.number_code)">
							{{$lang.BTN_DETAIL}}
						</view>
						<view class="trade_modal_btn" style="background-color:#042EB4;" @tap="handleSell(info.id)">
							{{$lang.BTN_SELL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TradeInfo from '@/components/TradeInfo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			HeaderPrimary,
			TradeInfo,
			EmptyData,
			TabsPrimary,
			TitleSecond,
			AccountAssets,
			CardItemPrimary,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
				cardData: {},
				curTab: 0, // 默认放在持仓列表，即左边

				radioLocation: this.$lang.STOCK_COUNTRY_SELF, // 국내
				isHold: true, // 是否是持股状态，否则为销售历史
				isSelf: true, // 国内，false:海外
				list: [],
				info: {},
				isShow: false, // 买卖弹出
				curPage: 1, // 当前页码	
				maxPage: 1, // 最大页码
				flag: true, // 上拉加载开关 防止一次触底查询多次问题,防止数据查完后触底还调接口问题
			}
		},
		computed: {
			cardLabels() {
				return [					
					this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
				];
			},
			locationList() {
				return [{
					name: this.$lang.STOCK_COUNTRY_SELF,
				}, {
					name: this.$lang.STOCK_COUNTRY_OTHER
				}]
			}
		},

		onLoad() {
			this.getUserInfo();
		},
		onShow() {
			console.log(`?`,this.cardLabels);
			this.getData();
		},
		//下拉刷新
		onPullDownRefresh() {
			// this.curPage = 1; // 从第一页重新开始
			// this.list = []; // 清空所有翻页后内中数据
			this.getData();
			uni.stopPullDownRefresh();
		},

		// //监听页面触底函数
		// onReachBottom() {
		// 	// 如果触底，并且当前页码<最大页码
		// 	console.log(this.curPage, this.maxPage);
		// 	if (!this.flag) {
		// 		if (this.curPage < this.maxPage) {
		// 			this.curPage++;
		// 			console.log('page:', this.curPage);
		// 			this.getData()
		// 		}
		// 		if (this.curPage >= this.maxPage) {
		// 			return false;
		// 		}
		// 	}
		// },
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				if (this.curTab == 1) {
					this.isHold = false;
				} else {
					this.isHold = true;
				}
				// this.isHold = val == 1;
				// this.curPage = 1; // 从第一页重新开始
				// this.list = []; // 清空数据
				this.getData();
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			groupChange(n) {
				console.log('groupChange', n);
			},
			// handleChangeLocation(val) {
			// 	this.isSelf = val == 0;
			// 	this.getData();
			// },
			// handleChangeList(val) {
			// 	this.isHold = val == 0;
			// 	this.getData();
			// },

			handleShowModal(item) {
				this.isShow = true;
				this.info = item
			},

			// 平仓/卖出
			handleSell(id) {
				const _this = this;
				uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
					success: function(res) {
						this.isShow = false;
						if (res.confirm) {
							_this.confirmSell(id);
						} else if (res.cancel) {}
					}
				})
			},

			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/user/info`);
				if (result.code == 0) {
					this.userInfo = result.data;
					this.cardData = {
						value1: this.userInfo.money, // 可提
						value2: this.userInfo. totalZichan, // AI
						value3: this.userInfo.aiMoney, // 总资产
					};
				} else {
					uni.$u.toast(result.message);
				}
				uni.hideLoading();
			},

			// 平仓功能
			async confirmSell(id) {
				const result = await this.$http.post(`api/user/sell`, {
					id
				});
				if (result.code == 0) {
					this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}

			},

			handleStockDetail(code) {
				uni.navigateTo({
					url: `${this.$paths.STOCK_OVERVIEW}?code=${code}`
				});
			},

			async getData() {
				// this.flag = true;
				const result = await this.$http.get(`api/user/order`, {
					// page: this.curPage,
					status: this.isHold ? 1 : 2, // 1持仓，2历史
					gp_index: this.isSelf ? 0 : 1,
				});

				// this.flag = false;
				if (result.code == 0 && result.data) {
					// this.list.push(...result.data);
					this.list = result.data;
					// this.maxPage = result.data.last_page; // 最大页码
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>