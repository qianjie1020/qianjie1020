<template>
	<view :style="$theme.setBGSize('480rpx')">
		<!-- <view style="background-image: linear-gradient(180deg, #F5B71C, transparent);"> -->
		<HeaderSecond :title="$lang.ACCOUNT_CHANGE_PWDDD" color="#FFFFFF"></HeaderSecond>
		<!-- </view> -->

		<view style="background-color: #FFFFFF;padding: 20rpx;margin: 20rpx;">
			<!-- <TitleSecond :title="$lang.TIP_OLD_PWD" color="#121212"></TitleSecond> -->
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.TIP_OLD_PWD"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>
			<!-- <TitleSecond :title="$lang.TIP_NEW_PWD" color="#121212"></TitleSecond> -->
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="value2" type="text" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value2" type="password" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
			<!-- <TitleSecond :title="$lang.TIP_NEW_PWD_VERIFY" color="#121212"></TitleSecond> -->
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="value3" type="text" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="value3" type="password" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
			<view :style="$theme.btnCommon(true)" @click="changePassword()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_CENTER
	} from '@/common/paths';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
		},
		data() {
			return {
				isShow: false, // 密码显隐
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(`api/user/updateLoginPassword`, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_POST_SUCCESS);
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>