<template>
	<view style="position: relative;">
		<image src="/static/beijing.png"  style="width: 100%;height: 160px;"></image>
		
        
		<view style="position: relative;bottom: 170px;">
			<HeaderPrimary isSearch isLang isAccount> </HeaderPrimary>
			
			<view style="width: 100%;justify-content: center;display: flex;margin-top: 15px;">
				<image src="/static/lumbotuts.png" mode="widthFix" style="width: 95%;border-radius: 10px;"></image>
			</view>
			
		
		<ButtonGroup></ButtonGroup>

		<!-- <NotifyPrimary></NotifyPrimary> -->
		<view style="background-color: #FFFFFF;margin:30rpx;">
			<CustomTitle :title="$lang.MARKET_NEWS_TITLE">
				<view style="font-size: 13px;color:#555555;" @click="linkMarketNews()">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(14)">
					</view>
				</view>
			</CustomTitle>

			<view style="padding-bottom: 16px;">
				<MarketNewsTop></MarketNewsTop>
			</view>
		</view>

		<!-- <FollowList ref="follow"></FollowList> -->
		<view style="background-color: #FFFFFF;margin:30rpx;padding-bottom: 60rpx;">
			<CustomTitle :title="$lang.STOCK_ALL">
				<view style="font-size: 13px;color:#555555;" @click="linkAllList()">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</CustomTitle>

			<!-- <GoodsList ref="goods"></GoodsList> -->
			<view style="padding-bottom:20px;">
				<MarketHot></MarketHot>
			</view>
		</view>

		<template v-if="isShow">
			<view class="mask" @click="handleClose()">
				<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 10vh;"
					@click="handleClose()">
					<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:20vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;padding: 20px 0;"
						:style="$theme.linerGradient(180,'#FFA99D','#FFFFFF')">
						<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
							
						</view>

						<view>
							<image src="/static/dialog_icon.png" mode="aspectFit" :style="$theme.setImageSize(450,250)">
							</image>
						</view>
						
						<view
							style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
							<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
								{{ipoInfo.name}}
							</view>
							<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
								{{ipoInfo.code}}
							</view>

							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_QTY}}</view>
								<text style="font-weight: 700;color:#722A3E;font-size: 16px;">
									{{$util.formatNumber(ipoInfo.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
								<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_TOTAL}}</view>
								<text
									style="font-weight: 700;color:#722A3E;font-size: 16px;">{{$util.formatNumber(ipoInfo.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1.5;background-color:#722A3E;color:#FFF;margin:20px 30px;"
								@click="linkIPOSuccessLog()">{{$lang.BTN_DETAIL_NOW}}</view>
						</view>
					</view>
				</view>
			</view>
		</template>
		</view>
	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/home/ButtonGroup.vue';
	// import GoodsList from '@/components/GoodsList.vue';
	// import FollowList from '@/components/FollowList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import CardPrimary from '@/components/card/CardPrimary.vue';
	import NotifyPrimary from '@/components/notify/NotifyPrimary.vue';
	import MarketNewsTop from '@/components/market/MarketNewsTop.vue';
	import MarketHot from '@/components/market/MarketHot.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			// GoodsList,
			// FollowList,
			CustomTitle,
			CardPrimary,
			NotifyPrimary,
			MarketNewsTop,
			MarketHot,
		},
		data() {
			return {
				ipoInfo: {}, // 
				isShow: false, // 是否显示中签弹层
				// isNotify: true, // 显示横向滚动通知
			}
		},

		computed: {
			bgColor() {
				return ['#158DB2', '#E65C3C', '#FFA847', '#49BB90'];
			}
		},

		onLoad() {
			// console.log('onLoad', this.$refs.goods);
			// console.log('onLoad', this.$refs.follow);
			this.ipoSuccess();
		},

		onShow() {
			// console.log('onShow', this.$refs.goods);
			// console.log('onShow', this.$refs.follow);
			// if (this.$refs.goods) {
			// 	this.$refs.goods.onSetTimeout();
			// }
			// if (this.$refs.follow) {
			// 	this.$refs.follow.onSetTimeout();
			// }
		},
		onReady() {
			// console.log('onReady', this.$refs.goods);
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			// console.log('onHide', this.$refs.goods);
			// console.log('onHide', this.$refs.follow);
			// this.$refs.goods.clearTimer();
			// this.$refs.follow.clearTimer();
		},
		deactivated() {
			// console.log('deactivated', this.$refs.goods);
			// console.log('deactivated', this.$refs.follow);
			// this.$refs.goods.clearTimer();
			// this.$refs.follow.clearTimer();
		},

		methods: {
			// 四个大按钮，跳转事件
			linkPage(url) {
				uni.navigateTo({
					url: url
				})
			},

			// // 关闭滚动通知
			// choseNotify(val) {
			// 	this.isNotify = false;
			// },
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: `${this.$paths.MARKET_OVERVIEW}?type=3`,
				})
			},
			// 关闭中签提醒
			handleClose(val) {
				console.log(val);
				this.isShow = val;
			},
			linkIPOSuccessLog() {
				uni.navigateTo({
					url: `${this.$paths.TRADE_IPO}?type=2`,
				})
			},

			// 获取IPO成功记录
			async ipoSuccess() {
				uni.showLoading({
					title: this.$lang.STATUS_REQUEST,
				})
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				console.log(result,'55555');
				if (result.code == 0) {
					if (result.data.length > 0) {
						const temp = result.data[0];
						this.ipoInfo = {
							code: temp.goods.code,
							name: temp.goods.name,
							success: temp.success,
							total: temp.total,
						};
						this.isShow = true;
					}
				} else {
					uni.$u.toast(result.data.message);
				}
				uni.hideLoading();
			},
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		/* background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat; */
		height: 55vh;
		width: 80vw;
	}
</style>