<template>
	<view :style="$theme.setBGCover(`launch_bg`)">

		<view style="display: flex;align-items: center;justify-content: center;padding-top: 23vh;">
			<image src='/static/logo.png' :style="$theme.setImageSize(412,400)">
			</image>
		</view>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<image src="/static/launch_img.png" mode="aspectFit" :style="$theme.setImageSize(512)"></image>
		</view> -->
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 100rpx;margin-bottom: 20vh;">
			<view style="text-align: center;font-size: 36rpx;font-family: 700;color:#FFFFFF;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view>

		<ProgressPrimary></ProgressPrimary>

	</view>
</template>

<script>
	import ProgressPrimary from '@/components/progress/ProgressPrimary.vue';
	export default {
		components: {
			ProgressPrimary
		},
	}
</script>

<style lang="scss">
	/* 启动页 */
	.launch {
		width: 100%;
		height: 100vh;
		background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		/* background-image: linear-gradient(180deg, #FFF3D1, transparent); */
		position: relative;
	}
</style>