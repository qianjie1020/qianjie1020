<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderPrimary isSearch isAccount></HeaderPrimary>
		<view style="margin:0 10px;padding:10rpx;background-color: #FFFFFF;">
			<TabsPrimary :tabs="$lang.MARKET_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>
		</view>
		<view style="padding-bottom: 20px;">
			<template v-if="curTab==0">
				<TabOne ref="tab0"></TabOne>
			</template>

			<template v-if="curTab==1">
				<view style="margin: 30rpx 20rpx ;background-color: #FFFFFF;min-height: 90vh;">
					<MarketHot></MarketHot>
				</view>
			</template>

			<template v-if="curTab==2">
				<view style="margin: 30rpx 20rpx ;background-color: #FFFFFF;min-height: 90vh;">
					<MarketKPI></MarketKPI>
				</view>
			</template>

			<template v-if="curTab==3">
				<view style="margin: 30rpx 20rpx ;background-color: #FFFFFF;min-height: 90vh;">
					<MarketNews></MarketNews>
				</view>
			</template>

		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabOne from '@/components/market/TabOne.vue'
	import MarketHot from '@/components/market/MarketHot.vue'
	import MarketKPI from '@/components/market/MarketKPI.vue'
	import MarketNews from '@/components/market/MarketNews.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TabOne,
			MarketHot,
			MarketKPI,
			MarketNews,
		},
		data() {
			return {
				curTab: 0,
				// timer: null,
			}
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type);
				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.changeTab(this.curTab);
		},
		onReady() {
			console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {
			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
			},
		},
	}
</script>