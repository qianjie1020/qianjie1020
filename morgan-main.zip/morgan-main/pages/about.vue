<!-- 关于我们 -->
<template>
	<view :style="$theme.setBGSize('480rpx')">
		<HeaderSecond :title="info.title" color="#333333"></HeaderSecond>

		<template v-if="isContent">
			<view style="padding: 40rpx;background-color: #FFFFFF;margin:0 20rpx">
				<view v-html="info.content"
					style="font-size:28rpx;white-space: break-spaces;line-height: 1.3;padding:10px;color:#000">
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				info: {},
			};
		},
		computed: {
			// 有内容则显示
			isContent() {
				return this.info && this.info.content && this.info.content.length > 0;
			}
		},
		onLoad() {
			this.getAbout()
		},
		methods: {
			//关于我们
			async getAbout() {
				const result = await this.$http.get(`api/article/about-us`);
				if (result.code == 0) {
					this.info = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>