<template>
	<view>
		<!-- <view style="display: flex;align-items: center;flex-wrap: wrap;justify-content:space-between;margin:30rpx;">
			<block v-for="(item,index) in btns.slice(0,4)" :key="index">
				<view @click="actionEvent(item.url)" :style="setBtnBG(`top${index}`)">
					<view
						style="display: flex;align-items: center;flex-direction: column;justify-content: center;height: 100%; text-align: center;color: #121212;">
						{{item.name}}
					</view>
				</view>
			</block>
		</view> -->

		<view style="background-color: #FFFFFF;margin:20rpx 30rpx;">
			<view class="btns " style="">
				<block v-for="(item,index) in btns.slice(0,8)" :key="index">
					<view class="item" @click="actionEvent(item.url)">
						<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(60,60)">
						</image>
						<text style="padding-top: 6px;">{{item.name}}</text>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		data() {
			return {};
		},
		computed: {
			btns() {
				// 首页按钮组
				const BTNS_CONFIG = [{
						name: this.$lang.TRADE_AI_TITLE,
						url: this.$paths.TRADE_AI,
					},
					{
						name: this.$lang.PAGE_TITLE_TRADE_IPO,
						url: this.$paths.TRADE_IPO,
					},
					//  {
					// 	name: this.$lang.PAGE_TITLE_TRADE_DAY,
					// 	url: this.$paths.TRADE_DAY,
					// },
					{
						name: this.$lang.PAGE_TITLE_TRADE_EQUITY,
						url: this.$paths.TRADE_IPOPEISHOU,
					},
					{
						name: this.$lang.PAGE_TITLE_TRADE_LARGE,
						url: this.$paths.TRADE_LARGE,
					},
					{
						name: '입금',
						url: '/pages/service',

					}, {
						name: this.$lang.PAGE_TITLE_WITHDRAW,
						url: this.$paths.ACCOUNT_WITHDRAW,
					}, {
						name: this.$lang.PAGE_TITLE_AUTH,
						url: this.$paths.ACCOUNT_AUTH,
					},
					{
						name: this.$lang.TABBAR_TRADE,
						url: this.$paths.MARKET_OVERVIEW,
					}
				];
				let btns = [];
				for (let i = 0; i < BTNS_CONFIG.length; i++) {
					btns.push({
						name: BTNS_CONFIG[i].name,
						icon: `top${i}`,
						url: BTNS_CONFIG[i].url
					})
				}
				return btns;
			}
		},
		methods: {
			// home btn组，四种交易背景图
			setBtnBG(url) {
				return {
					backgroundImage: `url(/static/${url}.png)`,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					width: '45%',
					height: '80px',
					margin: '10rpx',
				}
			},

			actionEvent(url) {
				if (url.includes('pages')) {
					if (url.includes('service')) {
						this.$util.linkCustomerService();
					} else if (url.includes('pages/market/overview')) {
						uni.reLaunch({
							url: `${this.$paths.MARKET_OVERVIEW}?type=3`,
						})
						// 底部菜单栏跳转用switchTab
					} else {
						uni.navigateTo({
							url: url
						})
					}
				} else {
					this.$emit('action', 1);
				}
			},
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px 0;

		.item {
			width: 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #121212;
			padding: 4px 0;
		}
	}
</style>