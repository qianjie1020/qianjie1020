<template>
	<view style="padding-bottom: 20px;">
		<template v-if="stockInfo">
			<view style="background-color: #FFFFFF;margin:-40rpx 20rpx 30rpx 20rpx;padding:0 20rpx 30rpx 20rpx;">
				<!-- 股票基本信息 -->
				<StockInfoBase :info="stockInfo.top1"></StockInfoBase>
				<!-- 公司简介 -->
				<CompanyProfile :info="stockInfo.top2"></CompanyProfile>
			</view>

			<!-- 销售额 -->
			<template v-if="isSales">
				<view style="background-color: #FEFFFF;margin:0 20rpx 30rpx 20rpx;padding:20rpx 0;">
					<CustomTitle :title="$lang.STOCK_SALES">
						<view style="margin-left: auto;color:#999999;">
							{{stockInfo.top3[0].report_year_month}}
						</view>
					</CustomTitle>

					<view style="display: flex;align-items: center;justify-content: space-around;margin:0 80rpx;">
						<block v-for="(item,index) in $lang.STOCK_SALES_TABS" :key="index">
							<view
								style="border-radius: 20rpx;padding:10rpx 20rpx;min-width: 80rpx;text-align: center;margin-right: 20rpx;"
								:style="setStyle(curSales ==index)" @click="changeSalesTab(index)">
								{{item}}
							</view>
						</block>
					</view>

					<view style="padding: 10px 6px;">
						<template v-if="salesData.length>0">
							<view style="display: flex;align-items: center;">
								<block v-for="(item,index) in formatSalesData">
									<!-- :style="{backgroundColor:item.rate>0?'#FFF3F1':'#D6FFEB' }" -->
									<view
										style="flex:33%;margin: 6px;padding: 6px;text-align: center;border:1px solid #ededed;border-radius: 12rpx;">
										<view style="line-height: 1.8;color:#999999;">{{item.label}}</view>
										<view style="font-size: 28rpx;line-height: 1.8;"
											:class="item.rate>0? 'rise':'fall'">
											{{$util.formatNumber(item.amount)}}{{$lang.UNIT_BILION}}
										</view>
										<view style="font-size: 24rpx;line-height: 1.8;"
											:class="item.rate>0? 'rise':'fall'">
											{{$util.formatNumber(item.rate,2)}}%
										</view>
									</view>
								</block>
							</view>
						</template>
					</view>

					<TabsFifth :tabs="$lang.STOCK_SALES_KLINE_TABS" @action="changeSalesKlineTab"
						:acitve="curSalesKline">
					</TabsFifth>

					<view style="margin: 10px 6px 20px 6px;">
						<view id="main" class="chart">
							<canvas canvas-id="zhexian" id="zhexian" class="charts" />
						</view>
					</view>
				</view>
			</template>

			<!-- 投资趋势 -->
			<view style="background-color: #FEFFFF;margin:0 20rpx 30rpx 20rpx;padding:20rpx 0;">
				<CustomTitle :title="$lang.STOCK_TRADE_TREND_TITLE">
					<view style="margin-left: auto;color:#999999;">
						{{stockInfo.top4['net_volume'].dt}}
					</view>
				</CustomTitle>

				<view style="padding:10px 0;">
					<view style="color:#121212;padding-left: 30rpx;font-size: 28rpx;">
						{{$lang.STOCK_TRADE_TREND_BUY_AMOUNT[0]}}
					</view>
					<StockTradeTrend :info="stockInfo.top4" :flag="0"></StockTradeTrend>

					<view style="color:#121212;padding-left: 30rpx;font-size: 28rpx;">
						{{$lang.STOCK_TRADE_TREND_BUY_AMOUNT[1]}}
					</view>
					<StockTradeTrend :info="stockInfo.top4" :flag="1"></StockTradeTrend>

					<view style="line-height: 2;color:#121212;padding-left: 30rpx;font-size: 28rpx;">
						{{$lang.STOCK_TRADE_TREND_RECENT_TITLE}}
					</view>

					<template v-if="stockInfo.top5">
						<view style="border-radius: 8px;">
							<view
								style="border-radius: 8px 8px 0 0;display: flex;align-items: center;padding:10px;background-color: #DBDBDB;">
								<block v-for="(item,index) in $lang.STOCK_TRADE_TREND_RECENT_LABELS">
									<view style="color:#999999;"
										:style="{flex:index==0?'20%':'26%',textAlign:index==0?'':'right'}">
										{{item}}
									</view>
								</block>
							</view>

							<block v-for="(item,index) in stockInfo.top5" :key="index">
								<view
									style="display: flex;align-items: center;padding:10px;border-bottom:1px solid #ededed;">
									<view style="flex:20%;font-size: 20rpx;color:#999999;">{{item.dt}}</view>
									<view :style="$theme.setStockRiseFall(item.net_vol_individual>0)"
										style="flex:26%;text-align: right;">
										{{$util.formatNumber(item.net_vol_individual)}}
									</view>
									<view :style="$theme.setStockRiseFall(item.net_vol_institutional>0)"
										style="flex:26%;text-align: right;">
										{{$util.formatNumber(item.net_vol_institutional)}}
									</view>
									<view :style="$theme.setStockRiseFall(item.net_vol_foreigner>0)"
										style="flex:26%;text-align: right;">
										{{$util.formatNumber(item.net_vol_foreigner)}}
									</view>
								</view>
							</block>
						</view>
					</template>
				</view>
			</view>

			<template v-if="isPireChart">
				<view style="background-color: #FEFFFF;margin:0 20rpx 30rpx 20rpx;padding:20rpx 0;">
					<CustomTitle :title="$lang.STOCK_TRADE_TREND_PIE_TITLE"></CustomTitle>

					<view class="list" style="margin:0px;padding:0 10px;border:none">
						<view class="flex flex-b">
							<canvas canvas-id="huan1" id="huan1" class="charts" />
						</view>
					</view>
				</view>
			</template>

			<view style="background-color: #FEFFFF;margin:0 20rpx 30rpx 20rpx;padding:20rpx 0;">
				<CustomTitle :title="$lang.STOCK_TRADE_SELL_EMPTY_TITLE"></CustomTitle>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<block v-for="(item,index) in $util.setSellEmptyData(stockInfo.top7)">
						<view
							style="flex:48%;margin: 6px;line-height: 2;padding:10px;border:1px solid #ededed;border-radius: 12rpx;">
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="font-size: 28rpx;font-weight: 700;color:#121212;">{{item.title}}</view>
							</view>
							<view style="font-size: 24rpx;">{{item.desc}}</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
								<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
									{{$util.formatNumber(item.amount)}}{{$lang.QUANTITY_UNIT}}
								</view>
								<view style="font-size:32rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
									{{$util.formatNumber(item.rate,2)}}%
								</view>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.5;color:#999999;">

								<view style="font-size: 24rpx;">{{item.dt}}</view>
							</view>

						</view>
					</block>
				</view>
			</view>

			<template v-if="isIndustry">
				<view style="background-color: #FEFFFF;margin:0 20rpx 30rpx 20rpx;padding:20rpx 0;">
					<CustomTitle :title="$lang.STOCK_INDUSTRY_TITLE">
						<view style="margin-left: auto;color:#999999;">
							{{$lang.STOCK_INDUSTRY_DESC}}
							{{stockInfo.top8.count}} {{$lang.STOCK_INDUSTRY_DESC_SUFFIX}}
						</view>
					</CustomTitle>

					<block v-for="(item,index) in $lang.STOCK_INDUSTRY_DATA_LABELS" :key="index">
						<StockIndustryItem :info="stockInfo.top8" :flag="index" :name="item"></StockIndustryItem>
					</block>
				</view>
			</template>
		</template>
	</view>
</template>

<script>
	import zhexian from '@/common/zhexian.js';
	import uCharts from '@/common/u-charts.js';
	import StockInfoBase from '@/components/stock/StockInfoBase.vue';
	import CompanyProfile from '@/components/stock/CompanyProfile.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import StockTradeTrend from '@/components/stock/StockTradeTrend.vue';
	import StockIndustryItem from '@/components/stock/StockIndustryItem.vue';

	var uChartsInstance = {};
	export default {
		name: 'InfoTwo',
		props: ['code', 'id'],
		components: {
			CustomTitle,
			StockInfoBase,
			CompanyProfile,
			TabsFifth,
			TabsSixth,
			StockTradeTrend,
			StockIndustryItem,
		},
		data() {
			return {
				stockInfo: null, // 单股概况
				curSales: 0, // 销售额tab选中项
				salesData: [], // 销售额
				formatSalesData: [], // 格式化销售额
				curSalesKline: 0, // 当前显示Kline数据
				curSalesKlinePos: 29, // 当前显示Kline的销售额数组中，下标值。(29:销售额;32:盈利;36:净利)
				cWidth: 750,
				cHeight: 500,
			}
		},
		computed: {
			// 是否有销售额
			isSales() {
				return this.stockInfo && this.salesData.length > 0;
			},
			// 是否显示行业排行
			isIndustry() {
				return this.stockInfo && this.stockInfo.top8 && Object.keys(this.stockInfo.top8).length > 0;
			},
			// 饼图
			isPireChart() {
				return this.stockInfo && this.stockInfo.top6.length > 0;
			}

		},

		created() {
			this.getStockInfo();
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(750);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
		},

		onLoad() {},
		methods: {
			// 设置样式
			setStyle(val) {
				return {
					backgroundColor: val ? '#E8EDFF' : '#F5F5F5',
					color: val ? this.$theme.PRIMARY : '#585858',
				}
			},

			// 季度年度 销售额切换
			changeSalesTab(val) {
				this.curSales = val;
				if (this.curSales == 0) {
					this.getStockInfo()
				} else {
					this.getStockInfoYear()
				}
			},

			// 销售额 Kline切换
			changeSalesKlineTab(val) {
				this.curSalesKline = val;
				this.curSalesKlinePos =
					this.curSalesKline == 1 ? 32 :
					this.curSalesKline == 2 ? 36 : 29;
				this.genKLine()
			},

			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "ring",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					fontSize: 13,
					fontColor: "#666666",
					dataLabel: true,
					dataPointShape: true,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: true,
						position: "right",
						lineHeight: 25,
						float: "left",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					// title: {
					//   name: "2,515억",
					//   fontSize: 15,
					//   color: "#666666",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					// subtitle: {
					//   name: "자산총계",
					//   fontSize: 25,
					//   color: "#7cb5ec",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					extra: {
						ring: {
							ringWidth: 30,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF",
							centerColor: "#FFFFFF",
							customRadius: 0,
							linearType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						}
					}
				});
			},

			async getStockInfo() {
				const result = await this.$http.get(`api/product/info_two`, {
					code: this.code,
					stock_id: this.id,
				});
				this.stockInfo = result.data[0];
				console.log('stockInfo:', this.stockInfo);
				this.salesData = this.stockInfo.top3; // 季度销售额
				if (this.isSales) {
					this.formatSalesData = this.$util.setSalesData(this.salesData, this.curSales);
					this.genKLine(); // 处理并显示折线数据
				}
				let res = {
					series: [{
						data: result.data[0].top6
					}]
				};
				this.drawCharts('huan1', res);
			},

			// 生成折线数据，并显示
			genKLine() {
				let res = {
					categories: this.salesData.map(item => item.report_year_month),
					series: [{
						name: "",
						data: this.salesData.map(item => item.fields[this.curSalesKlinePos].value / 100000000),
					}]
				};
				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(zhexian.Charts(ctx, res, this.cWidth, this.cHeight))
			},
			// 获取年度销售额
			async getStockInfoYear() {
				const result = await this.$http.get(`api/product/info_two1`, {
					code: this.code,
					stock_id: this.id
				})
				console.log('getStockInfoYear:', result);
				this.salesData = result.data[0].top3; // 年度销售额
				if (this.isSales) {
					this.formatSalesData = this.$util.setSalesData(this.salesData, this.curSales);
					this.changeSalesKlineTab(0)
				}
			},
		},
	}
</script>
<style scoped>
	.charts {
		width: 750rpx;
		height: 500rpx;
	}
</style>