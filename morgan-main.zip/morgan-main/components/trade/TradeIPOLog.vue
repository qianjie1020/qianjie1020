<template>
	<view style="padding: 10px;background-color: #FFFFFF;margin:20rpx;">
		<template v-if="!list || list.length<=0">
			<view class="common_block" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view :class="index==list.length-1?'':'line' "
					style="margin: 10rpx; word-wrap:break-word;padding: 10px;border-bottom: 1px solid #E5E5E5;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TEXT}" style="font-size: 32rpx;">{{item.goods.code}}</view>
						<view><text
								style="background-color: #f85252;color:#FFF;padding:2px;border-radius: 4px;">{{item.message }}</text>
						</view>
					</view>
					<view :style="{color:$theme.PRIMARY}" style="font-size: 36rpx;">{{item.goods.name}}</view>


					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[0]}}</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[4]}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.apply_amount)}}</view>
					</view>
					
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[1]}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.apply_num_amount)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[3]}}</view>
						<view :style="{color:$theme.PRIMARY}">{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_LOG_LABELS[2]}}</view>
						<view :style="{color:$theme.TIP}">{{item.order_sn}}</view> 
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPOLog",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/goods-shengou/user-Apply-Log`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>