<template>
	<view style="background-color: #FFFFFF;padding-bottom:30rpx;">
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx;padding: 20rpx 0; border-bottom: 1px solid #E5E5E5;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view>{{item.zt}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_DAY_BUY_AMOUNT}}</view>
						<view>{{$util.formatNumber(item.money)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LABEL}">{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}">{{$util.formatNumber(item.success)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LABEL}">
						<view>{{$lang.TRADE_DAY_ORDER_SN}}</view>
						<view>{{item.ordersn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
						:style="{color:$theme.LABEL}">
						<view>{{$lang.TRADE_DAY_CREATE_TIME}}</view>
						<view>{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getData();
		},
		methods: {
			// 申请列表
			async getData() {
				const result = await this.$http.get(`api/rinei/sq-list`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>