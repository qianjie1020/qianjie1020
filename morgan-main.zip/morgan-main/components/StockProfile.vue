<!-- 股票概况 -->
<template>
	<view style="margin:0 20px;padding-bottom: 10px; border-bottom: 1px solid #999;">
		<view v-for="(item,index) in info" :key="index" style="display: flex;align-items: center;">
			<view style="flex:30%;padding-left: 20px;" :style="{color:$theme.LABEL}">{{item.label}}
			</view>
			<view style="flex:70%;text-align: right;padding-right: 20px;" :style="{color:$theme.TEXT}">{{item.value}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "StockProfile",
		props: ['params'],
		data() {
			return {
				info: [],
			};
		},
		created() {
			this.getData();
		},
		methods: {
			async getData() {
				console.log(this.params);
				uni.showLoading({
					mask: true,
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_INFO_TOW, {
					code: this.params.code,
					stock_id: this.params.id
				})
				if (result.data.code == 0) {
					const temp = result.data.data[0].top1;
					this.info =[{
						label: '기업순위',
						value: `코스닥 ${temp.marketcap_rank} 위`
					}, {
						label: '주식수',
						value: `${this.$util.formatNumber(temp.sharesout)} 주`
					}, {
						label: '산업군',
						value: `${this.$util.formatNumber(temp.sector)}`
					}, {
						label: '52주 최고',
						value: `${this.$util.formatNumber(temp.year_high)}`
					}, {
						label: '평가금액',
						value: `${this.$util.formatNumber(temp.marketcap)} 억`
					}, {
						label: '외국인비중',
						value: `${this.$util.formatNumber(temp.foreigners_pie)}%`
					}, {
						label: '세부산업군',
						value: `${this.$util.formatNumber(temp.industry)}`
					}, {
						label: '52주 최저',
						value: `${this.$util.formatNumber(temp.year_low)}`
					}]
					uni.hideLoading()
				}
			}
		}
	}
</script>