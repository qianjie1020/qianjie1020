<template>
	<view style="display: flex;align-items: center;flex-wrap: wrap;padding:10rpx 0 10rpx 30rpx;">
		<block v-for="(item,index) in funcList" :key="index">
			<view style="flex:0 0 48%;">
				<view style="margin:0;padding:30rpx;height: 110rpx;text-align: center;" :style="setStyle(index)"
					@click="actionEvent(item,index)">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(40)"></image>
					<view style="text-align: center; font-size: 28rpx;color: #121212;padding: 20rpx 0 0 20rpx; ">
						{{item.name}}
					</view>
				</view>


				<!-- <view
					style="display: flex;align-items: center;margin:0;padding:30rpx;border-bottom: 1px solid #F1F1F1;height: 110rpx;"
					@click="actionEvent(item,index)">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(40)"></image>
					<text style="font-size: 28rpx;color: #121212;padding-left: 20rpx;">{{item.name}}</text>
				</view> -->
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'AccountCenterList',
		props: {
			info: {
				type: Object,
				default: []
			}
		},
		data() {
			return {};
		},
		computed: {
			// 是否实名
			authCode() {
				return this.info.is_check
			},
			// 设置实名状态
			setAuthStatus() {
				return this.$lang.ACCOUNT_AUTH_STATUS.map((item, index) => {
					return {
						name: item,
						url: this.$paths.ACCOUNT_AUTH,
						icon: 'authentication',
						code: index == 0 ? -1 : index == 1 ? 0 : 2,
					}
				}).filter(item => item.code == this.authCode);
			},
			// 设置功能组
			funcList() {
				console.log(this.setAuthStatus);
				return [...this.setAuthStatus, {
						name: this.$lang.ACCOUNT_CHANGE_PWD,
						url: this.$paths.ACCOUNT_PWD,
						icon: 'signin_pwd',
						mode: 'link',
					}, {
						name: this.$lang.ACCOUNT_CHANGE_PAY_PWD,
						url: this.$paths.ACCOUNT_PWD_PAY,
						icon: 'pay_pwd',
						mode: 'link',
					}, {
						name: this.$lang.ACCOUNT_CARD_MANAGEMENT,
						url: this.$paths.ACCOUNT_BANK_CARD,
						icon: 'bank_card',
						mode: 'link',
					},
					// {
					// 	name: this.$lang.ACCOUNT_NOMINEE,
					// 	url: this.$paths.ACCOUNT_NOMINEE,
					// 	icon: 'nominee',
					// 	mode: 'link',
					// }, {
					// 	name: this.$lang.CREDIT_SCORE,
					// 	url: this.$paths.ACCOUNT_CREDIT_SCORE,
					// 	icon: 'loan',
					// 	mode: 'link',
					// },
					{
						name: this.$lang.ACCOUNT_TRADE_LOG,
						url: this.$paths.ACCOUNT_TRADE_LOG,
						icon: 'capital_deatil',
						mode: 'link',
					},
					// {
					// 	name: this.$lang.PAGE_TITLE_AUTH,
					// 	url:this.$paths.ACCOUNT_AUTH,
					// 	icon: 'auth',
					// 	mode: 'link',
					// },
					{
						name: this.$lang.ABOUT_US,
						url: this.$paths.ABOUT_US,
						icon: 'about',
						mode: 'link',
					},
					{
						name: this.$lang.ACCOUNT_SERVICE,
						url: '',
						icon: 'center_service',
						mode: 'service',
					},

					// {
					// 	name: this.$lang.SIMGN_OUT,
					// 	url: '',
					// 	icon: 'sign_out',
					// 	mode: 'sign_out',
					// }
				];
			},
		},
		methods: {
			// 设置样式
			setStyle(val) {
				// 数组总长度，奇偶. 
				const lastPos = this.funcList.length % 2 === 0;
				console.log(lastPos);
				let temp = '';
				// 偶数：最后两个元素不含下边线
				if (lastPos) {
					temp = val < this.funcList.length - 2 ? `1px solid #F1F1F1` : 'none';
				} else {
					// 奇数： 只有最后一个元素不含下边线；
					temp = val < this.funcList.length - 1 ? `1px solid #F1F1F1` : 'none';
				}

				return {
					borderRight: val % 2 == 0 ? '1px solid #F1F1F1' : `none`, // 右边线					
					borderBottom: temp, // 下边线
				}
			},

			actionEvent(item, index) {
				if (item.mode == 'service') {
					this.$util.linkCustomerService();
					return false;
				}
				uni.navigateTo({
					url: item.url,
				})
			},
		}
	}
</script>