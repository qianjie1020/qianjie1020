<template>
	<view
		style="text-align: center;border:1px solid #242424;background-color: #F6F7FE;border-radius: 46rpx;color:#FF0101;padding:20rpx 0;margin:40rpx; font-size: 28rpx;"
		@click="handleSignOut()">
		{{$lang.SIMGN_OUT}}
	</view>
</template>

<script>
	export default {
		name: 'SignOut',
		methods: {
			// 登出
			async handleSignOut() {
				const result = await this.$http.get(`api/app/logout`);
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500);
			}
		}
	}
</script>

<style>
</style>