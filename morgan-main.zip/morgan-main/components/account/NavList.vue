<!-- 用于纵向导航，个人中心 -->
<template>
	<view style="padding: 6px;margin-top:10px;padding-top:10px;">
		<block v-for="(item,index) in funcList" :key="index">
			<view style="display: flex;align-items: center;margin:10px 0;padding-bottom: 10px;"
				@click="actionEvent(item,index)">
				<view style="flex: 12%;padding-left: 20px;">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(48)"></image>
				</view>
				<text style="flex: 78%;font-weight: 700;font-size: 15px;color: #333333;">{{item.name}}</text>
				<view style="flex: 10%;">
					<view class="arrow rotate_45" :style="{borderColor:'#333333',...$theme.setImageSize(12)}">
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: {
			info: {
				type: Object,
				default: []
			}
		},
		data() {
			return {};
		},
		computed: {
			// 是否实名
			authCode() {
				return this.info.is_check
			},
			// 设置实名状态
			setAuthStatus() {
				return this.$lang.ACCOUNT_AUTH_STATUS.map((item, index) => {
					return {
						name: item,
						url: this.$paths.ACCOUNT_AUTH,
						icon: 'authentication',
						code: index == 0 ? -1 : index == 1 ? 0 : 2,
					}
				}).filter(item => item.code == this.authCode);
			},
			// 设置功能组
			funcList() {
				console.log(this.setAuthStatus);
				return [...this.setAuthStatus, {
						name: this.$lang.ACCOUNT_CHANGE_PWD,
						url: this.$paths.ACCOUNT_PWD,
						icon: 'signin_pwd',
						mode: 'link',
					}, {
						name: this.$lang.ACCOUNT_CHANGE_PAY_PWD,
						url: this.$paths.ACCOUNT_PWD_PAY,
						icon: 'pay_pwd',
						mode: 'link',
					}, {
						name: this.$lang.ACCOUNT_CARD_MANAGEMENT,
						url: this.$paths.ACCOUNT_BANK_CARD,
						icon: 'bank_card',
						mode: 'link',
					},
					// {
					// 	name: this.$lang.ACCOUNT_NOMINEE,
					// 	url: this.$paths.ACCOUNT_NOMINEE,
					// 	icon: 'nominee',
					// 	mode: 'link',
					// }, {
					// 	name: this.$lang.CREDIT_SCORE,
					// 	url: this.$paths.ACCOUNT_CREDIT_SCORE,
					// 	icon: 'loan',
					// 	mode: 'link',
					// },
					{
						name: this.$lang.ACCOUNT_TRADE_LOG,
						url: this.$paths.ACCOUNT_TRADE_LOG,
						icon: 'capital_deatil',
						mode: 'link',
					},
					// {
					// 	name: this.$lang.PAGE_TITLE_AUTH,
					// 	url: this.$paths.ACCOUNT_AUTH,
					// 	icon: 'auth',
					// 	mode: 'link',
					// },
					{
						name: this.$lang.ABOUT_US,
						url: this.$paths.ABOUT_US,
						icon: 'about',
						mode: 'link',
					},
					{
						name: this.$lang.ACCOUNT_SERVICE,
						url: '',
						icon: 'center_service',
						mode: 'service',
					},
					// {
					// 	name: this.$lang.SIMGN_OUT,
					// 	url: '',
					// 	icon: 'sign_out',
					// 	mode: 'sign_out',
					// }
				];
			},
		},
		methods: {
			actionEvent(item, index) {
				if (item.mode == 'service') {
					this.$util.linkCustomerService();
					return false;
				}
				uni.navigateTo({
					url: item.url,
				})
			},
		}
	}
</script>