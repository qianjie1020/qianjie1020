<template>
	<header class="common_header">
		<view style="flex:1 0 8%;padding-right:30rpx;">
			<image src="/static/app_logo.png" mode="aspectFit" :style="$theme.setImageSize(68,68)">
			</image>
		</view>
		<template v-if="title!=''">
			<view class="header_title" :style="{color:color}">{{title}}</view>
		</template>
		<template v-if="isService">
			<image mode="aspectFit" src="/static/service_dark.png" :style="$theme.setImageSize(40)"
				@click="linkService()" style="padding-right: 20px;"></image>
		</template>
		<template v-if="isSearch">
			<SearchPrimary></SearchPrimary>
		</template>
		<!-- <template v-if="isLang">
			<Translate></Translate>
		</template> -->

		<template v-if="isAccount">
			<image mode="aspectFit" src="/static/account_center.png" style="padding-left: 20rpx;"
				:style="$theme.setImageSize(60)" @click="linkAccount()">
			</image>
		</template>
	</header>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import SearchPrimary from '@/components/search/SearchPrimary.vue';
	export default {
		name: 'HeaderPrimary',
		components: {
			Translate,
			SearchPrimary
		},
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#333333'
			},
			// 是否需要搜索
			isSearch: {
				type: Boolean,
				default: false,
			},
			// 是否需要客服
			isService: {
				type: Boolean,
				default: false,
			},
			// 是否需要语言
			isLang: {
				type: Boolean,
				default: false,
			},
			// 是否需要个人中心
			isAccount: {
				type: Boolean,
				default: false,
			}
		},
		methods: {
			// 跳转到个人中心
			linkAccount() {
				uni.switchTab({
					url: this.$paths.ACCOUNT_CENTER
				})
			},

			// // 跳转到客服
			// linkService() {
			// 	this.$util.linkCustomerService();
			// },
		}
	}
</script>