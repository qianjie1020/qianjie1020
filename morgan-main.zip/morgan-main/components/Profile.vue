<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;margin:20rpx 40rpx;" @click="handleLink()">
			<image style="border-radius: 100px;" mode="aspectFit" :src="info.avatar?info.avatar:'/static/avatar.png'"
				:style="$theme.setImageSize(120)"></image>
			<view style="flex:70%;margin-left: 20rpx;">
				<view style="font-size: 36rpx;text-align: left;padding-right: 30rpx;color:#FFFFFF" >
					{{info.real_name}}
				</view>
				<view style="font-size: 32rpx;text-align: left;color:#F8F8F8;padding-right: 30rpx;">
					{{info.p_mobile}}
				</view>
			</view>
			<view style="margin-left: auto;">
				<view class="arrow rotate_45" :style="{borderColor:'#FFFFFF',...$theme.setImageSize(12)}"></view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入信息修改页面
			handleLink() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AVATAR,
				})
			},
		}
	}
</script>

<style>

</style>