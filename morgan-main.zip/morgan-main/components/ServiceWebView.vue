<template>
	<view style="width: 100%;height: 100vh;">
		<web-view :src="src"></web-view>
	</view>
</template>

<script>
	export default {
		name: 'ServiceWebView',
		props: {
			mode: {
				type: String,
				default: ""
			}
		},
		data() {
			return {
				src: ""
			}
		},
		created() {
			this.getAppConfig();
		},
		methods: {
			async getAppConfig() {
				const result = await this.$http.get(`api/app/config`);
				console.log(result);
				if (result.code == 0) {
					const temp = result.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					// "CustomerLink"	"kakao"
					// this.list = [temp.get('CustomerLink'), temp.get("kakao")][this.code];
					this.src = temp.get(this.mode);
					console.log(this.src);
				}
			}
		}
	}
</script>
<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	iframe {
		width: 600px !important;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>