<template>
	<view class="empty">
		<image :src="`/static/empty_${img}.png`" mode="aspectFit" :style="$theme.setImageSize(400)"></image>
		<view :style="{color:color}">{{$lang.EMPTY_DATA}}</view>
	</view>
</template>

<script>
	export default {
		name: "EmptyData",
		props: {
			color: {
				type: String,
				default: '#121212',
			},
			// 空数据时，显示的图片
			img: {
				type: String,
				default: 'data'
			},
		},
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>