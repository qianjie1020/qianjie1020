import Vue from 'vue';
import {
	BASE_URL
} from '@/common/http.js';

// 客服跳转
// const linkService = async () => {
// 	const result = await Vue.prototype.$http.get(`api/app/config`);
// 	console.log('reslut:', result);
// 	console.log('window:', window);
// 	console.log('navigator:', navigator);
// 	// "CustomerLink" "kakao"
// 	if (result.code == 0) {
// 		const temp = result.data.reduce((map, item) => {
// 			map.set(item.key, item.value);
// 			return map;
// 		}, new Map());
// 		console.log('config:',temp);
// 		let url = "";
// 		// 弹层，客户选择客服系统
// 		const tempModal = await uni.showModal({
// 			title: Vue.prototype.$lang.BTN_SEND_SERVICE,
// 			content: Vue.prototype.$lang.SERVICE_MODAL_CONTENT,
// 			cancelText: 'Line',
// 			confirmText: '고객센터',
// 			confirmColor: '#042eb4',
// 			cancelColor: '#1c829b',
// 		});
// 		console.log('异步弹层:', tempModal);
// 		if (tempModal[1].confirm) {
// 			url = temp.get('CustomerLink'); // 视为 Kakao
// 		} else if (tempModal[1].cancel) {
// 			url = temp.get('kakao'); // 视为 Line
// 		}

// 		console.log('url:', url);

// 		// let url = temp.get('CustomerLink');

// 		if (window.android) {
// 			window.android.callAndroid("open," + url)
// 			return false;
// 		}
// 		if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
// 			.nativeExt) {
// 			window.webkit.messageHandlers.nativeExt.postMessage({
// 				msg: 'open,' + url
// 			})
// 			return false;
// 		}
// 		let u = navigator.userAgent;
// 		let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
// 		if (isiOS) {
// 			// return "222";
// 			window.location.href = url;
// 			return false;
// 		}
// 		window.open(url)
// 	}
// }

// /*
// 跳转到客服，内部分为两种方式：
// 1. 直接跳转到软件内客服页面
// 2. 调用客服跳转函数，用于上架
// */
// const linkCustomerService = () => {
// 	// 1. 直接跳转到软件内客服页面
// 	uni.navigateTo({
// 		url: Vue.prototype.$paths.SERVICE
// 	});
// 	let url =
// 		"https://chatlink.wchatlink.com/widget/standalone.html?eid=8845de6fb119a18c17ab1bc176a8ec05&language=ko";

// 	if (window.android) {
// 		window.android.callAndroid("open," + url)
// 		return false;
// 	}
// 	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
// 		.nativeExt) {
// 		window.webkit.messageHandlers.nativeExt.postMessage({
// 			msg: 'open,' + url
// 		})
// 		return false;
// 	}
// 	let u = navigator.userAgent;
// 	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
// 	if (isiOS) {
// 		window.location.href = url;
// 		return false;
// 	}
// 	window.open(url)

// 	// 2.调用客服跳转函数，用于上架
// 	linkService();
// }

// 客服跳转 读取系统配置客服url，外部打开。
const linkService = async () => {
	const result = await Vue.prototype.$http.get(`api/app/config`);
	console.log(`?`, result);
	// if (!result) return false;
	let url = '';
	if (result && result.code == 0) {
		const temp = result.data.reduce((map, item) => {
			map.set(item.key, item.value);
			return map;
		}, new Map());
		url = temp.get('CustomerLink');
	}

	if (window.android) {
		window.android.callAndroid("open," + url)
		return false;
	}
	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
		.nativeExt) {
		window.webkit.messageHandlers.nativeExt.postMessage({
			msg: 'open,' + url
		})
		return false;
	}
	let u = navigator.userAgent;
	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if (isiOS) {
		window.location.href = url;
		return false;
	}
	window.open(url)
}

/*
跳转到客服，：
	上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	正常模式：`line`(跳轉到外鏈頁面)，`第三方`(跳轉内頁)
*/
const linkCustomerService = () => {
	// 上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	// uni.showToast({
	// 	title: Vue.prototype.$lang.SERVICE_CONTACT_MANAGER,
	// 	icon: 'none'
	// });

	// 正常模式：`line`(跳轉到外鏈頁面)
	// linkService();

	// 正常模式：`第三方`(跳轉内頁)
	uni.navigateTo({
		url: Vue.prototype.$paths.SERVICE
	});
}

// 计算设计图上带有透明度的值输出为RGBA
const RGBConvertToRGBA = (hexColor, opacity) => {
	const r = parseInt(hexColor.slice(1, 3), 16);
	const g = parseInt(hexColor.slice(3, 5), 16);
	const b = parseInt(hexColor.slice(5, 7), 16);
	const a = opacity / 100;
	return `rgba(${r},${g},${b},${a})`;
};

// 数字值格式化
const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
		backgroundColor: !isbg ? '' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
	}
};

// 负数取绝对值
const formatMathABS = (val) => {
	return Math.abs(val);
}

// 对象嵌套转数组对象。当前用于市场指标返回数据，将其从对象转为数组对象
const ObjectConvertArray = (obj) => {
	return Object.values(obj);
};

export default {
	linkCustomerService,
	RGBConvertToRGBA,
	ObjectConvertArray,
	formatNumber,
	setStockRiseFall,
	formatMathABS,

	// 切换底部导航文字多语言
	switchTabBar: () => {
		const TABBAR = [
			Vue.prototype.$lang.TABBAR_HOME,
			Vue.prototype.$lang.TABBAR_FOLLOW,
			Vue.prototype.$lang.TABBAR_MARKET,
			Vue.prototype.$lang.TABBAR_TRADE_D,
			Vue.prototype.$lang.TABBAR_ACCOUNT
		];
		// 遍历底部导航，逐一换成当前语言
		for (let i = 0; i <= 5; i++) {
			uni.setTabBarItem({
				index: i,
				text: TABBAR[i],
			})
		}
	},

	// 设置input的placeholder样式
	setPlaceholder: (color = '', fontsize = '') => {
		return `color:${color == '' ? Vue.prototype.$theme.PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
	},

	// 设置图片尺寸（自定义size）
	setImageSize: (w = 0, h = 0) => {
		const _w = w > 0 ? w : 20;
		const _h = h > 0 ? h : _w;
		return {
			width: `${_w}rpx`,
			// 若为设置h值，则视为高=宽
			height: `${_h}rpx`,
		};
	},
	// 设置页面背景,返回style对象，动态替换页面背景图
	setPageBG: (url) => {
		return {
			backgroundImage: `url(/static/${url}.png)`,
			backgroundSize: '100% auto',
			backgroundRepeat: 'no-repeat',
			backgroundPosition: '0 -32rpx',
		}
	},

	// 根据传入值，求出进度条元素宽度
	setProgress: (val, max) => {
		// 模拟数据所需，实际数据不会出现
		const result = max - val < 0 ? 0 : (val / max) * 100;
		console.log(result);
		return {
			// backgroundImage: `url(/static/progress.png)`,
			// backgroundSize: 'auto',
			// backgroundRepeat: 'repeat',
			// backgroundPosition: '0 -7px',
			backgroundImage: 'linear-gradient(-90deg, #F5B71C, rgba(255,255,255,0.8))',
			width: `${result}%`,
			height: '100%',
			borderRadius: `12px`,
		}
	},
	// 根据传入值，求出进度条元素宽度 v:是否垂直
	setProgressToTop: (val) => {
		return {
			backgroundImage: 'linear-gradient(-180deg,  rgba(255,255,255,0.8),#F5B71C)',
			width: `100%`,
			height: `${val}%`,
		}
	},

	formatDate: (timeString) => {
		// console.log('fmt:',fmt);
		const date = new Date(timeString);
		const year = date.getUTCFullYear();
		const month = String(date.getUTCMonth() + 1).padStart(2, '0');
		const day = String(date.getUTCDate()).padStart(2, '0');
		const h = String(date.getUTCHours()).padStart(2, '0');
		const m = String(date.getUTCMinutes()).padStart(2, '0');
		const s = String(date.getUTCSeconds()).padStart(2, '0');
		// return `${year}.${month}.${day} ${h}:${m}:${s}`;
		return `${year}.${month}.${day}`;
	},
	// 首页股票列表与关注页面列表，通用表头
	setStockListThead: () => {
		const labels = Vue.prototype.$lang.STOCK_THEAD;
		let theads = [];
		for (let i = 0; i <= 2; i++) {
			theads.push({
				label: labels[i] + `${i!=1? '':`[${Vue.prototype.$lang.CURRENCY_UNIT}]`}`,
				width: i == 0 ? '40%' : i == 1 ? '30%' : '20%',
				align: [2].includes(i) ? 'center' : [1].includes(i) ? 'right' : '',
			})
		}
		return theads;
	},
	// 部分页面需要拼接股票完整LOGO的url
	setLogo: (url) => {
		if (url.includes('http')) {
			return url;
		} else {
			return BASE_URL + url
		}
	},
	// 设置TAB激活状态
	setTabActive: (active = true) => {
		return {
			color: active ? Vue.prototype.$theme.PRIMARY : Vue.prototype.$theme.TIP,
			borderBottom: active ? `3px solid ${ Vue.prototype.$theme.PRIMARY}` : '',
			// backgroundColor: active ? '#03327857' : '',
		}
	},
	setTabSecondActive: (active = true, bg = '') => {
		return {
			color: active ? '#FFFFFF' : '#666',
			backgroundColor: active ? '#EBBD33' : bg,
		}
	},
	setTabThird: (active = true) => {
		return {
			color: active ? Vue.prototype.$theme.PRIMARY : Vue.prototype.$theme.TEXT,
			borderBottom: `3px solid ${active ? Vue.prototype.$theme.PRIMARY:'transparent'}`,
		}
	},

	// 设置交易记录中， 提现记录，每条数据状态明文
	setWithdrawLogStatus: (code = 0) => {
		const temp = [{
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[0],
			icon: '/static/audit.png',
			color: '#FF6700'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[1],
			icon: '/static/success.png',
			color: '#00B45A'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[2],
			icon: '/static/failed.png',
			color: '#00A9DE'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[3],
			icon: '/static/refuse.png',
			color: '#f56a6a'
		}];
		return temp[code];
	},

	// sales (数据，销售额类型)
	setSalesData: (data, type) => {
		console.log('当前销售额：', data, type);
		return [{
			label: Vue.prototype.$lang.STOCK_SALES_TITLE[0],
			amount: data[0].fields[29].value / 100000000,
			rate: data[0].fields[type == 1 ? 43 : 42].value,
		}, {
			label: Vue.prototype.$lang.STOCK_SALES_TITLE[1],
			amount: data[0].fields[32].value / 100000000,
			rate: data[0].fields[type == 1 ? 82 : 81].value,
		}, {
			label: Vue.prototype.$lang.STOCK_SALES_TITLE[2],
			amount: data[0].fields[36].value / 100000000,
			rate: data[0].fields[type == 1 ? 84 : 83].value,
		}];
	},
	// 设置卖空量数据
	setSellEmptyData: (data) => {
		return [{
			title: Vue.prototype.$lang.STOCK_TRADE_SELL_EMPTY_ITEM_TITLES[0],
			desc: Vue.prototype.$lang.STOCK_TRADE_SELL_EMPTY_ITEM_DESC[0],
			amount: data[0].short_volume,
			rate: data[0].short_volume_weight,
			dt: data[0].dt
		}, {
			title: Vue.prototype.$lang.STOCK_TRADE_SELL_EMPTY_ITEM_TITLES[1],
			desc: Vue.prototype.$lang.STOCK_TRADE_SELL_EMPTY_ITEM_DESC[1],
			amount: data[1].short_volume,
			rate: data[1].short_volume_weight,
			dt: data[1].dt
		}]
	}
}

// // 折线图 StockLineChart 
// // 饼状图 StockPieChart

// // 销售额 StockSales
// // 投资者交易趋势 TradeTrend
// // 卖空量 ShortSellVol


// // 日内交易说明


// const calcPageHeight = () => {
// 	const systemInfo = uni.getSystemInfoSync();
// 	const tabBarHeight = systemInfo.screenHeight - systemInfo.windowHeight;
// 	return systemInfo.screenHeight - tabBarHeight;
// };

// const BTNS_IPO = ['청약 신청', '구독기록', '우승기록'];