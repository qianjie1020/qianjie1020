import Vue from 'vue';
import {
	ACCOUNT_ACCESS
} from '@/common/paths.js';
import md5 from 'js-md5';

export const BASE_URL = `https://api.apollostock.xyz`;

const CODE = "Qwd3N5yp";

async function http(url, params = {}) {
	console.log('url:', url, 'params:', params);
	const token = uni.getStorageSync("token") || '';
	const headers = {
		"Content-Type": "application/x-www-form-urlencoded",
		// 处理携带token
		"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
		"language": uni.getStorageSync('lang') || 'en', // 'zh-Hans'
	};
	const time = parseInt(new Date().getTime() / 1000);
	const str_url = `/${url}`.toLowerCase();
	const mdd = md5(`XPFXMedS${CODE + str_url + time}`);

	try {
		const response = await uni.request({
			url: `${BASE_URL}/${url}?sign=${mdd}&t=${time}`,
			method: params.method || 'GET',
			data: params.data || {},
			header: headers
		});
		// console.log('response:', response);
		let [err, res] = response;
		if (res && res.statusCode == 200) {
			if (res.data.code === 999) {
				uni.clearStorageSync();
				uni.$u.toast(Vue.prototype.$lang.API_TOKEN_EXPIRES);
				uni.$u.sleep(1000).then(() => {
					uni.navigateTo({
						url: Vue.prototype.$paths.ACCOUNT_ACCESS
					});
				})
				return false;
			}
			return res.data;
		} else {
			uni.$u.toast(Vue.prototype.$lang.STATUS_HTTP_ERROR);
		}
	} catch (error) {
		// console.log(error);
		throw error;
	}
};

// 外部调用，模拟整理前写法。
const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}

export default {
	http,
	get,
	post,
};


uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})