<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <header class="header">
			<view class="left">
				<image src="/static/logo_name.png" mode="aspectFit" :style="$theme.setImageSize(220,60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text>
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header> -->

		<view
			style="margin: 48rpx 40rpx 20rpx 40rpx;border:4rpx solid #38AA9A;border-radius: 44rpx;display: flex;align-items: center;justify-content: space-between;">
			<block v-for="(item,index) in tabs" :key='index'>
				<view :style="setStyleTab(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<template v-if="curTab==0">
			<view style="display: flex;align-items: center;justify-content: center;margin-top: 28rpx;">
				<view class="common_card_bg card_bg_0" style="width: 86%;">
					<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
				</view>
			</view>

			<view style="display: flex;align-items: center; justify-content: space-around;margin:30rpx 60rpx;">
				<view :style="setStyle(false)" @click="linkDeposit()">
					<image src="/static/center_left.png" mode="aspectFit" :style="$theme.setImageSize(28)"
						style="padding-right: 40rpx;"></image>
					{{$lang.DEPOSIT_TITLE}}
				</view>
				<view :style="setStyle(true)" @click="linkWithdraw()">
					<image src="/static/center_right.png" mode="aspectFit" :style="$theme.setImageSize(28)"
						style="padding-right: 40rpx;"></image>
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>

			<view style="background-color:#F8F8F8;padding:32rpx;border-radius: 8rpx;margin:0 20rpx">
				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.4;">
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_TOTAL_BUY_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(userInfo.frozen)}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_VALUATION_GAIN_LOSS}}
						</view>
						<view style="font-size:28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(userInfo.holdYingli)}}
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.4;">
					<view style="flex: 1 0 45%;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.ACCOUNT_AMOUNT_TOTAL}}
						</view>
						<view style="font-size:28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(userInfo.totalZichan)}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_TOTAL_GAIN}}
						</view>
						<view style="font-size:28rpx;text-align: right;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(userInfo.totalYingli)}}
						</view>
					</view>
				</view>
			</view>

			<view style="margin:10rpx 40rpx;">
				<TitleThird :title="$lang.TRADE_TITLE">
					<view style="font-size: 13px;margin-left: auto;" @click="changeTab(1)"
						:style="{color:$theme.PRIMARY}">
						{{$lang.MORE}}
						<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)">
						</image>
					</view>
				</TitleThird>
			</view>

			<AccountTradeHoldList ref="hold1"></AccountTradeHoldList>
		</template>

		<template v-else-if="curTab==1">
			<AccountTradeHoldList ref="hold"></AccountTradeHoldList>
		</template>
		<template v-else>
			<AccountTradeSellList ref="sell"></AccountTradeSellList>
		</template>
	</view>
</template>

<script>
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import TitleThird from '@/components/title/TitleThird.vue';
	import AccountTradeHoldList from './components/AccountTradeHoldList.vue';
	import AccountTradeSellList from './components/AccountTradeSellList.vue';

	export default {
		components: {
			CardItemPrimary,
			TitleThird,
			AccountTradeHoldList,
			AccountTradeSellList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 
				list: [],
				userInfo: {},
				cardData: {},
			}
		},
		computed: {
			tabs() {
				return [
					this.$lang.TRADE_TITLE,
					this.$lang.TRADE_HOLD_LOG,
					this.$lang.TRADE_SELL_LOG,
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
		},

		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		// 觸底加載
		onReachBottom() {
			if (this.curTab == 0 && this.$refs.hold1) {
				console.log(this.$refs.hold1);
				if (this.$refs.hold1.curPage < this.$refs.hold1.maxPage) {
					this.$refs.hold1.curPage++;
					this.$refs.hold1.getList();
				}
			}
			if (this.curTab == 1 && this.$refs.hold) {
				console.log(this.$refs.hold);
				if (this.$refs.hold.curPage < this.$refs.hold.maxPage) {
					this.$refs.hold.curPage++;
					this.$refs.hold.getList();
				}
			}
			if (this.curTab == 2 && this.$refs.sell) {
				console.log(this.$refs.sell);
				if (this.$refs.sell.curPage < this.$refs.sell.maxPage) {
					this.$refs.sell.curPage++;
					this.$refs.sell.getList();
				}
			}
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo();
			if (this.$refs.hold1) {
				this.$refs.hold1.curPage = 1;
				this.$refs.hold1.list = [];
				this.$refs.hold1.getList();
			}
			if (this.$refs.hold) {
				this.$refs.hold.curPage = 1;
				this.$refs.hold.list = [];
				this.$refs.hold.getList();
			}
			if (this.$refs.sell) {
				this.$refs.sell.curPage = 1;
				this.$refs.sell.list = [];
				this.$refs.sell.getList();
			}
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
			},

			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: result.money || 0, // 可提
					value2: result.freeze || 0, // 冻结
					value3: result.totalZichan || 0, // 总资产
				};
			},

			setStyle(val) {
				return {
					color: val ? '#FFFFFF' : this.$theme.PRIMARY,
					borderRadius: `16rpx`,
					border: `4rpx solid #38AA9A`,
					padding: `16rpx 32rpx`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					minWidth: `160rpx`,
				}
			},

			// 设置样式
			setStyleTab(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>