<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <header class="header">
			<view class="left">
				<image src="/static/logo_name.png" mode="aspectFit" :style="$theme.setImageSize(220,60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text>
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header> -->

		<view
			style="margin: 48rpx 40rpx 20rpx 40rpx;border:4rpx solid #38AA9A;border-radius: 44rpx;display: flex;align-items: center;justify-content: space-between;">
			<block v-for="(item,index) in $lang.MARKET_TABS" :key='index'>
				<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>


		<view :class="setClass" style="padding-top:0; margin:20rpx;min-height: 100vh;">
			<TabOne v-if="curTab==0" ref="tab0"></TabOne>

			<template v-if="curTab==1">
				<MarketHot :list="hotList" @action="handleHotList" @actfollow="handleFollow"></MarketHot>
			</template>
			<template v-if="curTab==2">
				<MarketKPI :list="kpiList" @action="handleKpiList"></MarketKPI>
			</template>
			<template v-if="curTab==3">
				<MarketNews></MarketNews>
			</template>

		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabOne from './components/TabOne.vue'
	import MarketHot from './components/MarketHot.vue'
	import MarketKPI from './components/MarketKPI.vue'
	import MarketNews from './components/MarketNews.vue';

	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			TabOne,
			MarketHot,
			MarketKPI,
			MarketNews
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
				// timer: null,
				hotList: [], // 热门股票
				kpiList: [], // 指标
				curHotTab: 0, // 热门 当前tab
				curKpiTab: 0, // 指标 当前tab
			}
		},
		computed: {
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},
		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
				// this.changeTab(this.curTab);
			}
		},
		onShow() {
			this.isAnimat = true;
			console.log('onShow', this.$refs.tab0);
			// if (this.$refs.tab0) {
			// 	this.$refs.tab0.onSetTimeout();
			// }
			this.changeTab(this.curTab);
		},
		onReady() {
			console.log('onReady', this.$refs.tab0);
		},
		onHide() {
			this.isAnimat = false;
			console.log('onHide', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},
		deactivated() {
			console.log('deactivated', this.$refs.tab0);
			if (this.$refs.tab0) {
				this.$refs.tab0.clearTimer();
			}
		},

		methods: {
			changeTab(val) {
				if (this.$refs.tab0) {
					this.$refs.tab0.clearTimer();
				}
				this.curTab = val;
				if (this.curTab == 0) {
					if (this.$refs.tab0) {
						this.$refs.tab0.onSetTimeout();
					}
				}
				if (this.curTab == 1) this.getHotList();
				if (this.curTab == 2) this.getKpiList();
			},

			handleHotList(val) {
				this.curHotTab = val;
				if (this.curTab == 1) this.getHotList();
			},
			handleKpiList(val) {
				this.curKpiTab = val;
				if (this.curTab == 2) this.getKpiList();
			},

			// 热门
			async getHotList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/goods/paihang`, {
					current: this.curHotTab
				})
				if (!result) return false;
				console.log(result);
				this.hotList = result.length <= 0 ? [] : result.map(item => {
					return {
						logo: item.logo || '',
						name: item.ko_name || '',
						code: item.code,
						price: item.close || 0,
						rate: item.returns || 0,
						follow: item.sc,
						gid: item.gid,
					}
				});
			},

			// 指标
			async getKpiList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/zhibiao`, {
					current: this.curKpiTab
				})
				// console.log('result, result);
				if (!result) return false;
				this.kpiList = Object.values(result).map(item => {
					return {
						logo: item.logo,
						name: item.ko_name,
						code: item.code,
						price: item.close,
						rate: item.returns,
						follow: item.sc,
						gid: item.gid,
						close: item.close,
					}
				});
			},

			// 设置样式
			setStyle(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>