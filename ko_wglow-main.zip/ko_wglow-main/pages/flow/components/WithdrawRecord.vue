<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="text-align: right;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_WITHDRAW_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.money)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_ORDER_SN}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;color:#333333;">
							{{item.order_sn}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_CREATE_TIME}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>

					<template v-if="item.reason && item.reason.length>0">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">{{$lang.LOG_TRADE_DESC}}</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:10%;"></view>
							<text style="white-space:pre-wrap;text-align: right;color:#666;">{{item.reason}}</text>
						</view>
					</template>

					<view style="display: flex;align-items: center;">
						<view style="color: #666666;font-size: 24rpx;padding-right: 40rpx;">{{$lang.LOG_STATUS}}</view>
						<view style="flex:1 0 auto;">
							<template v-if="item.status==0">
								<view style="display: flex;align-items: center;">
									<view
										style="background-color: #FFB044;font-size: 20rpx;color:#FFFFFF;text-align: center;padding:4rpx 16rpx;border-radius: 8rpx;">
										검토 중</view>
									<view style="color:#FFB044;margin-left: auto;padding:6rpx 0;"
										@click="handleCancel(item.id)">
										{{$lang.BTN_CANCEL}}
										<image src="/static/arrow_right1.png" mode="aspectFit"
											:style="$theme.setImageSize(20)">
										</image>
									</view>
								</view>
							</template>
							<template v-if="item.status==1">
								<view style="display: flex;align-items: center;">
									<!-- <view :style="item.style"> {{item.text}} </view> -->
								</view>
							</template>
							<template v-if="item.status==2">
								<view style="display: flex;align-items: center;">
									<view
										style="background-color: #FF2D30;font-size: 20rpx;color:#FFFFFF;text-align: center;padding:4rpx 16rpx;border-radius: 8rpx;">
										감사 실패</view>
									<view style="color:#FF2D30;margin-left: auto;padding:6rpx 0;"
										@click="handleService()">
										{{$lang.BTN_SEND_SERVICE}}
										<image src="/static/arrow_right2.png" mode="aspectFit"
											:style="$theme.setImageSize(20)">
										</image>
									</view>
								</view>
							</template>
							<template v-if="item.status==3">
								<view style="display: flex;align-items: center;">
									<!-- <view :style="item.style"> {{item.text}} </view> -->
								</view>
							</template>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'WithdrawRecord',
		components: {
			EmptyData
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},

			// 取消提现
			async handleCancel(id) {
				const result = await uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.cancelWithdraw(id);
				}
			},

			async cancelWithdraw(id) {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'none',
				});
				const result = await this.$http.post(`api/app/qx`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});

				setTimeout(() => {
					this.$emit('action', 1);
				}, 1000);
			},
		}
	}
</script>

<style>
</style>