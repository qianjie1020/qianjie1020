<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_DW}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.money)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_AMOUNT_AFTER}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;color:#333333;">
							{{$util.formatMoney(item.after)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_AMOUNT_BEFORE}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;color:#333333;">
							{{$util.formatMoney(item.before)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.LOG_TRADE_CREATE_TIME}}
						</view>
						<view style="font-size: 28rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>

					<template v-if="item.desc && item.desc.length>0">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">{{$lang.LOG_TRADE_DESC}}</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:10%;"></view>
							<text style="white-space:pre-wrap;text-align: right;color:#666;">{{item.desc}}</text>
						</view>
					</template>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeRecord',
		components: {
			EmptyData
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
	}
</script>

<style>
</style>