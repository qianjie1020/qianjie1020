<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.NOTIFY_TITLE}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<template v-if="!info">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding:20rpx 40rpx;line-height: 1.8;">
				<view style="font-size: 32rpx;font-weight: 700; text-align: center;" :style="{color:$theme.SECOND}">
					{{info.biaoti}}
				</view>
				<view style="font-size: 24rpx;text-align: right;" :style="{color:$theme.LOG_LABEL}">
					{{$util.formatDate(info.updated_at)}}
				</view>

				<view v-html="info.xiangqing"></view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			EmptyData
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				id: 0,
				info: null,
			}
		},
		onLoad(opt) {
			this.id = opt.id || 0;
		},
		onShow() {
			this.isAnimat = true;
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getData();
			uni.stopPullDownRefresh();
		},
		methods: {
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/app/gginfo`, {
					id: this.id
				});
				if (!result) return false;
				console.log(`result:`, result);
				this.info = result;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>