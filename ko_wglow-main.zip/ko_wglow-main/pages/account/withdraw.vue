<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.WITHDRAW_TITLE}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_1" style="width: 80%;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>




		<!-- <view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view> -->

		<view style="padding:30px  20px 10px 20px;">
			<view style="position: relative;height: 60rpx;color:transparent;width: max-content;padding: 0 24rpx;">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
				<view
					style="position: absolute;bottom: 20rpx;left: 0;right: 0;height: 16rpx;width: 100%; background-image:linear-gradient(90deg,#FF2D30,#FF2D30);border-radius: 16rpx;">
				</view>
				<view
					style="position: absolute;top:0; left: 0;right: 0;font-size: 32rpx;font-weight: 800;width: 100%;text-align: center;color:#333333;">
					{{$lang.WITHDRAW_WITH_AMOUNT}}
				</view>
			</view>

			<view class="common_input_wrapper" style="padding-left: 40rpx;">
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper" style="margin-bottom:0;padding-left: 40rpx;">
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.TIP_WITHDRAW_PWD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
		</view>

		<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: #FF2D30;border:none;"
			@click="handleSubmit()">
			{{$lang.BTN_CONFIRM}}
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 28rpx;font-weight: 700;text-align: center;padding-bottom: 20rpx;"
				:style="{color:$theme.LOG_LABEL}">
				{{$lang.WITHDRAW_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT">
				<view style="line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			CardItemPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: uni.getStorageSync('show') || false,
				showAmount: uni.getStorageSync('show') || false,
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
				cardData: {},
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_AMOUNT_TOTAL
				];
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
				this.$util.setShowData(this.showAmount);
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.TIP_AMOUNT_WITHDRAW,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/withdraw`, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				});
				if (!result) return false;
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.FLOW_INDEX + `?code=2`,
					})
				}, 1000)

			},
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO,
				})
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: result.money || 0, // 可提
					value2: result.freeze || 0, // 冻结
					value3: result.totalZichan || 0, // 总资产
				};
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 40rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>