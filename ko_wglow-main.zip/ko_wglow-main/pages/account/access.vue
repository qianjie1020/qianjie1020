<template>
	<view class="access_bg" :class="isAnimat?'fade_in':'fade_out'">
		<view :class="isSignIn?'signin':'signout'">
			<view
				style="display: flex;align-items: center;justify-content: center;flex-direction: column;height: 440rpx;">
				<image src='/static/access_logo.png' :style="$theme.setImageSize(240,220)">
				</image>
			</view>
		</view>

		<view :class="isSignIn?'right_in':'left_in'"
			style="margin: 30rpx;padding:30rpx;margin-top: 0;padding-bottom: 200rpx;">
			<view style="font-size: 40rpx;font-weight: 700; text-align: center;color:#333333;line-height: 2.4;">
				{{isSignIn?$lang.SIGN_IN_TITLE:$lang.SIGN_UP_TITLE}}
			</view>

			<!-- 手机号登录及注册 -->
			<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
				<template v-if="isSignIn">
					<image src="/static/account_name.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				</template>
				<template v-else>
					<image src="/static/account_name1.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				</template>

				<input v-model="user" type="number" :placeholder="$lang.ACCOUNT_NAME" maxlength="11"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<!-- 通用的输入密码 -->
			<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
				<template v-if="isSignIn">
					<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
				</template>
				<template v-else>
					<image src="/static/account_password1.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
				</template>
				<template v-if="isShow">
					<input v-model="password" type="text" :placeholder="$lang.ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="password" type="password" :placeholder="$lang.ACCOUNT_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>

				<template v-if="isSignIn">
					<image :src="`/static/icon_${isShow?'show':'hide'}_0.png`" mode="aspectFit"
						:style="$theme.setImageSize(32)" @click="toggleShow">
					</image>
				</template>
				<template v-else>
					<image :src="`/static/icon_${isShow?'show':'hide'}_1.png`" mode="aspectFit"
						:style="$theme.setImageSize(32)" @click="toggleShow">
					</image>
				</template>
			</view>

			<!-- 注册所需 -->
			<template v-if="!isSignIn">
				<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
					<template v-if="isSignIn">
						<image src="/static/account_password.png" mode="aspectFit" :style="$theme.setImageSize(40)">
						</image>
					</template>
					<template v-else>
						<image src="/static/account_password1.png" mode="aspectFit" :style="$theme.setImageSize(40)">
						</image>
					</template>
					<template v-if="isShow">
						<input v-model="verifyPassword" type="text" :placeholder="$lang.VERIFY_ACCOUNT_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>
					<template v-else>
						<input v-model="verifyPassword" type="password" :placeholder="$lang.VERIFY_ACCOUNT_PASSWORD"
							:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
					</template>

					<template v-if="isSignIn">
						<image :src="`/static/icon_${isShow?'show':'hide'}_0.png`" mode="aspectFit"
							:style="$theme.setImageSize(32)" @click="toggleShow">
						</image>
					</template>
					<template v-else>
						<image :src="`/static/icon_${isShow?'show':'hide'}_1.png`" mode="aspectFit"
							:style="$theme.setImageSize(32)" @click="toggleShow">
						</image>
					</template>
				</view>

				<view class="common_input_wrapper" style="margin-bottom: 40rpx;">
					<image src="/static/account_code.png" mode="aspectFit" :style="$theme.setImageSize(40)">
					</image>
					<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</view>
			</template>

			<!-- 记住密码，以及登入注册的切换 -->
			<view style="display: flex;align-items: center;justify-content: flex-end;margin-bottom: 40rpx;">
				<template v-if="isSignIn">
					<u-checkbox-group>
						<!-- circle -->
						<u-checkbox shape="" :activeColor="isSignIn?$theme.PRIMARY:$theme.SECOND"
							:label="$lang.TIP_REMEMBER_PWD" v-model="isRemember" labelColor="#666666" labelSize="24rpx"
							@change="changeRemember" :checked="isRemember" iconColor="#FFFFFF"></u-checkbox>
					</u-checkbox-group>
				</template>

				<view style="margin-left: auto;">
					<view style="display: flex;align-items: center;justify-content: center;">
						<template v-if="isSignIn">
							<view @click="changeTab(1)" :style="{color:$theme.PRIMARY}">
								{{$lang.SIGN_IN_TITLE}}
							</view>
						</template>
						<template v-else>
							<view @click="changeTab(0)" :style="{color:$theme.SECOND}">
								{{$lang.SIGN_UP_TITLE}}
							</view>
						</template>

						<template v-if="isSignIn">
							<image src="/static/arrow_right.png" mode="aspectFit" :style="$theme.setImageSize(24)">
							</image>
						</template>
						<template v-else>
							<image src="/static/arrow_right1.png" mode="aspectFit" :style="$theme.setImageSize(24)">
							</image>
						</template>
					</view>
				</view>
			</view>

			<!-- 通用按钮 已包含相关逻辑判断 -->
			<view class="common_btn" @click="handleConfirm()" style="margin:120rpx auto;border: none;"
				:style="{backgroundColor:isSignIn?$theme.PRIMARY:$theme.SECOND}">
				{{isSignIn?$lang.BTN_SIGN_IN:$lang.BTN_SIGN_UP}}
			</view>
		</view>

		<view style="position: fixed;left: 0;right: 0;bottom: 0;background-color: #FFFFFF;">
			<!-- 隐私协议 -->
			<view style="display: flex;align-items: center;justify-content: center;margin: 48rpx 0;">
				<view>
					<u-checkbox-group>
						<u-checkbox shape="" :activeColor="isSignIn?$theme.PRIMARY:$theme.SECOND"
							:label="$lang.TIP_AGREE" v-model="isAgree" labelColor="#333333" labelSize="24rpx"
							@change="changeAgree" :checked="isAgree" iconColor="#FFFFFF"></u-checkbox>
					</u-checkbox-group>
				</view>
				<view style="font-size:24rpx;margin-left: 8px;" :style="{color:isSignIn?$theme.PRIMARY:$theme.SECOND}"
					@click="linkPact()">
					{{$lang.TIP_PRVITE_PACT}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// import Translate from '@/components/Translate.vue';
	export default {
		components: {
			// Translate,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: uni.getStorageSync('show') || false, // 密码显隐
				user: "", // 账户
				password: '', // 密码
				verifyPassword: '', // 确认密码
				emailCode: '', // 邮箱验证码（印度）
				code: '', // 邀请码
				curTab: 0,
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		computed: {
			// current is signin
			isSignIn() {
				return this.curTab < 1;
			},
		},
		onLoad() {
			// 读取缓存中的页面信息
			if (this.isSignIn) {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
			}
		},
		onShow() {
			this.isAnimat = true;
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换当前 登录或注册
			changeTab(val) {
				// this.isSignIn = !this.isSignIn;
				this.curTab = val;
				console.log(this.curTab);
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			// 勾选记住密码
			changeRemember(e) {
				console.log(e);
				this.isRemember = e;
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				console.log(e);
				this.isAgree = e;
			},

			// 用户隐私协议
			linkPact() {
				if (this.isSignIn) {
					uni.setStorageSync('user', this.user);
					uni.setStorageSync('pwd', this.password);
				}
				uni.navigateTo({
					url: this.$paths.PRVITE_PACT,
				})
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_NAME,
						icon: 'none',
					});
					return false;
				}
				// 以下通用
				if (this.password == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.showToast({
						title: this.$lang.TIP_ENTER_VERIFY_ACCOUNT_PASSWORD,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.showToast({
						title: this.$lang.TIP_PWD_NOEQUAL,
						icon: 'none',
					});
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.showToast({
						title: this.$lang.TIP_ENTER_INVITATION_CODE,
						icon: 'none',
					});
					return false;
				}
				if (this.isAgree != true) {
					uni.showToast({
						title: this.$lang.TIP_CHECK_AGREE,
						icon: 'none',
					});
					return false;
				}
				return true;
			},

			async signIn() {
				uni.showLoading({
					title: this.$lang.API_SIGN_IN_NOW,
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_SIGNIN,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME,
					});
				}, 1000);
			},
			async register() {
				uni.showLoading({
					title: this.$lang.API_SIGN_UP_NOW,
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				});
				console.log('result:', result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.TIP_SUCCESS_REGISTER,
					icon: 'success',
				});
				setTimeout(() => {
					this.changeTab(0);
				}, 1000);
			},
		}
	}
</script>

<style lang="scss">
	// /deep/.u-checkbox__icon-wrap {
	// 	background-color: transparent !important;
	// }

	.access_bg {
		width: 100%;
		min-height: 100vh;
		background-color: #FFFFFF;
	}

	.signin {
		width: 100%;
		min-height: 440rpx;
		padding-top: 0;
		background-image: url('/static/access_bg_0.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
	}

	.signout {
		width: 100%;
		min-height: 440rpx;
		padding-top: 0;
		background-image: url('/static/access_bg_1.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
	}
</style>