<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left">
				<image src="/static/logo_name.png" mode="aspectFit" :style="$theme.setImageSize(220,60)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<!-- <text :style="{color:$theme.PAGE_TITLE}">{{info.title}}</text> -->
			</view>
			<view class="right" @click="linkSearch()">
				<image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>
        
		<Profile :info="userInfo"></Profile>
	
		<view style="display: flex;align-items: center;justify-content: center;padding:20rpx 0;">
			<view class="common_card_bg card_bg_0" style="width: 80%;height: 150px;">
				<CardItemPrimary :info="cardData" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding:20rpx 90rpx;">
			<view @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top5.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<!-- <view @click="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top6.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.AUTH_TITLE}}
				</view>
			</view> -->

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top7.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.ACCOUNT_SERVICE}}
				</view>
			</view>
		</view>



		<view style="margin:20rpx 36rpx;">
			<TitleThird :title="$lang.ACCOUNT_MORE_FEATURES"></TitleThird>
			
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<!-- <view style="margin-top: 60rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view> -->
		</view>


	</view>
</template>

<script>
	import TitleThird from '@/components/title/TitleThird.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		components: {
			TitleThird,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemPrimary
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: uni.getStorageSync('show') || false,
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
				this.$util.setShowData(this.showAmount);
			},
			linkSearch() {
				uni.navigateTo({
					url: this.$paths.SEARCH
				})
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
					value4: this.userInfo.xinyong || 0,
				};
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>