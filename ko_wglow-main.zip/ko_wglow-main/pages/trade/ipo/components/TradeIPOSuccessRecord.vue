<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%">
							<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
									{{item.goods.name}}
									<text style="font-size: 20rpx;padding:20rpx;color:#999;">
										{{item.goods.code}}</text>
								</view>
								<view style="margin-left: auto;">
									<!-- <template v-if="item.status==2">
										<view :style="setStyle()" @click="subscription(item)">
											{{$lang.TRADE_IPO_SUCCESS_SUB}}
										</view>
									</template> -->
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_IPO_SUCCESS_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_APPLY_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_QUANTITY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.success)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.success_num_amount)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_FREEZE}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.freeze)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_UNPAY_AMOUNT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{item.success*item.price-item.freeze>0?
							$util.formatMoney(item.success*item.price*1-item.freeze*1):0+`
							${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_ORDER_SN}}
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
							{{item.order_sn}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_SUCCESS_CT}}
						</view>
						<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
							{{item.created_at}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeIPOSuccessRecord',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				item: ''
			};
		},
		methods: {
			async subscription(item) {
				const result = await this.$http.post(`api/goods-shengou/pay`, {
					id: item.id
				});
				console.log('result:', result);
				// if (result.code == 0) {
				// 	uni.$u.toast(result.message);
				// 	if (result.success == 0) {
				// 		setTimeout(() => {
				// 			this.$util.linkCustomerService();
				// 		}, 500)
				// 	} else {
				// 		uni.redirectTo({
				// 			url: TRADE_IPO_SUCCESS,
				// 		});
				// 		this.$router.go(0)
				// 	}
				// } else {
				// 	uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				// }
			},
		},
		setStyle() {
			return {
				backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
				color: this.$theme.PRIMARY,
				borderRadius: `8rpx`,
				// minWidth: `60rpx`,
				padding: `4rpx 16rpx`,
				fontSize: `22rpx`,
				textAlign: `center`
			}
		},
	}
</script>