<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view
					style="background-color:#F8F8F8; padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0 0 6%">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:94%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
									{{item.name}}
									<text style="font-size: 20rpx;padding:20rpx;color:#999;">
										{{item.code}}</text>
								</view>
								<view style="margin-left: auto;">
									<view :style="setStyle()" @click="handleDetail(item)">
										{{$lang.BTN_BUY}}
									</view>
								</view>
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_BLOCK_PRICE}}</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_IPO_POST_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.fa_amount*1)+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_MIN_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.min_num+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="color: #666666;font-size: 24rpx;">
							{{$lang.TRADE_BLOCK_MAX_QTY}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.max_num+` ${$lang.QUANTITY_UNIT}`}}
						</view>
					</view>
					<template v-if="item.shengou_date">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_IPO_SUB_CT}}
							</view>
							<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
								{{item.shengou_date}}
							</view>
						</view>
					</template>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'TradeIPOList',
		components: {
			EmptyData,
			CustomLogo,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				itemInfo: {}, // 单条数据详情
			}
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
			// 不跳页面，按钮弹层，二次确认购买
			handleDetail(val) {
				console.log('val:', val);
				this.itemInfo = val;
				this.handleShowModal();
			},
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: this.$lang.TRADE_IPO_MODAL_CONTENT,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.purchase();
				}
			},

			// 点击申购 一个账号只能申购一次。
			async purchase() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					// num: this.value,
					id: this.itemInfo.id,
					// price: this.price
				})
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success'
				});
				setTimeout(() => {
					this.$emit('action', 1);
				}, 1000);
			},
		}

	}
</script>

<style>
</style>