<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{stockTitle}}</text>
			</view>
		</header>

		<view style="padding-bottom: 20px;">
			<template v-if="stockInfo">
				<StockInfoPrimary :info="stockInfo"></StockInfoPrimary>

				<view style="padding-top: 32rpx;">
					<TabsFourth :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"></TabsFourth>
				</view>

				<template v-if="curTab==0">
					<view
						style="margin:28rpx 40rpx 20rpx 40rpx;border:4rpx solid #38AA9A;border-radius: 44rpx;display: flex;align-items: center;justify-content: space-between;">
						<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key='index'>
							<view :style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
								{{item}}
							</view>
						</block>
					</view>

					<template v-if="isShowKline">
						<StockKLine :list="klineList" :active="curKLine" ref="kline"></StockKLine>
					</template>

					<view class="common_btn" @click="linkBuy" style="margin: 20rpx auto;width: 80%;">
						{{$lang.BTN_BUY}}
					</view>
				</template>

				<template v-if="curTab==1">
					<StockDetail :code='code' :id='stockInfo.stock_id'></StockDetail>
				</template>

				<template v-if="curTab==2">
					<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import StockDetail from './components/StockDetail.vue'
	import StockNews from './components/StockNews.vue';
	import StockInfoPrimary from './components/StockInfoPrimary.vue';
	import StockKLine from './components/StockKLine.vue';
	export default {
		components: {
			TabsFourth,
			StockDetail,
			StockNews,
			StockInfoPrimary,
			StockKLine,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，				
				timer: null,
				curKLine: 0, // 当前显示的Kline数据图标
				klineList: [],
			};
		},
		computed: {
			stockTitle() {
				return this.stockInfo && this.stockInfo.name ?
					this.stockInfo.name : this.$lang.STOCK_OVERVIEW_TITLE
			},
			// 图表数据
			klineDataStock() {
				return this.klineList && this.klineList.length > 0 ?
					this.klineList : []
			},
			// 显示图表
			isShowKline() {
				return this.klineDataStock.length > 0
			},
		},

		onLoad(option) {
			this.code = option.code;
		},
		onShow() {
			this.isAnimat = true;
			this.getStockInfo();
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
		},
		onPullDownRefresh() {
			this.clearTimer();
			this.getStockInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 买入
			linkBuy() {
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?code=${this.code}`
				});
			},
			changeTab(val) {
				this.clearTimer(); // 每次切换，停止计时器
				console.log('val:', val);
				this.curTab = val;
				if (this.curTab == 0) this.handleShowKLine(0);
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.genKLineData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				this.clearTimer(); // 每次切换，停止计时器
				this.curKLine = val;
				this.getStockInfo();
			},
			// 产品详情
			async getStockInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				if (!result) return false;
				this.stockInfo = result[0];
				if (this.curTab == 0) {
					this.genKLineData();
					this.onSetTimeout(); // 开启计时器
				}
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				if (!result) return false;
				this.klineList = result;
				if (this.isShowKline && this.$refs.kline) {
					// 使图表组件重新渲染
					this.$refs.kline.renderInit();
				}
			},
			// 设置样式
			setStyle(val) {
				return {
					// minWidth: `80rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#999999',
					textAlign: 'center',
					fontSize: `28rpx`,
					fontWeight: `500`,
					backgroundColor: val ? this.$theme.PRIMARY : this.$theme.TRANSPARENT,
					borderRadius: `44rpx`,
					margin: `6rpx`,
					// borderBottom: `4rpx solid ${val? this.$theme.PRIMARY :this.$theme.TRANSPARENT }`
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>