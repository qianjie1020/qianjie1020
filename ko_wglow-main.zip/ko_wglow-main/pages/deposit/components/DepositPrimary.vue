<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_3" style="width: 80%;">
				<CardItemPrimary :info="info" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<view style="padding:30px  20px 10px 20px;">
			<view style="position: relative;height: 60rpx;color:transparent;width: max-content;padding: 0 24rpx;">
				{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}
				<view
					style="position: absolute;bottom: 20rpx;left: 0;right: 0;height: 16rpx;width: 100%; background-image:linear-gradient(90deg,#FFB044,#FFB044);border-radius: 16rpx;">
				</view>
				<view
					style="position: absolute;top:0; left: 0;right: 0;font-size: 32rpx;font-weight: 800;width: 100%;text-align: center;color:#333333;">
					{{$lang.DEPOSIT_TIP_DEPOSIT_AMOUNT}}
				</view>
			</view>


			<view class="common_input_wrapper" style="padding-left: 40rpx;">
				<input v-model="amount" :placeholder="$lang.DEPOSIT_TIP_LOW_AMOUNT" type="number"
					:placeholder-style="$theme.setPlaceholder()" style="flex: auto;"></input>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;margin: 30rpx 0;">
				<block v-for="(item,index) in amountList" :key="index">
					<view
						style="border-radius: 8rpx;width:25%;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
						:style="setStyle(curPos==index)" @click="quantity(item,index)">
						{{$util.formatMoney(item,0)}} 
					</view>
				</block>
			</view>
		</view>

		<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: #FFB044;border:none;"
			@click="handleSubmit()">
			{{$lang.BTN_CONFIRM}}
		</view>

		<view style="padding: 10px 20px;">
			<view style="font-size: 28rpx;font-weight: 700;text-align: center;padding-bottom: 20rpx;"
				:style="{color:$theme.LOG_LABEL}">
				{{$lang.DEPOSIT_TIP_TITLE}}
			</view>
			<block v-for="(item,index) in $lang.DEPOSIT_TIP_TEXT">
				<view style="line-height: 1.6;" :style="{color:$theme.LOG_LABEL}">{{item}}</view>
			</block>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/common/js_sdk.js';

	import AccountAssets from '@/components/account/AccountAssets.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		// desc:入金模式 之  带有输入项提交等
		name: 'DepositPrimary',
		components: {
			AccountAssets,
			CardItemPrimary,
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				curPos: 0, // 当前选中预置金额。
				amount: "", // 储值金额
			};
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT,
					this.$lang.ACCOUNT_TOTAL_PROFIT
				];
			},
			// 入金金额预置值
			amountList() {
				return [1000000, 3000000, 5000000, 10000000];
			},
		},
		created() {
			console.log(this.info);
			this.amount = this.amountList[this.curPos];
		},
		methods: {
			setStyle(val) {
				return {
					backgroundColor: val ? '#FFB044' : '#E9E9E9',
					color: val ? '#FFFFFF' : '#333333',
					borderRadius: `8rpx`,
					// border: `1px solid #F88B8B1A`
				}
			},

			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_TIP_LOW_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: 5,
					image: this.is_url || '',
					desc: this.value2 || '',
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					this.$util.linkCustomerService();
				}, 1000)
			},
		},
	}
</script>

<style>
</style>