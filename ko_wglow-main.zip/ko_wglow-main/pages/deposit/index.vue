<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{$lang.DEPOSIT_TITLE}}</text>
			</view>
			<!-- <view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view> -->
		</header>

		<DepositPrimary :info="info"></DepositPrimary>

	</view>
</template>

<script>
	import DepositPrimary from './components/DepositPrimary.vue';
	export default {
		components: {
			DepositPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {}, // 
			};
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getAccountInfo();
			uni.stopPullDownRefresh();
		},
		methods: {
			//个人信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				console.log(result);
				this.info = {
					value1: result.money, // 可提
					value2: result.freeze, // 冻结
					value3: result.totalYingli, // 总盈利}
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 40rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>