<template>
	<view style="display: flex;align-items: center;justify-content: space-between; height:60rpx;">
		<view style="margin-right: auto;">
			<view style="position: relative;height: 60rpx;color:transparent;width: max-content;padding: 0 24rpx;">
				{{title}}
				<view
					style="position: absolute;bottom: 20rpx;left: 0;right: 0;height: 16rpx;width: 100%; background-image:linear-gradient(90deg,#38AA9A,#38AA9A);border-radius: 16rpx;">
				</view>
				<view
					style="position: absolute;top:0; left: 0;right: 0;font-size: 32rpx;font-weight: 800;width: 100%;text-align: center;color:#333333;">
					{{title}}
				</view>
			</view>
		</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: 'TitleThird',
		props: {
			title: {
				type: String,
				default: ''
			},
		},
	}
</script>

<style>
</style>