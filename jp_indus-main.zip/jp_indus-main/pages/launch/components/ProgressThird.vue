<template>
	<view>
		<view
			style="position:relative;margin:30rpx 120rpx; background-color:rgba(255,255,255,0);border: 1px solid #ACD4FF;height:12rpx;border-radius: 20rpx;padding:0 3px;">
			<view :style="setStyle"></view>
			<view :style="imgMove"> </view>
		</view>
		<view style="text-align: center;color: #FFFFFF;font-size: 32rpx;margin-top: 30rpx;">
			{{`${$lang.LAUNCH_PROGRESS_TITLE} `}} {{`${percentage} %`}}
		</view>
	</view>
</template>

<script>
	// desc:带有一个小火煎/圆球的进度条
	export default {
		name: 'ProgressThird',
		data() {
			return {
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},

		computed: {
			setStyle() {
				const temp = {
					position: 'absolute',
					bottom: 0,
					left: 0,
					height: '12rpx',
					width: `${this.percentage}%`,
					backgroundImage: `linear-gradient(90deg,#9d7ef8 ,#6258fa,#9d7ef8)`,
					borderRadius: '20rpx',
				};
				return temp;
			},
			// 小火箭的位移
			imgMove() {
				const temp = {
					backgroundImage: `url('/static/launch_loading_icon.png')`,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: `${this.percentage}% 2px`,
					backgroundSize: '6%',
					width: ' 100%',
					height: '40rpx',
					position: 'absolute',
					left: 0,
					right: 0,
					top: '-14rpx',
					bottom: 0,
					zIndex: 99,
				};
				return temp;
			}
		},
		mounted() {
			console.log('child mounted', this.timer);
			this.onSetTimeout();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							uni.switchTab({
								url: this.$paths.HOME,
							})
						}, 1500);
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}
	}
</script>

<style>
</style>