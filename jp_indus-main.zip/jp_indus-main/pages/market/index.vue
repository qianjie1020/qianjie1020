<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view class="header_bg">
			<header style="padding-top: 60rpx;">
				<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;"
					@touchmove.stop>
					<view style="display: flex;margin:0 10rpx;">
						<block v-for="(item,index) in tabs" :key='index'>
							<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
								{{item}}
							</view>
						</block>
					</view>
				</scroll-view>
			</header>
		</view>

		<view :class="setClass"
			style="padding: 20rpx 0;background-color: #FFFFFF;margin:20rpx 20rpx 0 20rpx;border-radius: 28rpx 28rpx 0 0;min-height: 100vh;">
			<template v-if="curTab==0">
				<MarketTrack ref="track" @action="linkStock"></MarketTrack>
			</template>
			<template v-else-if="curTab==1">
				<MarketStockList ref="all"></MarketStockList>
			</template>
			<template v-else-if="curTab==2">
				<MarketHot ref="hot"></MarketHot>
			</template>
			<template v-else>
				<MarketKPI ref="kpi"></MarketKPI>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import MarketTrack from './components/MarketTrack.vue';
	import MarketStockList from './components/MarketStockList.vue';
	import MarketHot from './components/MarketHot.vue';
	import MarketKPI from './components/MarketKPI.vue';
	export default {
		components: {
			HeaderPrimary,
			TabsPrimary,
			MarketTrack,
			MarketStockList,
			MarketHot,
			MarketKPI
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_TRACK,
					// this.$lang.MARKET_INDEX_TAB_MARKET,
					// this.$lang.MARKET_INDEX_TAB_HOP,
					// this.$lang.MARKET_INDEX_TAB_KPI
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
		},

		onLoad(op) {
			if (op.type) {
				this.curTab = Number(op.type) || 0;
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onReady() {
			// console.log('onReady', this.$refs.follow);
		},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					padding: `12rpx 32rpx`,
					color: val ? '#FFFFFF' : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? '#FFFFFF' :this.$theme.TRANSPARENT }`
				}
			},
			linkStock() {
				this.changeTab(1);
			},
		},
	}
</script>
<style lang="scss" scoped>
	.header_bg {
		background-image: url(/static/bg_1.png);
		background-position: center center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		width: 100%;
		height: 160rpx;
	}
</style>