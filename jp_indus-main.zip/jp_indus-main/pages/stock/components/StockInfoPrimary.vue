<template>
	<view style="padding-bottom: 20rpx;">
		<view style="padding-bottom: 10px;">
			<view style="display: flex;align-items: center;padding: 20px;padding-bottom: 0;">
				<view style="flex:18%">
					<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
				</view>
				<view style="flex:72%">
					<view style="margin-bottom: 2px;font-size: 40rpx;" :style="{color:'#FFFFFF'}">
						{{info.name}}
						<image :src="`/static/arrow_${info.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$theme.setImageSize(24)" style="margin-left: 10px;"></image>
					</view>
					<view :style="{color:$theme.LOG_LABEL}"> {{info.number_code}} {{info.ct_name}}</view>
				</view>
				<view style="flex:10%;text-align: right;" @click="handleUnFollow(info.gid)">
					<image :src="`/static/${info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
						:style="$theme.setImageSize(36)"></image>
				</view>
			</view>
			<view
				style="display: flex;align-items: center;padding: 10px 20px;padding-bottom: 0;justify-content:space-between;"
				:style="$theme.setStockRiseFall(info.rate>0)">
				<view style="font-size: 32rpx;">
					{{$util.formatNumber(info.current_price)}} {{$lang.CURRENCY_UNIT}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate_num)}}
				</view>
				<view style="text-align: right;font-size: 32rpx;">
					{{$util.formatNumber(info.rate)}}%
				</view>
			</view>
		</view>
		<!-- <view style="margin:0 10rpx;padding:0 20rpx;line-height: 1.8;">
			<view style="display: flex;align-items: center;">
				<template v-if="setInfo.open>0">
					<view style="flex:0 0 50%;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;padding-right: 40rpx;">
							<view>{{$lang.STOCK_INFO_OPEN}}</view>
							<view>
								{{$util.formatMoney(setInfo.open) + ` ` + this.$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
				</template>

				<template v-if="setInfo.close>0">
					<view style="flex:0 0 50%;">
						<view style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;">
							<view>{{$lang.STOCK_INFO_CLOSE}}</view>
							<view>
								{{$util.formatMoney(setInfo.close) + ` ` + this.$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
				</template>
			</view>

			<view style="display: flex;align-items: center;">
				<template v-if="setInfo.high>0">
					<view style="flex:0 0 50%;">
						<view
							style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;padding-right: 40rpx;">
							<view>{{$lang.STOCK_INFO_HIGH}}</view>
							<view>
								{{$util.formatMoney(setInfo.high) + ` ` + this.$lang.CURRENCY_UNIT}}
							</view>
						</view>
					</view>
				</template>
				<template v-if="setInfo.low>0">
					<view style="flex:0 0 50%;">
						<view style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;">
							<view>{{$lang.STOCK_INFO_LOW}}</view>
							<view>{{$util.formatMoney(setInfo.low) + ` ` + this.$lang.CURRENCY_UNIT}}</view>
						</view>
					</view>
				</template>
			</view> -->

			<!-- <template v-if="setInfo.volume>0">
				<view style="display: flex;align-items: center;justify-content: space-between;color:#FFFFFF;">
					<view>{{$lang.STOCK_INFO_VOLUME}}</view>
					<view>{{setInfo.volume}}</view>
				</view>
			</template> -->
		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'StockInfoPrimary',
		components: {
			CustomLogo
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},

		computed: {
			setInfo() {
				return {
					// 这个你要判断下，有的没有，没有的就不显示
					open: this.info.info.ask,
					close: this.info.info.last,
					high: this.info.info.high,
					low: this.info.info.low,
					volume: this.info.info.turnover,
				}
			}
		},

		methods: {
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				})
				console.log(`result:`, result);
				// uni.showToast({
				// 	title: result.message,
				// 	icon: 'none'
				// });
				this.info.is_collected = this.info.is_collected == 1 ? 0 : 1;
			},
		}
	}
</script>

<style>
</style>