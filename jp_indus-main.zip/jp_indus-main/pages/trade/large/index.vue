<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`520rpx`,`bg_1`)">
		<HeaderThird :title="$lang.TRADE_LARGE_TITLE" color="#FFFFFF">
			<view style="color:#FFFFFF;" @click="linkRecord()">{{$lang.TRADE_LARGE_RECORD}}</view>
		</HeaderThird>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20rpx;">
			<image src="/static/trade_large.png" mode="aspectFit" :style="$theme.setImageSize(240,260)"></image>
		</view>

		<view style="background-color: #FFFFFF;min-height: 80vh;margin-top:40rpx;padding:40rpx">
			<TradeLargeList ref="list"></TradeLargeList>
		</view>
	</view>
</template>

<script>
	import HeaderThird from '@/components/header/HeaderThird.vue';
	import TradeLargeList from './components/TradeLargeList.vue';

	export default {
		components: {
			HeaderThird,
			TradeLargeList,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
			}
		},
		onShow() {
			this.isAnimat = true;
			if (this.$refs.list)
				this.$refs.list.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_LARGE_RECORD
				})
			}
		},
	}
</script>