<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`140rpx`,`bg_1`)">
		<HeaderSecond :title="$lang.TRANSACTION_TITLE" color="#FFFFFF"></HeaderSecond>

		<view style="background-color: #FFFFFF;padding: 20rpx 0;min-height:96vh;">
			<TabsThird :tabs="tabLabels" @action="changeTab" :acitve="curTab"></TabsThird>
			<template v-if="curTab == 0">
				<TradeRecord></TradeRecord>
			</template>

			<template v-if="curTab == 1">
				<DepositRecord></DepositRecord>
			</template>

			<template v-if="curTab == 2">
				<WithdrawalRecord></WithdrawalRecord>
			</template>
		</view>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsThird from '@/components/tabs/TabsThird.vue';
	import TradeRecord from './components/TradeRecord.vue';
	import DepositRecord from './components/DepositRecord.vue';
	import WithdrawalRecord from './components/WithdrawalRecord.vue';
	export default {
		components: {
			HeaderSecond,
			TabsThird,
			TradeRecord,
			DepositRecord,
			WithdrawalRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		computed: {
			// tabs的明文
			tabLabels() {
				return [
					this.$lang.TRADE_LOG_TRADE,
					this.$lang.TRADE_LOG_DEPOSIT,
					this.$lang.TRADE_LOG_WITHDRAW
				];
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curTab = Number(opt.code) || 0;
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>