<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`160rpx`,`bg_1`)">
		<HeaderSecond :title="setTitle" color="#FFFFFF"></HeaderSecond>

		<view style="padding: 20px;background-color: #F1F4FF;min-height: 80vh;">
			<TitleSecond :title="$lang.OLD_PASSWORD"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="oldPassword" type="text" :placeholder="$lang.ENTER_OLD_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="oldPassword" type="password" :placeholder="$lang.ENTER_OLD_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitleSecond :title="$lang.NEW_PASSWORD"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="newPassword" type="text" :placeholder="$lang.ENTER_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="newPassword" type="password" :placeholder="$lang.ENTER_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>

			<TitleSecond :title="$lang.VERIFY_NEW_PASSWORD"> </TitleSecond>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/account_password.png" :style="$theme.setImageSize(40)">
				</image>
				<template v-if="isShow">
					<input v-model="newPassword2" type="text" :placeholder="$lang.ENTER_VERIFY_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<template v-else>
					<input v-model="newPassword2" type="password" :placeholder="$lang.ENTER_VERIFY_NEW_PASSWORD"
						:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$theme.setImageSize(32)" @click="toggleShow">
				</image>
			</view>
		</view>
		<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
			<view class="common_btn" style="margin:0 auto;width: 80%;" @click="handleSubmit()">
			変更
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			HeaderSecond,
			TitleSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: false, // 密码显隐
				oldPassword: "", // 旧密码
				newPassword: "", // 新密码
				newPassword2: "", // 验证新密码
				role: '', // 根据当前角色，处理逻辑。
			};
		},
		computed: {
			// 当前页面用于:role=pay视为变更支付密码，否则视为变更登入密码
			isPay() {
				return this.role == 'pay';
			},
			// 当前页面header标题
			setTitle() {
				return this.isPay ? this.$lang.PAY_PASSWORD_TITLE : this.$lang.SIGNIN_PASSWORD_TITLE
			}
		},
		onLoad(opt) {
			console.log(opt.role);
			this.role = opt.role || '';
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 检查表单
			checkForm() {
				if (this.oldPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_OLD_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword2 == '') {
					uni.showToast({
						title: this.$lang.ENTER_NEW_PASSWORD,
						icon: 'none'
					});
					return false;
				}
				if (this.newPassword != this.newPassword2) {
					uni.showToast({
						title: this.$lang.ENTER_VERIFY_FAIL,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.updatePassword();
				}
			},
			//修改密码
			async updatePassword() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const temp = this.isPay ? `updatePayPassword` : `updateLoginPassword`
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPassword,
					newpass: this.newPassword,
					confirmpass: this.newPassword2,
				});
				console.log(result);
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000)
			},
		}
	}
</script>

<style>
</style>