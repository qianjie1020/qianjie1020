<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setBGSize(`480rpx`,`bg_1`)">
		<HeaderSecond :title="$lang.AUTH_TITLE" color="#FFFFFF"></HeaderSecond>

		<view style="padding-bottom: 180rpx;">

			<view class="common_block" style="padding:40rpx;position: relative;margin-top: 120rpx;">
				<view style="position: absolute;top:-30%;left: 0;right: 0;">
					<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 60rpx;">
						<image src="/static/auth.png" mode="aspectFit" :style="$theme.setImageSize(280,220)"></image>
					</view>
				</view>

				<TitleSecond :title="$lang.AUTH_REAL_NAME"></TitleSecond>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom: 20px;">
					<input v-model="realName" type="text" :placeholder="$lang.TIP_REAL_NAME"
						:disabled="!userInfo || userInfo.is_check!=-1" style="width: 80%;"></input>
				</view>

				<TitleSecond :title="$lang.AUTH_ID_CARD"></TitleSecond>
				<view class="common_input_wrapper" style="padding-left: 10px;margin-bottom:0;">
					<template v-if="showPwd">
						<input v-model="cardNo" type="text" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"
							:disabled="!userInfo || userInfo.is_check!=-1"></input>
					</template>
					<template v-else>
						<input v-model="cardNo" type="password" :placeholder="$lang.AUTH_TIP_ID_CARD"
							placeholder-style="font-size:11px" style="width: 86%;"
							:disabled="!userInfo || userInfo.is_check!=-1"></input>
					</template>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}_dark.png`" @click="handleShowPwd"
						:style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>

			<template v-if="userInfo && userInfo.is_check==1">
				<view class="common_block" style="padding:24rpx;">
					<view style="text-align: center;font-size: 32rpx;font-weight: 700; line-height: 20;">
						本人確認済み
					</view>
				</view>
			</template>

			<template v-if="userInfo && userInfo.is_check==0">
				<view class="common_block" style="padding:24rpx;">
					<view style="text-align: center;font-size: 32rpx;font-weight: 700; line-height:20;">
						本人確認中
					</view>
				</view>
			</template>

			<template v-if="!userInfo || userInfo.is_check==-1">
				<view class="common_block" style="padding:24rpx;">
					<TitleSecond :title="$lang.AUTH_CARD_F"></TitleSecond>
					<view style="background-color: #E5E5E5;width: 100%;height: 1px;"></view>
					<view
						style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #F7F9FF;border-radius: 8rpx;margin: 30rpx;">
						<image :src="!formData.obverseUrl?`/static/card_f.png`:formData.obverseUrl"
							@click="selectImg('obverse')" style="margin: 10px;width: 220px;height: 120px;"></image>
					</view>
				</view>

				<view class="common_block" style="padding:24rpx;">
					<TitleSecond :title="$lang.AUTH_CARD_B"></TitleSecond>
					<view style="background-color: #E5E5E5;width: 100%;height: 1px;"></view>
					<view
						style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #F7F9FF;border-radius: 8rpx;margin: 30rpx;">
						<image :src="!formData.reverseUrl?`/static/card_b.png`:formData.reverseUrl"
							@click="selectImg('reverse')" style="margin: 10px;width: 220px;height: 120px;"></image>
					</view>
				</view>
			</template>
		</view>

		<template v-if="!userInfo || userInfo.is_check==-1">
			<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #FFFFFF;padding:40rpx">
				<view class="common_btn" style="margin:0 auto;width: 80%;" @click="gain_aouonym()">
					提出
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				realName: '', // 姓名
				cardNo: '', // 证件号码
				showPwd: false, // 是否显示完整证件号
				fullCardNo: '', // 证件号码完整值

				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				userInfo: null,
			};
		},
		computed: {
			// 实名认证状态明文
			statusLabels() {
				return [
					this.$lang.AUTH_RESULT_REVIEW,
					this.$lang.AUTH_RESULT_PASS,
					this.$lang.AUTH_RESULT_REPOST,
				]
			},
		},
		onLoad() {
			this.getAccountInfo();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			this.setStorageData();
		},

		methods: {
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('realName', this.realName);
				uni.setStorageSync('cardNo', this.cardNo);
				console.log(`111`, this.formData);
				uni.setStorageSync('obverseUrl', this.formData.obverseUrl);
				uni.setStorageSync('reverseUrl', this.formData.reverseUrl);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.realName = this.realName.length > 0 ? this.realName : (uni.getStorageSync('realName') || '');
				this.cardNo = this.cardNo.length > 0 ? this.cardNo : (uni.getStorageSync('cardNo') || '');
				this.formData.obverseUrl = this.formData.obverseUrl.length > 0 ?
					this.formData.obverseUrl : (uni.getStorageSync('obverseUrl') || '');
				this.formData.reverseUrl = this.formData.reverseUrl.length > 0 ?
					this.formData.reverseUrl : (uni.getStorageSync('reverseUrl') || '');
			},

			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
			},

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg(1, imageFile.path)

				} else if (name == "reverse") {
					this.upimg(2, imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 1) {
						this.formData.obverseUrl = temp[0].url;
					} else {
						this.formData.reverseUrl = temp[0].url;
					}
				}
				this.setStorageData();
			},

			// 认证
			async gain_aouonym() {
				if (this.realName == '') {
					uni.showToast({
						title: this.$lang.TIP_REAL_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.cardNo == '') {
					uni.showToast({
						title: this.$lang.AUTH_TIP_ID_CARD,
						icon: 'none'
					});
					return false;
				}

				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const tempCardNo = this.cardNo;
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName,
					// sex: this.calcSex,
					idno: tempCardNo,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				});
				if (result) {
					uni.showToast({
						title: result,
						icon: 'none'
					});
					setTimeout(() => {
						uni.switchTab({
							url: this.$paths.HOME
						});
					}, 1000);
				}
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.userInfo = result;
				this.realName = this.userInfo.real_name || '';
				this.cardNo = this.userInfo.idno || '';
				this.formData.obverseUrl = this.userInfo.front_image || '';
				this.formData.reverseUrl = this.userInfo.back_image || '';
				this.getStorageData();
			},
		},
	};
</script>