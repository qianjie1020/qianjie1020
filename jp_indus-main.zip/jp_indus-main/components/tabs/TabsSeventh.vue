<template>
	<view class="tabs_wrapper">
		<block v-for="(item,index) in tabs" :key='index'>
			<view :class="setClass(acitve==index)" @click="changeTab(index)">
				<view style="position: relative;height: 100rpx;padding: 0 20px;">
					<template v-if="acitve==index">
						<view
							style="position: absolute;bottom: 20rpx;left: 0;right: 0;height: 16rpx;width: 30%; background-image:linear-gradient(90deg,#6f62de,#6f62de);border-radius: 16rpx;margin:0 auto;">
						</view>
					</template>
					<view
						style="position: absolute;top:30rpx;left: 0;right: 0;font-size: 32rpx;font-weight: 800;width: 100%;text-align: center;"
						:style="{color:acitve==index?$theme.SECOND:'#898996'}">
						{{item}}
					</view>
				</view>

			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'TabsSeventh',
		props: {
			// tab项数组
			tabs: {
				type: Array,
				default: [],
			},
			// 当前激活项
			acitve: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				current: this.acitve,
			};
		},
		computed: {},
		methods: {
			changeTab(val) {
				this.current = val;
				this.$emit('action', this.current);
			},
			setClass(val) {
				return `item ${val?'item_act':''}`
			},
		}
	}
</script>
<style lang="scss" scoped>
	.tabs_wrapper {
		border-radius: 16rpx 16rpx 0 0;
		background-image: linear-gradient(90deg, #F1F4FF, #F1F4FF);
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: 100% 100%;
		width: 100%;
		height: 100rpx;
		display: flex;
		align-items: center;

		.item {
			flex: 1;
			border-radius: 16rpx;
			// padding: 20rpx 0;
			text-align: center;
			font-size: 32rpx;
			line-height: 1.8;
			color: #898996;
		}

		.item_act {
			background-image: linear-gradient(90deg, #FFFFFF, #FFFFFF);
			background-repeat: no-repeat;
			background-position: 0 0;
			background-size: 100% 100%;
			width: 100%;
			height: 100%;
			color: #121212;
		}
	}
</style>