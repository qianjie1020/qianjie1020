<template>
	<view style="position: relative;">
		<image src="/static/sybj.jpg" mode="widthFix" style="width: 100%;"></image>
	
	<view :class="isAnimat?'fade_in':'fade_out'" style="width: 100%;height: 150px; position: absolute;bottom: 50%;">
		
		<HeaderPrimary isSearch :title="`  `"> </HeaderPrimary>

		<!-- <view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_0" style="width: 90%;">
				<CardItemPrimary :info="cardInfo" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view> -->

		<view class="common_block" style="margin-top: 130px;">
			<ButtonGroup></ButtonGroup>
		</view>

		<view style="margin:0 40rpx;">
			<TitlePrimary :title="$lang.MARKET_NEWS_TITLE">
				<view style="font-size: 13px;margin-left: auto;" @click="linkMarketNews()"
					:style="{color:$theme.SECOND}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view>

		<MarketNewsTop></MarketNewsTop>

		<view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.STOCK_ALL">
				<view style="font-size: 13px;margin-left: auto;" @click="linkAllList()" :style="{color:$theme.SECOND}">
					{{$lang.MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view>

		<view
			style="padding:40rpx 20rpx;background-color: #FFFFFF;margin:0 20rpx 40rpx 20rpx;border-radius: 32rpx;">
			<MarketHot></MarketHot>
		</view>

		<!-- IPO申购成功弹层 -->
		<IPOSuccessAlert></IPOSuccessAlert>

	</view>
	</view>
</template>

<script>
	import Translate from '@/components/Translate.vue';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from './components/ButtonGroup.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	import MarketNewsTop from '../market/components/MarketNewsTop.vue';
	import MarketHot from '../market/components/MarketHot.vue';
	import IPOSuccessAlert from './components/IPOSuccessAlert.vue';
	export default {
		components: {
			Translate,
			HeaderPrimary,
			ButtonGroup,
			TitlePrimary,
			CardItemPrimary,
			MarketNewsTop,
			MarketHot,
			IPOSuccessAlert,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isActLang: true, // 当前登入用户是否开启多语言权限	
				cardInfo: {}, // 资产卡
				isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.27
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			// 今日
			setToday() {
				return this.$util.formatToday(new Date());
			}
		},

		onLoad() {},
		onShow() {
			this.getAccountInfo();
			this.isAnimat = true;
			console.log(this.cardLabels);
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		deactivated() {},

		methods: {
			// 跳转到市场的热门股票
			linkAllList() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=1`,
				})
			},
			linkMarketNews() {
				uni.reLaunch({
					url: this.$paths.MARKET_OVERVIEW + `?type=3`,
				})
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.cardInfo = {
					value1: result.totalZichan || 0,
					value2: result.money || 0,
					value3: result.freeze || 0,
				};
			}
		},
	}
</script>