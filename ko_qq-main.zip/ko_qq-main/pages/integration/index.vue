<template>
	<view class="bg">
		<view class="flex padding-25">
			<view @click="goBack()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="bold font-size-17 flex-1 text-center">퀀트 트레이딩</view>
			<!-- <view class="bold font-size-12 flex">거래내역</view> -->
		</view>
		
		<header style="padding-top: 10rpx;border-bottom: 1px solid #E7E8ED;">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;"
				@touchmove.stop>
				<view style="display: flex;margin:0 0rpx;justify-content: space-between;padding:0px 50px;">
					<block v-for="(item,index) in tabs" :key='index'>
						<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
							{{item}}
						</view>
					</block>
				</view>
			</scroll-view>
		</header>
		
		<template v-if="curTab==0">
		<view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<view class="flex" style=" justify-content: space-between;padding: 20px 50px;">
			<view  style="background-color:#3496e0;padding: 8px 40px;border-radius: 30px;color: #fff;"
				@click="handleSubmit()">예치</view>
			<view style="background-color:#3496e0;padding: 8px 40px;border-radius: 30px;color: #fff;"
				@click="handleDetail()">출금</view>
		</view>
		
		

		<view style="padding:40rpx;">

			<!-- <view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.LOG_VALUE}">
				입력 금액
			</view> -->
			<!-- <view class="common_input_wrapper" style="padding-left: 30px;margin-bottom: 20px;">
				<input v-model="amount" placeholder="입력 금액" type="number" :placeholder-style="$theme.setPlaceholder()"
					style="flex: auto;"></input>
			</view> -->

			<!-- <view>
				<view class="common_btn" style="margin:60rpx auto;width: 80%;background-color: #3496e0;"
					@click="handleSubmit()">
					{{$lang.BTN_CONFIRM}}
				</view>
			</view> -->
			<view class="text-center font-size-16">퀀트 투자 원클릭 시스템 가이드 </view>
			<view class="margin-top-15">1, 접속 규칙 </view>
			<view class="">• 원클릭으로 활성화 가능</view>
			<!-- <view class="">• 하루 1회만 가능</view> -->

			<view class="margin-top-15">2, 자금 운용 </view>
			<view class="">• 신한자산관리 계좌로 집중</view>
			<view class="">• AI 퀀트 시스템이 자동 매매</view>
			<view class="">• 접속 중 주식 매수 불가 </view>

			<view class="margin-top-15">3, 포지션 배정 규칙</view>
			<view class="">총자산별 최대 배정 비율 & 목표 수익률</view>
			<!-- <view class="">• 500만 원: 20% 배정, 목표 10%</view> -->
			<view class="">• 500만 원~2000만 원: 30% 배정, 목표 20%</view>
			<view class="">• 2000만 원~5000만 원: 40% 배정, 목표 50%</view>
			<view class="">• 5000만 원~1억원: 50% 배정, 목표 80%</view>
			<view class="">• 1억 원~2억 원: 80% 배정, 목표 100%</view>
			<view class="">• 2억 원~5억 원: 100% 배정, 목표 500%</view>

			<view class="margin-top-15">4, 스마트한 트레이딩</view>
			<view class="">• 목표 수익률 달성 시 퀀트 트레이딩 정지</view>
			<!-- <view class="">• 미달성 시 당일 장 마감 후 계좌로 반환</view> -->

			<view class="margin-top-15">예시:</view>
			<view class="">490만원 계좌 → 98만원 투자, 10% 수익 목표</view>
			<view class="">1234만원 계좌 → 370만원 투자, 20% 수익 목표</view>
		</view>
		</template>
		
		<template v-if="curTab==1 || this.curTab==0">
				<view style="display: flex;align-items: center;justify-content: center;margin-top: 40rpx;">
					<view class="common_card_bg" style="width: 640rpx;background-color: #F8F8FA;">
						<CardJijin :info="cardData2" :labels="cardLabels"></CardJijin>
					</view>
				</view>
				
				<view style="padding: 20px 50px;">
					<view class="text-center" style="background-color:#3496e0;padding: 8px 40px;border-radius: 30px;color: #fff;"
					@click="handleDatri()">매일 수익 만땅 퀀트</view>
				</view>
				
				<view style="padding:40rpx;">
					<!-- <view class="text-center font-size-16">퀀트 투자 원클릭 시스템 가이드 </view> -->
					<view class="margin-top-15">1. 3억 및 이상 투자 가능하신 분</view>
					<view class="">2. 선착순 200명만 가능해요</view>
					<!-- <view class="">• 하루 1회만 가능</view> -->
				
					<view class="margin-top-15">3. 신한자산관리에서 1000억 한도로 퀀트 거래해요. 매일 수익 자동 분배, 하루 20% 고정 수익!</view>
					<view class="">어떻게 가능하냐구요? 예를 들어, 오늘 신한자산관리가 XXX 주식 사서 20% 올랐다면, 여러분 계좌로 20% 수익이 쏙!
		</view>
				
					<view class="margin-top-15">4. 1000억으로 번 돈 중 20%만 여러분께 드리고, 나머지는 "착한 기금"으로 모아요.</view>
					<view class="">만약 하루에 30% 벌었다면, 20%는 여러분 몫, 10%는 "공익기금"으로 모아서 나중에 좋은 일에 써요!</view>
					
					<view class="margin-top-15">5. 매일 수익금 지급, 만기 시 원금 반환!</view>
					<view class="margin-top-15">그리고 15일에 하기로 했던 오프라인 모임 날짜가 변경되었으니 변경된 날짜는 추후에 공지해 드리겠습니다. 조건 맞는 분들 빨리 연락주세요!</view>
				</view>
				</template>
	</view>
</template>

<script>
	import CardItemThird from '@/components/card/CardItemThird.vue';
	import CardJijin from '@/components/card/CardJijin.vue';
	export default {
		components: {
			CardItemThird,
			CardJijin,
		},
		data() {
			return {
				amount: '',
				isAnimat: false, // 页面动画
				curTab: 0, // 
				isShow: false, // 密码显隐
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
				cardData: {},
				cardData2:{},
				selectedContent:'',
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.ACCOUNT_AMOUNT_TOTAL,
					this.$lang.ACCOUNT_AMOUNT_AVAILABLE,
					this.$lang.ACCOUNT_COLD_AMOUNT
				];
			},
			tabs() {
				return [
					this.$lang.LIANGHUA_JIERU,
					this.$lang.JIJIN_LICAI,
				]
			},
		},
		onShow() {
			this.getAccountInfo();
			this.getAccountlicaisj();
			this.isAnimat = true;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {

			handleDetail(val) {
				console.log('val:', val);
				this.itemInfo = val;
				this.handleShowModal();
			},
		    showContent(content){
				this.selectedContent = content;
			},
			// 平仓/卖出
			async handleShowModal() {
				const result = await uni.showModal({
					// title: this.$lang.TRADE_IPO_MODAL_TITLE,
					content: '현재 퀀트 트레이딩이 진행 중입니다. 중도 해지하시면 손실이 발생할 수 있습니다. 그럼에도 불구하고 출금을 진행하시겠습니까?',
					cancelText: '네',
					confirmText: '아니요',
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.transfer();
				}
			},


			async handleSubmit() {
				const result = await this.$http.post(`api/user/leilianghua`, {
					type: 1,
					// money: this.amount
				});
				console.log(`result:`, result);
				if (!result) return false;
				this.getAccountInfo()
				uni.showToast({
					title: result,
					icon: 'none'
				})
			},
			async handleDatri() {
				const result = await this.$http.post(`api/app/licaite`, {
					// type: 1,
					// money: this.amount
				});
				console.log(`result:`, result);
				if (!result) return false;
				// this.getAccountInfo()
				uni.showToast({
					title: result,
					icon: 'none'
				})
			},
			async transfer() {
				const result = await this.$http.post(`api/user/leilianghua`, {
					type: 2,
					// money: this.amount
				});
				this.getAccountInfo()
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				})

			},
			goBack() {
				uni.switchTab({
					url: '/pages/home/index'
				})
			},
			home() {
				console.log('dsdsd');
				uni.navigateTo({
					url: '/pages/integration/zhaunchu'
				})
			},
			zhaunru() {
				uni.navigateTo({
					url: '/pages/integration/zhuanru'
				})
			},
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `40%`,
					padding: `12rpx 0rpx`,
					color: val ? '#0293d3' : '#999',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `5rpx solid ${val? '#0293d3' :this.$theme.TRANSPARENT }`
				}
			},
			
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				console.log(`hold`, this.$refs.hold);
				if (this.curTab == 0) {
					// this.refreshChild();
				}
				if (this.curTab == 0 || this.curTab == 1) {
					if (this.$refs.hold) {
						console.log(this.$refs.hold);
						this.$refs.hold.curPage = 1;
						this.$refs.hold.list = [];
						this.$refs.hold.getList();
					}
				}
				if (this.curTab == 2) {
					if (this.$refs.sell) {
						console.log(this.$refs.sell);
						this.$refs.sell.curPage = 1;
						this.$refs.sell.list = [];
						this.$refs.sell.getList();
					}
				}
			},
			
			async getAccountlicaisj() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/app/licaisj`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData2 = {
					value1: this.userInfo.price || 0,
					value2: this.userInfo.gongyi || 0,
					// value3: this.userInfo.freeze || 0,
					value3: this.userInfo.shouyi || 0,
				};
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					// value3: this.userInfo.freeze || 0,
					value3: this.userInfo.lianghua || 0,
				};
			},
		}
	}
</script>

<style lang="scss" scoped>
	.bg {
		background-image: url(/static/bg_1.png);
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: 100% 100%;
		width: 100%;
		// min-height: 100vh;
	}
</style>