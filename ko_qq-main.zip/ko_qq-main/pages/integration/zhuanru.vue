<template>
	<view>
		<view class="flex padding-20">
			<view @tap="home()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="text-center flex-1 font-size-16 bold">转入</view>
		</view>
		
		<view style="" class="text-center">
			
			<view class="title" style="font-size: 16px;">
				<span>전환 가능 금액</span>
			</view>
			<view class="money text-center font-size-22 bold margin-top-10">
					<span>{{$util.formatMoney(userInfo.money)}}</span>
			</view>

		</view>
		<view style="background-color: #F6FFFA;margin: 20px 10px;" class="flex flex-b padding-20 radius10">
			<view>
				AI 트레이딩 지갑 계좌
			</view>
			<!-- <view>
				전환 금액
			</view> -->
		</view>
		<view style="margin: 20px;">
			<view style="margin: 10px 0;" class="bold">전환 금액</view>
			<u--input placeholder="입력 금액"  v-model="money" style="height: 30px;"></u--input>
		</view>
		<view class="flex flex-wrap text-center gap10" style="margin: 20px;color: #14CF76;">
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(10)">
				10%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(20)">
				20%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(30)">
				30%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(40)">
				40%
			</view>
		</view>
		<view class="flex flex-wrap text-center gap10" style="margin: 20px;color: #14CF76;">
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(50)">
				50%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(60)">
				60%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(70)">
				70%
			</view>
			<view class="flex-1 padding-20" style="background-color: #daf7e8;" @click="xx(80)">
				80%
			</view>
		</view>
	
		<view class="purchase" @click="transfer">
			확인
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				money: '',
				userInformation: {},
				userInfo:{},
				
			}
		},
		onShow() {
			// this.gaint_info()
			this.getAccountInfo();
		},
		methods: {
			xx(number){
				// console.log(this.balance);
				this.money=parseInt(this.userInfo.money*number*0.01)
				
			},
			home() {
				uni.navigateBack()
			}, 
			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				console.log('result: ',result);
				if (!result) return false;
				
				this.userInfo = result;
				// this.cardData = {
				// 	value1: this.userInfo.totalZichan || 0,
				// 	value2: this.userInfo.money || 0,
				// 	// value3: this.userInfo.freeze || 0,
				// 	value3: this.userInfo.lianghua || 0,
				// };
			},
			
			async transfer() {
				if (this.money > 0) {
					let list = await this.$http.post('api/user/leilianghua', {
						
						'money': this.money,
						'type': 1
					});
					this.getAccountInfo()
					console.log('yyyyyyyyy===',list);
					uni.showToast({
						
						title: list.data.message,
						// icon: 'none'
					})
					let _this = this;
					setTimeout(function() {
						_this.gaint_info();
						_this.money = '';
					}, 1000)

				}

			}
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 150px;
		// background-image: url("../../../../static/my/zijimima.png");
		background: linear-gradient(to right, #14CF76, #59DF9F);
		background-repeat: no-repeat;
		background-size: 100% 100%;
		display: flex;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {
			text-align: center;
			margin: 0 auto;
			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 20rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-color: #3496e0;
		margin: 60rpx 30rpx;
		border-radius: 80rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}

	.with-bottom-line {
		color: #1d7ed2;
	}

	.with-bottom-line::after {
		content: "";
		/* 必须设置，表示插入的内容为空 */
		display: block;
		/* 使得::after生成的元素成为块级元素 */
		border-bottom: 2px solid #1d7ed2;
		/* 添加底部横线 */
		width: 60%;
		/* 使横线宽度与父元素相同 */
		margin-top: 10px;
		/* 可选：添加一些顶部外边距 */
		text-align: center;
		margin-left: 20%;
	}
</style>