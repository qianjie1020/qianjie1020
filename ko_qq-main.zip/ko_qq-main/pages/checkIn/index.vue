<template>
	<view
		style="background-image: url(/static/qiandao.png);background-repeat: no-repeat;background-position: 0 0;background-size: 100% 360rpx;min-height: 100vh;">
		<view class="flex padding-25">
			<view @click="goBack()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="bold font-size-17 flex-1 text-center">로그인</view>
		</view>

		<view class="bold font-size-25 padding-20">출석보상 받아가기</view>
		<view style="padding: 0px 20px;">
			<view class="font-size-13">이벤트 기간: </view>
			<view class="font-size-15" style="padding-top: 24rpx;text-align: center;">2024년 7월 1일 ~ 2024년 12월 31일</view>
		</view>

		<view style="padding:40rpx;">
			<view style="display: flex;align-items: center;line-height: 1.4;padding-bottom: 12rpx;">
				<view style="background-color: #0d5cfa;width: 8rpx;height:30rpx;"></view>
				<view style="font-size: 30rpx;padding-left: 12rpx;">출석체크
				</view>
				<view style="margin-left: auto;">{{setToDay}}</view>
			</view>

			<view>
				<!-- <view>{{setToDay}}</view> -->
				<view style="display: flex;align-items:center;flex-wrap: wrap;padding-top: 12rpx;">
					<block v-for="(item,index) in curMonthDays" :key="item">
						<view style="flex:0 0 14.28%;">
							<view style="padding: 12rpx 12rpx 0 0;">
								<view :style="setStyle(item)" @click="handleCheckIn(item)">{{item}}</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>

		<!-- <view style="padding:0 40rpx;padding-bottom: 24rpx;">
			<view style="display: flex;align-items: center;line-height: 1.4;padding-bottom: 12rpx;">
				<view style="background-color: #0d5cfa;width: 8rpx;height:30rpx;"></view>
				<view style="font-size: 30rpx;padding-left: 12rpx;">출석체크 규칙
				</view>
				<view style="margin-left: auto;">출석체크 <text style="color: #0d5cfa;padding:0 12rpx;">{{total}}</text> 일
				</view>
			</view>
			<view style="display: flex;align-items: center;padding-top: 12rpx;">
				<view style="flex:0 0 4%;">
					<image src="/static/checkin_1.svg" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>
				</view>
				<view style="flex:1;">
					<view style="padding-left: 24rpx;">{{prizes[curTag]}}</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;padding-top: 12rpx;">
				<view style="flex:0 0 4%;">
					<image src="/static/checkin_0.svg" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>
				</view>
				<view style="flex:1;">
					<view style="padding-left: 24rpx;">{{prizes[curTag+1]}}</view>
				</view>
			</view>
		</view> -->

		<view style="padding:40rpx;">
			<!-- <view style="display: flex;align-items: center;line-height: 1.4;padding-bottom: 12rpx;">
				<view style="background-color: #0d5cfa;width: 8rpx;height:30rpx;"></view>
				<view style="font-size: 30rpx;padding-left: 12rpx;">출석체크 규칙
				</view>
			</view> -->
			<view style="display: flex;align-items: center;line-height: 1.4;padding-bottom: 12rpx;">
				<view style="background-color: #0d5cfa;width: 8rpx;height:30rpx;"></view>
				<view style="font-size: 30rpx;padding-left: 12rpx;">출석체크 규칙
				</view>
				<view style="margin-left: auto;">출석체크 <text style="color: #0d5cfa;padding:0 12rpx;">{{total}}</text> 일
				</view>
			</view>
			<template v-if="curTag>0">
				<view style="display: flex;align-items: center;padding-top: 12rpx;">
					<view style="flex:0 0 4%;">
						<image src="/static/checkin_1.svg" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>
					</view>
					<view style="flex:1;">
						<view style="padding-left: 24rpx;">{{prizes[curTag]}}</view>
					</view>
				</view>
			</template>
			<view style="display: flex;align-items: center;padding-top: 12rpx;">
				<view style="flex:0 0 4%;">
					<image src="/static/checkin_0.svg" mode="aspectFit" style="width: 32rpx;height: 32rpx;"></image>
				</view>
				<view style="flex:1;">
					<view style="padding-left: 24rpx;">{{prizes[curTag+1]}}</view>
				</view>
			</view>

			<view style="font-size: 28rpx;">1. 출석체크 방법은? </view>
			<view style="font-size: 24rpx;padding-left: 48rpx;padding-bottom: 12rpx;color:#666;">"신한투자증권" 앱에서 매일
				(20:00~20:30) 이 시간에 위에 표시된 날자를 클릭하면 출석체크 할수 있습니다.</view>

			<view style="font-size: 28rpx;">2. 상품 수령 방법은 ?</view>
			<view style="font-size: 24rpx;padding-left: 48rpx;padding-bottom: 12rpx;color:#666;">출석체크 및 상품 수령 가능할 시
				매니저님한테 연락하시면 수령이 가능합니다.</view>

			<view style="font-size: 28rpx;">3. 출석체크 이벤트 상품
				<text style="font-size: 20rpx;color:#0d5cfa;padding-left: 24rpx;">상품은 중복 수령할 수 없습니다.</text>
			</view>
			<view style="padding-left: 48rpx;">
				<block v-for="(item,index) in checkInDays" :key="index">
					<view style="font-size: 24rpx;color:#666;padding-bottom: 6rpx;">{{item}} 일 출석체크 — {{prizes[index]}}.
					</view>
				</block>
			</view>
			<view>
				<image src="/static/qiandao.jpg" mode="widthFix" style="width: 100%;border-radius: 10px;"></image>
			</view>
		</view>
	</view>
</template>

<script>
	import prizes from './prizes.js';
	export default {
		data() {
			return {
				list: [], // 当月签到的日期数组
				total: 0, // 签到总天数
			};
		},
		computed: {
			// 今日显示值
			setToDay() {
				return new Date().toLocaleString('ko-KR', {
					day: '2-digit',
					month: '2-digit',
					year: 'numeric',
					timeZone: 'Asia/Seoul',
				});
			},
			fmtDate() {
				const arr = this.setToDay.split('.');
				return `${arr[0].trim()}-${arr[1].trim()}-${arr[2].trim()}`
			},
			// 今日
			toDay() {
				return this.fmtDate.split('-')[2].trim();
			},
			// 今月
			curMonth() {
				return this.fmtDate.split('-')[1].trim();
			},
			// 今年
			curYear() {
				return this.fmtDate.split('-')[0].trim();
			},
			// 当月总天数
			curMonthDays() {
				const days = new Date(this.curYear, this.curMonth, 0);
				return days.getDate();
			},
			// prizes 奖励领取达标天数
			prizes() {
				return prizes
			},
			// 签到奖励档位天数
			checkInDays() {
				return [3, 7, 15, 30, 45, 60, 75, 90, 120, 180];
				// return ['3일', '7일', '15일', '30일', '45일', '60일', '75일', '90일', '120일', '180일'];
			},
			// 当前达成目标下标
			curTag() {
				const temp = this.checkInDays.findIndex(item => item > this.total);
				console.log(`temp:`, temp);
				return temp - 1;
			}
		},
		beforeMount() {
			// 获取已签到日期
			this.getList();
		},
		methods: {
			// 点击日历
			async handleCheckIn(val) {
				// 如果点击日期是今日，并且在返回的日期数组中找不到
				if (val == this.toDay) {
					const temp = this.list.findIndex(item => item == val);
					if (temp < 0) {
						console.log(`temp:`, temp);
						const result = await this.$http.post(`api/user/sginexists`, {
							date: this.fmtDate
						});
						if (!result) return false;
						this.getList();
					}
				}
				// 其他情况:
				return false;
			},
			goBack() {
				uni.switchTab({
					url: '/pages/home/index'
				})
			},

			async getList() {
				const result = await this.$http.post(`api/user/sginlist`);
				if (!result) return false;
				console.log(`user/sgin`, result);
				// 总天数
				this.total = result.length;
				// 格式化数据
				result.forEach(item => {
					const arr = item.data.split('-');
					item.year = arr[0].trim();
					item.month = arr[1].trim();
					item.day = arr[2].trim();
				});
				console.log(`result`, result);
				// 处理，只需要当前月份
				this.list = result.filter(item => item.month == this.curMonth).map(item => Number(item.day));
				console.log(`this.list`, this.list);
			},


			// 设置背景样式
			setStyle(val) {
				// console.log(`val:`, val);
				// 缺签日：
				// 签到日/ 今日已签：
				// 今日未签：
				// const tempToDay = val == this.toDay; // 今日
				// 大于today视为今日之后
				const after = val > this.toDay;
				// 今日 将val在已签到数组中过滤，找到视为已签到，否则视为缺签
				const temp = this.list.filter(item => item == val).length > 0;
				// console.log(`temp:`, temp);

				return {
					backgroundImage: `url(/static/checkin_${after?2: temp ? 1:0}.svg)`,
					backgroundRepeat: `no-repeat`,
					backgroundPosition: `center`,
					backgroundSize: `80% 80%`,
					textAlign: `center`,
					borderRadius: `16rpx`,
					fontSize: `32rpx`,
					fontWeight: `900`,
					width: `100%`,
					height: `80rpx`,
					lineHeight: `80rpx`,
					border: `1px solid #CCC`,
					color: temp ? '#121212' : '#999',
				}

			}
		}
	}
</script>

<style>
</style>