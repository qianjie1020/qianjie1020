<template>
	<view>
		<view class="flex" style=" justify-content: space-between;padding: 20px;">
			<view @click="fanhui()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			
			<view class="bold font-size-17">수익 순위</view>
			
			<view @click="huodong()">
				<image src="/static/wenhao.png" mode="widthFix" style="width: 15px;"></image>
			</view>
		</view>
		
		<view>
			<view style="position: relative;">
				<!-- <image src="/static/csbj.png" mode="widthFix" style="width: 90%;padding: 0px 20px;"></image> -->
				<image :src="item.img"  style="width: 90%;padding: 0px 20px;height: 230px;"></image>
			</view>
			
			<view style="margin-top: -220px;position: absolute;padding: 0px 40px;">
				<view class="bold color-white">
					<view class="font-size-18">{{item.text1}}</view>
					<view class="font-size-18">{{item.text2}}</view>
				</view>
				
				<view class="color-white margin-top-10">
					<view>{{item.text3}}</view>
					<view class="margin-top-5">{{item.text4}}</view>
					<view class="margin-top-5">{{item.text5}}</view>
					
						<view class="margin-top-10">이벤트 기간: {{item.time}}- {{item.endtime}}</view>
						
				</view>
			</view>
			<view style="padding: 0px 20px; ">
				<view class="padding-15 justify-center flex" style="background-color: #ffffff;border-radius: 10px;">
					<view class="text-center bold" style="background-color: #fff;border-radius: 30px;padding: 5px;width: 75%;color: #ff5a44;" @click="cansai" id="cs">{{status}}</view>
				</view>
			</view>
			
			
			<view style="padding: 10px 20px;">
				<view style="background-color: #fff;border-radius: 10px;">
					<view class="flex padding-20">
						<view>
							<image src="/static/pm.png" mode="widthFix" style="width: 20px;"></image>
						</view>
						
						<view class="flex-1 margin-left-15 bold font-size-17">내 순위</view>
						<view class="font-size-10">날짜: {{duringTime}}</view>
					</view>
					
					<view class="font-size-10 text-center">현재 순위가 없습니다.</view>
				</view>
			</view>
			
			<view style="padding: 0px 20px;">
				<view style="background-color: #fff;border-radius: 10px;">
					<view class="flex padding-20 justify-center">
						<view style="color: #ff5a44;">——</view>
					    <view class="bold margin-left-10">현재 순위</view>
						<view style="color: #ff5a44;margin-left: 10px;">——</view>
					</view>
					
					<view class="flex" style="padding: 0px 10px;">
						<view class="flex-1">순위</view>
						<view class="flex-3">사용자</view>
						<view>수익률</view>
					</view>
					<view class="flex" style="padding: 0px 10px;margin-top: 15px;" v-for="(item,index) in contestPmList " :key="index">
						
						<view class="flex-1"  v-if="index+1 ==1"><img src="../static/gold.png" alt="" style="width: 30px;"/></view>
						<view class="flex-1"  v-else-if="index+1 ==2"><img src="../static/yin.png" alt="" style="width: 30px;"/></view>
						<view class="flex-1"  v-else-if="index+1 ==3"><img src="../static/tong.png" alt="" style="width: 30px;"/></view>
						<view class="flex-1" style="padding-left:8px" v-else>{{index+1}}</view>
						<view class="flex-4"><img src="../static/avatar.png" style="width: 30px;vertical-align: middle;margin-right: 5px;"></img><span>{{item.user_info == null ? "": item.user_info.nick_name}}</span></view>
						<view>{{parseFloat(item.shouyilv).toFixed(2)}}%</view>
					</view>
					<view style="margin-top: 20px;color: #fff;">.</view>
					
				</view>
				
			</view>
			
			
			
		</view>
		
		
		
	</view>
</template>

<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
				status:"지금 참여하세요",
				bisaiId: "",
				contestPmList:[],
				duringTime:"",
				item:null
			};
		},
		
		onLoad(option) {
			console.log("打印option的值:",option);
			this.bisaiId = option.id
			this.duringTime = option.date
		},
		onShow() {
			
		},
		onHide() {
			
		},
		created(){
			this.refreshPaiming()
			this.getAccountInfo()
		},
		methods: {
			fanhui(){
				uni.switchTab({
					url:'/pages/account/center'
				})
			},
			huodong(){
				uni.navigateTo({
					url:'/pages/illustrate?id='+this.bisaiId
				})
			},
			async cansai() {
				this.status = "이미 대회에 참가했습니다."
				document.querySelector("#cs").style.backgroundColor="#fef2da"
				const result = await this.$http.get("api/app/contest?id="+this.bisaiId)
				console.log("结果是:",result);
			},
			async getAccountInfo() {
				const result = await this.$http.get(`api/app/onecontest`,{
					id:this.bisaiId,
				});
				if (!result) return false;
				this.item = result;
				// this.item.img = '/static/csbj.png';
			},
			async refreshPaiming() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/app/contest_pm?id=`+this.bisaiId);
				console.log("打印结果:",result)
				const userInfo = await this.$http.get("api/user/info")
				console.log(userInfo);
				for(let i = 0;i < result.length;i++) {
					if(userInfo.uid == result[i].uid) {
						this.status = "이미 대회에 참가했습니다."
						document.querySelector("#cs").style.backgroundColor="#fef2da"
						break;
					}
				}
				this.contestPmList = result
		
			},
		},
	}
</script>

<style>

</style>