<template>
	<view :class="isAnimat?'fade_in':'fade_out'" >
		<!-- <HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond> -->
		<view class="flex padding-20">
			<view @click="fanhui()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			
			<view class="text-center flex-1" style="font-size: 36rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
			{{$lang.ACCOUNT_TRADE_LOG_TITLE}}
			</view>
		</view>
		

		<TabsPrimary :tabs="tabLabels" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<view style="padding: 20rpx 0;">
			<!-- <template v-if="curTab == 0">
				<LogTrade></LogTrade>
			</template> -->

			<template v-if="curTab == 0">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="curTab == 1">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		computed: {
			// tabs的明文
			tabLabels() {
				return [
					// this.$lang.TRADE_LOG_TRADE,
					this.$lang.TRADE_LOG_DEPOSIT,
					this.$lang.TRADE_LOG_WITHDRAW
				];
			}
		},
		onLoad(opt) {
			console.log(opt);
			this.curTab = Number(opt.code) || 0;
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},
		},
	}
</script>