<template>
	<view style="position: relative;">
		<image src="../../static/cc-bj.png" mode="widthFix" style="width: 105%;"></image>
	
	<view :class="isAnimat?'fade_in':'fade_out'" style="width: 100%;height: 150px; position: absolute;bottom: 60%;">
		<HeaderPrimary isSearch isNotify :title="setTitle" :color="$theme.SECOND"></HeaderPrimary>
        <view style="margin-top: 50px;">
		<Profile :info="userInfo"></Profile>

		<view style="display: flex;align-items: center;justify-content: center;margin-top: 20px;">
			<view class="common_card_bg" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemThird :info="cardData" :labels="cardLabels"></CardItemThird>
			</view>
		</view>

		<view class="" style="display: flex;padding:20rpx 30rpx; justify-content: space-between;margin-top: 20px;">
			<view @click="linkDeposit()">
				<!-- <view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_deposit.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view> -->
				<view style="text-align: center;font-size: 28rpx;color:#121212;background-color: #00b45a;padding: 10px 60px;border-radius: 30px;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<!-- <view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/centet_withdraw.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view> -->
				<view style="text-align: center;font-size: 28rpx;color:#121212;background-color: #0293d3;padding: 10px 50px;border-radius: 30px;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<!-- <view @click="linkAuth()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top6.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.AUTH_TITLE}}
				</view>
			</view>

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top7.png" mode="aspectFit" :style="$theme.setImageSize(120)"></image>
				</view>
				<view style="text-align: center;font-size: 28rpx;color:#121212;margin-top: 20rpx;">
					{{$lang.ACCOUNT_SERVICE}}
				</view>
			</view> -->
		</view>



		<view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx 32rpx 0 0;">
			<view
				style="margin:30rpx 40rpx 0 20rpx;font-size: 36rpx;font-weight: 700;line-height: 2.4;border-bottom: 1px solid #F3F3F3;"
				:style="{color:$theme.SECOND}">
				{{$lang.ACCOUNT_MORE_FEATURES}}
			</view>
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view>
			<view style="margin-top: 20px;color: #fff;">.</view>
		</view>
</view>
</view>

	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemThird from '@/components/card/CardItemThird.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemThird
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTitle() {
				if (this.userInfo.real_name) {
					return `${this.$lang.HELLO} ` + this.userInfo.real_name;
				} else {
					return this.$lang.ACCOUNT_CENTER_TITLE;
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkAuth() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_AUTH
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					// value3: this.userInfo.freeze || 0,
					value3: this.userInfo.lianghua || 0,
				};
			},
		},
	}
</script>