<template>
	<view style="padding-bottom: 200rpx;">
		<template v-if="list && list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="padding:30rpx;" @tap="handleShowModal(item)">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view class="bold" :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;line-height: 1.6;">
							{{item.name}}
						</view>
						<view class="flex-1 bold" style="padding: 0px 10px;">{{item.code}}</view>
						<view
							:class="{'common_btn':true,'bukuiColor':item.bukui ==null,'orange':item.bukui =='1','green':item.bukui=='2','red':item.bukui =='3'}"
							style="border-radius: 30px; height:10px;border:0;line-height: 10px;" v-if="item.profit < 0"
							@click.stop="bukui(item.orderId,item.bukui)">{{bukuiStatus(item.bukui)}}</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 10rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_PROFIT_RATE}}</view>
						<view :style="{color:$theme.setStockRiseFall(item.profitRate*1>0)}">
							{{$util.formatNumber(item.profitRate,2)}}%
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_PROFIT_AMOUNT}}</view>
						<view :style="{color:$theme.setStockRiseFall(item.profitRate*1>0)}">
							{{$util.formatMoney(item.profit*1)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_BUY_AMOUNT}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatNumber(item.buyNum)+` ${$lang.QUANTITY_UNIT}`}}
						</text>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_TOTAL_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.totalPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_BUY_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.buyPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_SELL_LABEL_SELL_PRICE}}</view>
						<text :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.sellPrice)+` ${$lang.CURRENCY_UNIT}`}}</text>
					</view>
				</view>
			</block>
		</template>
		<template v-if="isShow">
			<AccountTradeSellInfo :info="itemInfo" @action="handleClose"></AccountTradeSellInfo>
		</template>
	</view>
</template>

<script>
	import CustomTitle from '@/components/CustomTitle.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import AccountTradeSellInfo from './AccountTradeSellInfo.vue';
	export default {
		name: 'AccountTradeSellList',
		components: {
			CustomTitle,
			EmptyData,
			AccountTradeSellInfo,
		},
		data() {
			return {
				list: [], // 持有列表
				isShow: false, // 是否显示弹层
				itemInfo: {}, // 单条数据详情
				curPage: 1, // 当前页码
				maxPage: 1, // 最大页码
			}
		},
		beforeMount() {
			this.getList();
		},
		methods: {
			handleShowModal(item) {
				this.isShow = true;
				uni.hideTabBar(); // 隐藏tabBar
				this.itemInfo = item;
				console.log(this.itemInfo);
			},

			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				uni.showTabBar(); // 显示tabBar

				this.curPage = 1;
				this.list = [];
				this.getList();
			},

			async getList() {
				console.log(`curPage:`, this.curPage);
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/order`, {
					page: this.curPage,
					status: 2, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				console.log(`hold result:`, result);
				this.maxPage = result.last_page; // 記錄最大頁碼
				// 过滤保留合法数据
				const temp = !result.data || result.data.length <= 0 ? [] :
					result.data.filter(item => item.order_buy && item.order_buy.id > 0 &&
						item.order_sell && item.order_sell.id > 0);

				console.log('filter:', temp);
				const tempList = temp.length <= 0 ? [] : temp.map(item => {
					return {
						name: item.goods_info.name,
						// 盈利率计算： 盈利比=（卖出价 - 买入价） / 买入价 *100% 
						profitRate: (item.order_sell.price * 1 - item.order_buy.price * 1) / item.order_buy
							.price * 100,
						profit: item.order_sell.float_yingkui, // 盈利额
						buyNum: item.order_buy.num, // 购买数量

						totalPrice: item.order_sell.amount, // 

						// totalPrice: item.goods_info.current_price * 1 * item.order_buy.num, // 购买总价
						buyPrice: item.order_buy.price, // 买入单价
						sellPrice: item.order_sell.price, // 卖出单价

						// currentPrice: item.goods_info.current_price, // 最新价格
						// 弹层所需数据
						buyCreateTime: item.order_buy.created_at,
						double: item.order_buy.double,
						sellFee: item.order_sell.sell_fee,
						amount: item.order_buy.amount,
						code: item.goods_info.number_code,
						id: item.id,
						// typeId: item.goods_info.project_type_id,
						sellCreateTime: item.order_sell.created_at,
						floatProfit: item.order_sell.float_yingkui * 1, // 浮动盈亏
						orderId: item.order_sell.id,
						bukui: item.order_sell.bukui
					}
				})
				if (tempList.length > 0) {
					this.list.push(...tempList);
				} else {
					this.list = tempList;
				}
				console.log("打印list的内容", this.list);
				console.log(this.list, this.list.length);
			},
			async placeOrder() {
				const money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				const result = await uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.buy();
				}
			},
			async bukui(orderId, bukui) {
				if (bukui == '1' || bukui == '2') {
					return
				}
				const result = await this.$http.get(`api/user/repair`, {
					id: orderId,
				});
				console.log("result", result);
				if (!result) return false;
				uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
				});
				setTimeout(() => {
					this.curPage = 1;
					this.list = [];
					this.getList();
				}, 1000)

				// if (result == null) {
				// 	console.log("结果result是null");
				// 	return
				// }
				// console.log("result:", result);
				// console.log("result.data", result.data);
				// console.log("result !=[]", result.data != []);
				// if (result) {
				// 	console.log("进入到了弹窗");
				// 	this.huancun();
				// 	let timer = setTimeout(() => {
				// 		this.getList()
				// 		timer = null
				// 	}, 2000)
				// }
			},
			// huancun() {
			// 	uni.showToast({
			// 		title: this.$lang.COMMON_QINGCHU,
			// 	})
			// },
			bukuiStatus(bukui) {
				if (bukui == '1') {
					// return "검토중"
					return '심사 중'
				} else if (bukui == '2') {
					// return '제공됨'
					return '승인 완료'
				} else if (bukui == '3') {
					return "미승인"
				}
				// return '손실 보상 신청하기'
				return '손실 보상 신청'
			}
		},
	}
</script>

<style>
	.yellow {
		background-color: yellow;
	}

	,
	.orange {
		//审核中
		background-color: orange;
	}

	,
	.green {
		//审核通过
		background-color: #259345;
	}

	,
	.red {
		//审核未通过
		background-color: #fc4337;
	}

	,
	.bukuiColor {
		// 补亏按钮颜色
		background-color: #23a9f2;
	}
</style>