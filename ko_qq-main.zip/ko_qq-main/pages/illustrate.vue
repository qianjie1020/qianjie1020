<template>
	<view>
		<view class="flex padding-20" style="background-color: #fff;">
			<view @click="fanhui()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="flex-1 text-center font-size-18 bold">활동 설명</view>
		</view>
		
		<view style="padding: 20px;">
			<view style="background-color: #fff;padding: 10px;border-radius: 10px;">
				<view v-html="item.jieshao"></view>
				<!-- <view>활동시간:</view>
				<view>2027.7.1---2024.12.31</view>
				<view class="margin-top-10">주간 보상:</view>
				<view>1.매주 월요일 오전에 가입하세요</view>
				<view>2.금요일 오후 결산 마감</view>
				<view class="margin-top-10">참여 방법 및 조건:</view>
				<view>1.신한투자증권을 이용해야 합니다. 흥한 인텔리전스 트레이딩 플랫폼 계정 참여.</view>
				<view>2.주간대회 등록 조건 : 계좌 총자산이 2천만원 이상이어야 합니다.</view>
				<view>3.매주 월요일 아침, 소프트웨어에서 "참가"를 클릭하여 등록할 해당 주간 대회를 선택하면 시스템이 자동으로 현재 총 자산, 포지션 등을 계산합니다.</view>
				<view>4.총자산 및 거래내역은 금요일 오후 장 마감 후 정산되며, 수익률이 산정됩니다(등록 후 입금액 제외).</view>
				<view class="margin-top-10">선정기준:</view>
				<view>수익률: 투자 기간 동안의 총 수익률입니다.</view>
				<view class="margin-top-10">수상 설정:</view>
				<view>1.1등 : 상금 2천만원</view>
				<view>2.2등 : 현금 1천만원</view>
				<view>3.3등 : 현금 100만원 </view>
				<view>4.참가상 : 대회에 등록하였으나 순위 및 거래내역을 제공하지 않은 참가자 전원에게 20만원 상당의 주유카드를 증정합니다.</view>
				<view class="margin-top-10">월별 보상:</view>
				<view>1.매달 15일에 가입하세요</view>
				<view> 2.주간대회 등록 조건 : 계좌 총자산이 2천만원 이상이어야 합니다.</view>
				<view class="margin-top-10">참여 방법 및 조건:</view>
				<view>1.신한투자증권을 이용해야 합니다.흥한 인텔리전스 트레이딩 플랫폼 참여할 계정입니다.</view>
				<view>2.월간 콘테스트 참가조건 : 총계좌자산 2억원 이상 </view>
				<view>3.15일 매일 아침 소프트웨어에서 "참가"를 클릭하여 등록할 해당 월간 대회를 선택하면 시스템이 자동으로 현재 총 자산, 포지션 등을 계산합니다.</view>
				<view>4.총자산 및 거래내역은 금요일 오후 장 마감 후 정산되며, 수익률이 산정됩니다(등록 후 입금액 제외).</view>
				<view class="margin-top-20">선정기준:</view>
				<view>수익률: 투자 기간 동안의 총 수익률입니다.</view>
				<view class="margin-top-20">수상 설정:</view>
				<view>1.1등 : 상금 2억원</view>
				<view>2.2등 : 상금 1억원 </view>
				<view>3.3등 : 상금 5천만원</view>
				<view>4.참가상 : 콘테스트에 등록했지만 순위를 받지 못하고 거래내역을 제공한 분께는 50만원 상당의 주유카드를 증정합니다.</view>
				<view class="margin-top-20">선정과정:</view>
				<view>시스템은 거래 기록과 수익률을 자동으로 계산하여 선택하며, 수익률이 가장 높은 사람이 승자가 됩니다.</view>
				<view class="margin-top-20">*위 모든 활동보상에 대한 최종 해석권은 신한투자증권에 귀속됩니다*</view>
				<view class="margin-top-20">소속 : 신한투자증권</view> -->
			</view>
			
			
		</view>
	</view>
</template>

<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
				item:null,
			    bisaiId:''
			};
		},
		
		onLoad(op) {
			console.log(op);
			this.bisaiId=op.id;
		},
		onShow() {
			
		},
		onHide() {
			
		},
		created(){
			this.getAccountInfo()
		},
		methods: {
			fanhui(){
				uni.navigateBack({
					delta:1,
				})
			},
			async getAccountInfo() {
				const result = await this.$http.get(`api/app/onecontest`,{
					id:this.bisaiId,
				});
				if (!result) return false;
				this.item = result;
				// this.item.img = '/static/csbj.png';
			},
		},
	}
</script>

<style>
</style>