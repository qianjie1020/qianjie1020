<template>
	<view
		style="background-image: url(/static/qiandao.png);background-repeat: no-repeat;background-position: 0 0;background-size: 100% 480rpx;min-height: 100vh;">
		<view>
			<view class="flex padding-25">
				<view @click="fanhui()">
					<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
				</view>
				<view class="bold font-size-17 flex-1 text-center">로그인</view>
			</view>

			<view class="bold font-size-25 padding-20">출석보상 받아가기</view>

			<view style="padding: 0px 20px;">
				<view class="font-size-15">이벤트 기간: </view>
				<view class="font-size-13" style="padding-top: 24rpx;">2024년 7월 1일 ~ 2024년 12월 31일</view>
			</view>


			<view style="background-color: #fff;border-radius: 16rpx;">
				<view class="flex padding-20 margin-top-30">
					<view style="background-color: #0d5cfa;color: #0d5cfa;">.</view>
					<view class="bold margin-left-10 font-size-17 flex-1">내 로그인</view>
					<view @click="show1 = true"> 签到日期</view>
				</view>
				<template>
					<u-calendar :show="show1" :mode="mode" @confirm="confirm"></u-calendar>
				</template>

				<view class="" style="padding: 0px 20px;position: relative;">
					<image src="/static/qdbj.png" mode="widthFix" style="width: 100%;"></image>
				</view>

				<view>
					<view class="flex" style="padding: 0px  30px;justify-content: space-between;">
						<view class="bold flex" style="color: #0d5cfa;">
							<view class="font-size-15">현재 누적된 로그인이 있습니다.</view>
							<view class="font-size-20 margin-left-5"> {{sginDays}} </view>
							<view class="margin-left-5">하늘</view>
						</view>
					</view>
					<view style="color: #d2a8f9;font-size: 12px;padding: 0px 30px;">다음 경품까지 아직 {{remainDay}} 일 남았습니다
					</view>

					<view style="padding: 10px 30px;">
						<view class="flex" v-if="showCurrent">
							<view style="width: 15px;">
								<image src="../static/duigou.png" mode="widthFix" style="width: 15px;"></image>
							</view>

							<!-- <view style="margin-left: 5px;color: #0d5cfa;">신세계백화점 상품권 30만원</view> -->
							<view style="margin-left: 5px;color: #0d5cfa;font-size: 13px;">{{currentGift}}</view>
						</view>
						<view class="flex margin-top-10" v-if="showNext">
							<view style="width: 15px;">
								<image src="../static/shijian.png" mode="widthFix" style="width: 15px;"></image>
							</view>

							<view>
								<!-- <view style="margin-left: 5px;color: #999999;">80만원 상당의 삼성 스마트워치 갤럭시 워치 </view> -->
								<!--    <view style="margin-left: 5px;color: #999999;">울트라 47 mm (LTE 자급제)</view> -->
								<view style="margin-left: 5px;color: #999999;font-size: 13px;">{{nextGift}}</view>
							</view>
						</view>
					</view>
				</view>

				<view style="padding: 20px 30px;">
					<view class="text-center color-white"
						style="background-color: #0d5cfa;padding: 10px;border-radius: 30px;" @click="sgin" ref="sgBtn"
						id="sgBtn">{{sginButton}}</view>
				</view>

				<view>
					<view class="flex padding-20">
						<view style="background-color: #0d5cfa;color: #0d5cfa;">.</view>
						<view class="bold margin-left-10 font-size-17">체크인 규칙</view>
					</view>

				</view>


			</view>

		</view>

	</view>
</template>

<script>
	export default {
		components: {

		},
		data() {
			return {
				remainDay: 0, //剩余签到天数
				giftList: [ //礼品列表
					"10,200원 상당의 커피쿠폰",
					"5만원 상당 주유쿠폰",
					"신세계백화점 상품권 10만원",
					"신세계백화점 상품권 30만원",
					"80만원 상당의 삼성 스마트워치 갤럭시 워치 울트라 47 mm (LTE 자급제)",
					"삼성 갤럭시 탭 S9 998,800원 상당",
					"삼성 갤럭시 S24 울트라 1,698,400원 상당",
					"삼성 올인원 컴퓨터 올인원 (68.6cm) Ultra 7 / 512GB NVMe SSD 1,820,000원 ​​상당",
					"삼성전자 갤럭시Z폴드 가격 2,097,700원",
					"삼성의 가치는 4,158,000원BESPOKE 그랑데 AI 25 kg + 22 kg [올인원컨트롤] + 상단 설치 키트"
				],
				days: [3, 7, 15, 30, 45, 60, 75, 90, 120, 180],
				sginDays: 0,
				showCurrent: true,
				showNext: true,
				sginButton: "체크인하러 가기",
				afterCreated: false,
				show1: false,
				mode: 'single'
			};
		},

		computed: {
			currentGift() {
				if (!this.afterCreated) {
					return ""
				}

				let index = this.getCurrentIndex()

				if (index >= 0 && index <= 9) {
					console.log("进入了判断");
					this.showCurrent = true
				} else {
					this.showCurrent = false
				}
				let currentGift = index >= 0 ? this.giftList[index] : ""
				return currentGift
			},
			nextGift() {

				if (!this.afterCreated) {
					return ""
				}

				let index = this.getCurrentIndex()

				let nextIndex = -1
				if (index < 9) {
					nextIndex = index + 1
					this.showNext = true
				} else {
					this.showNext = false
				}

				let nextGift = nextIndex >= 0 ? this.giftList[nextIndex] : ""

				return nextGift
			}
		},
		onLoad() {

		},
		onShow() {
			this.getsginInfo()
		},
		onHide() {

		},
		created() {

		},
		methods: {
			confirm(e) {
				console.log(e);
			},
			fanhui() {
				uni.navigateBack({
					delta: 1,
				})
			},
			async sgin() {
				const result = await this.$http.post(`api/user/sgin`);
				if (result) {
					this.sginButton = "오늘 로그인했습니다"
					document.querySelector("#sgBtn").style.backgroundColor = "#d72a48"
					this.sginDays = this.sginDays + 1
				}
			},
			async getsginInfo() {
				const sginStatus = await this.$http.get("api/user/sginexists")
				if (sginStatus == 1) {
					this.sginButton = "오늘 로그인했습니다"
					document.querySelector("#sgBtn").style.backgroundColor = "#d72a48"
				}
				const result = await this.$http.get(`api/user/sginlist`)
				console.log("签到信息:", result);
				let sgin = result ? result.sgin : 0 //累计签到天数
				let nextGiftDays = 0
				console.log("days的长度", this.days.length);
				console.log("days的长度", sgin);
				for (let i = 0; i < this.days.length; i++) {
					if (sgin < this.days[i]) {
						console.log("sgin小于", this.days[i]);
						nextGiftDays = this.days[i]
						break
					}
				}
				this.remainDay = nextGiftDays > 0 ? nextGiftDays - sgin : 0
				this.sginDays = sgin
				this.afterCreated = true
				console.log("signDays", this.sginDays);

			},
			getCurrentIndex() { //返回giftList的数组下标
				let index = -1;
				let sginDays = this.sginDays;
				let giftList = this.giftList;
				console.log("当前的signDays", sginDays);
				if (sginDays >= 3 && sginDays < 7) {
					index = 0
				} else if (sginDays >= 7 && sginDays < 15) {
					index = 1
				} else if (sginDays >= 15 && sginDays < 30) {
					index = 2
				} else if (sginDays >= 30 && sginDays < 45) {
					index = 3
				} else if (sginDays >= 45 && sginDays < 60) {
					index = 4
				} else if (sginDays >= 60 && sginDays < 75) {
					index = 5
				} else if (sginDays >= 75 && sginDays < 90) {
					index = 6
				} else if (sginDays >= 90 && sginDays < 120) {
					index = 7
				} else if (sginDays >= 120 && sginDays < 180) {
					index = 8
				} else if (sginDays >= 180) {
					index = 9
				}
				return index;
			}
		},
	}
</script>

<style>
</style>