<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:30rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_VALUE}" style="font-size: 32rpx;flex:70%;">{{item.goods.name}}
						</view>
						<template v-if="item.status==2">
							<view class="access_btn" @click="subscription(item)"
								style="padding:6rpx 24rpx;margin:0;font-size: 28rpx;line-height: 1.4;">
								{{$lang.TRADE_IPO_SUB}}
							</view>
						</template>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_PUBLIC_PRICE}}</view>
						<view :style="{color:$theme.LOG_VALUE}" style="text-align: right;">
							{{$util.formatNumber(item.price)}}<text style="padding:0 4px">{{$lang.CURRENCY_UNIT}}</text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_SUCCESS_APPLY_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.apply_amount)}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_SUCCESS_NUM_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}" style="text-align: right;">
							{{$util.formatNumber(item.success_num_amount)}}<text
								style="padding:0 4px">{{$lang.CURRENCY_UNIT}}</text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_SUCCESS_AMOUNT}}</view>
						<view :style="{color:$theme.LOG_VALUE}" style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.success)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_IPO_SUCCESS_CT}}</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
						:style="{color:$theme.LOG_LABEL}">
						<view>{{$lang.TRADE_IPO_SUCCESS_ORDER_SN}}</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeIssuanceSuccessLog',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		created(option) {
			this.getList()
		},
		methods: {
			// 우승기록
			async getList() {
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				}
			},

			async subscription(item) {
				const result = await this.$http.post(`api/goods-shengou/pay`, {
					id: item.id
				})
				if (result.code == 0) {
					uni.$u.toast(result.data.message);
					if (result.data.success == 0) {
						setTimeout(() => {
							this.$util.linkCustomerService();
						}, 500)
					} else {
						uni.redirectTo({
							url: this.$paths.TRADE_IPO_SUCCESS,
						});
						this.$router.go(0)
					}
				} else {
					uni.$u.toast(result.message || this.$lang.API_HTTP_ERROR);
				}
			},
		},
	}
</script>