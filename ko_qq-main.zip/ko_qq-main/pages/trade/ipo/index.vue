<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<!-- <HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond> -->
		<view class="flex padding-20">
			<view @click="goBack()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			
			<view class="text-center flex-1" style="font-size: 36rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
				{{$lang.TRADE_IPO_TITLE}}
			</view>
		</view>
		
		<TabsPrimary :tabs="$lang.TRADE_IPO_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab ==0">
			<TradeIPOList></TradeIPOList>
		</template>

		<template v-else-if="curTab==1">
			<TradeIPORecord></TradeIPORecord>
		</template>
		<template v-else>
			<TradeIPOSuccessRecord></TradeIPOSuccessRecord>
		</template>

	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TradeIPOList from './components/TradeIPOList.vue';
	import TradeIPORecord from './components/TradeIPORecord.vue';
	import TradeIPOSuccessRecord from './components/TradeIPOSuccessRecord.vue';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TradeIPOList,
			TradeIPORecord,
			TradeIPOSuccessRecord,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0,
			};
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},
			goBack(){
				uni.switchTab({
					url:'/pages/home/index'
				})
			},
		}
	}
</script>