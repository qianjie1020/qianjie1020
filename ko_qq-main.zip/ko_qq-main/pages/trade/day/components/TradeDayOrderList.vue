<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 28rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_DAY_ORDER_STATUS}}</view>
						<view :style="setStyle(item.status)"> {{item.zt}} </view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_BUY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.money)}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_SUCCESS_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.success)}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;">
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_ORDER_SN}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.ordersn}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_DAY_CREATE_TIME}}
							</view>
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.created_at}}
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeDayOrderList',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			// 申请状态样式
			setStyle(val) {
				// 背景色
				const tempBG = [
					this.$theme.RGBConvertToRGBA('#FFB044', 9),
					this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					this.$theme.RGBConvertToRGBA(this.$theme.THIRD, 9),
				];
				// 文字色
				const tempColor = [
					'#FFB044', this.$theme.PRIMARY, this.$theme.THIRD,
				];
				return {
					// PRIMARY
					backgroundColor: tempBG[val],
					color: tempColor[val],
					borderRadius: `12rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
					minWidth: `80rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},

			// 申请列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				console.log(result);
				this.list = !result || result.length <= 0 ? [] : result.map((item, index) => {
					return {
						...item,
						// 状态值明文、icon
						...this.$theme.setStatusPrimary(item.status),
						// 状态值 样式:字号、字色、背景等
						style: this.$theme.setStatusPrimary(item.status),
					}
				});
			},
		}
	}
</script>