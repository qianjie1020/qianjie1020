<template>
	<view>
		<view class="flex padding-20">
			<view @click="goBack()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="bold text-center flex-1 font-size-18">참가목록</view>
		</view>
		
		<view style="padding: 20px;" @click="cansai(item)" v-for="item in bisaiList">
			<view style="background-color: #fff;border-radius: 10px;padding: 20px;">
				<view class="flex" style="justify-content: space-between;">
					<view class="bold font-size-16">{{item.zhou}}</view>
					<view>
						<image src="/static/arrow-right.png" mode="widthFix" style="width: 10px;"></image>
					</view>
				</view>
				<view class="flex" style="justify-content: space-between;margin-top: 20px;">
					<view >경기 날짜</view>
					<view>
						<view>{{handleTime(item.time,item.endtime)}}</view>
					</view>
				</view>
			<!-- 	<view class="flex" style="justify-content: space-between;margin-top: 20px;">
					<view >参赛人员</view>
					<view>
						<view>785154人</view>
					</view>
				</view> -->
				
			</view>
		</view>
		
	</view>
</template>

<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
				bisaiList:[],
				choose:""
			};
		},
		
		onLoad() {
			
		},
		onShow() {
			
		},
		onHide() {
			
		},
		created(){
			this.init()
		},
		methods: {
			goBack(){
				uni.switchTab({
					url:'/pages/home/index'
				})
			},
			cansai(item){
				console.log(item);
				let time =  item.time
				let endTime = item.endtime
				let arr =  time.split(" ")[0].split("-");
				let arr2 = endTime.split(" ")[0].split("-");
			    let duringTime = arr[0].substring(2)+"."+arr[1]+"."+arr[2]+"-"+arr2[0].substring(2)+"."+arr2[1]+"."+arr2[2];
				
				uni.navigateTo({
					url:'/pages/Check?id='+item.id+"&date="+duringTime
				})
			},
			async init() {
				this.bisaiList = await this.$http.get("api/app/contestlist")
				console.log(this.bisaiList);
			},
			handleTime(time,endtime) {
				let time1 =  time.split(" ")[0]
				let time2 =  endtime.split(" ")[0].split("-")
				let time3 = time2[1]+"-" +time2[2]
				return time1 +"~" + time3
			}
	
		},
	}
</script>


<style>
</style>