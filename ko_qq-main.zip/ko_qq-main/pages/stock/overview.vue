<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderSecond :title="stockTitle" :color="$theme.SECOND"></HeaderSecond>

		<view style="padding-bottom: 20px;">
			<template v-if="stockInfo">
				<StockInfoPrimary :info="stockInfo"></StockInfoPrimary>

				<view class="common_block" style="padding:0px;box-shadow: none;">
					<TabsFourth :tabs="$lang.STOCK_OVERVIEW_TABS" @action="changeTab" :acitve="curTab"></TabsFourth>

					<view :style="{display:curTab==0?'block':'none' }" style="margin-top: 30rpx;">
						<view
							style="display: flex;align-items: center;justify-content: space-around;border-radius: 6rpx;">
							<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key="index">
								<view :style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
									{{item}}
								</view>
							</block>
						</view>
						<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
						</view>
					</view>

					<template v-if="curTab==0">
						<!-- <StockKline :code='code' :id='stockInfo.stock_id' :type="stockInfo.project_type_id" ref="stockLine">
					</StockKline> -->
						<view class="common_btn " @click="linkBuy" style="margin: 20rpx auto;background-color: #3494e3;">
							{{$lang.BTN_BUY}}
						</view>
					</template>

					<template v-if="curTab==1">
						<StockDetail :code='code' :id='stockInfo.stock_id'></StockDetail>
					</template>

					<template v-if="curTab==2">
						<StockNews :code='code' :id='stockInfo.stock_id'></StockNews>
					</template>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import StockDetail from './components/StockDetail.vue'
	import StockNews from './components/StockNews.vue';
	import StockInfoPrimary from './components/StockInfoPrimary.vue';

	import {
		init,
		registerLocale,
		dispose
	} from '@/common/klinecharts.min.js';

	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			TabsFourth,
			StockDetail,
			StockNews,
			StockInfoPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前tab
				code: '', // 股票代码 在外部点击进入是，参数携带
				stockInfo: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				timer: null,
			};
		},
		computed: {
			stockTitle() {
				return this.stockInfo && this.stockInfo.name ?
					this.stockInfo.name : this.$lang.STOCK_OVERVIEW_TITLE
			}
		},

		onLoad(option) {
			this.code = option.code;
			this.product();
		},
		onShow() {
			this.isAnimat = true;
			console.log('stock onShow:', this.curTab)
			if (this.curTab == 0) {
				this.onSetTimeout()
			}
		},
		onHide() {
			this.isAnimat = false;
			this.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.timer);
			this.clearTimer();
		},
		methods: {
			setStyle(val) {
				return {
					padding: `12rpx 32rpx`,
					borderRadius: `16rpx`,
					backgroundColor: val ? '#3494e3' : '#fff',
					color: val ? '#fff' : '#ccc',
				}
			},
			changeTab(val) {
				this.clearTimer();
				console.log('val:', val);
				this.curTab = val;
				if (this.curTab == 0) {
					this.onSetTimeout();
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.genKLineData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
			handleShowKLine(val) {
				this.curKLine = val;
				this.product();
			},

			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb919'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#ffbfb9',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#ffbfb9',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#ffbfb9'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},

			// 买入
			linkBuy() {
				uni.navigateTo({
					url: `${this.$paths.STOCK_BUY}?code=${this.code}`
				});
			},

			// 产品详情
			async product() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				console.log(result);
				if (!result) return false;
				this.stockInfo = result[0];
				// 延时,等DOM渲染
				setTimeout(() => {
					if (!this.kLineChart) {
						this.kLineChart = init('chart-type-k-line');
						this.kLineInit(); // 初始化Kline
					}
					this.genKLineData(); // 获取并生成KLine数据	
				}, 50);
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					stock_id: this.stockInfo.stock_id,
					ac_time: this.curKLine,
					project_type_id: this.stockInfo.project_type_id,
					code: this.stockInfo.code
				})
				console.log('k data:', result);
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "area" : "candle_solid",
					},
				});
				this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(result)
			},
		},
	}
</script>