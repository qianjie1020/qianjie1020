<template>
	<view>
		<view class="flex padding-20">
			<view @click="fanhui()">
				<image src="/static/heizuo.png" mode="widthFix" style="width: 10px;" ></image>
			</view>
			<view class="flex-1 text-center font-size-19">투자 성향 체크리스트</view>
		</view>
	
    <view style="padding: 0px 20px;">
			<view class="text-center font-size-18 color-red bold ">개인 투자자 리스크 감수 능력 설문조사</view>
					<view class="color-red margin-top-15 margin-left-10">본 설문은 두 부분으로 구성되어 있습니다.</view>
					<view class="  color-red margin-top-15">첫 번째 부분은 1번부터 8번까지의 문항으로, 개인 재무 상황에 관한 설문입니다. 이 부분에서는 귀하의 개인 재무 상황에 관한 질문들이 있으며, 이는 고객의 리스크 수용 패턴을 더 잘 파악하는 데 도움이 됩니다. 귀하의 개인정보 보호를 약속드리니 안심하고 작성해 주시기 바랍니다.
			</view>
			        <view class="  color-red margin-top-15 ">두 번째 부분은 9번부터 28번까지의 문항으로, 리스크 수용 능력 테스트 설문입니다.
			</view>
		
		
        <u-checkbox-group
            v-model="checkboxValue1"
            placement="column"
            @change="checkboxChange"
        >
            <u-checkbox
                :customStyle="{marginBottom: '8px'}"
                v-for="(item, index) in checkboxList1"
                :key="index"
                :label="item.name"
                :name="item.name"
            >
            </u-checkbox>
        </u-checkbox-group>
    </view>
	</view>
</template>
<script>
export default {
    data() {
        return {
            checkboxValue1:[],
            // 基本案列数据
            checkboxList1: [{
                    name: '苹果',
                    disabled: false
                },
                {
                    name: '香蕉',
                    disabled: false
                },
                {
                    name: '橙子',
                    disabled: false
                }
            ],
        }

    },
    methods: {
        checkboxChange(n) {
            console.log('change', n);
        },
		fanhui(){
			uni.switchTab({
				url:'/pages/account/center'
			});
		},
		
    }
}
</script>