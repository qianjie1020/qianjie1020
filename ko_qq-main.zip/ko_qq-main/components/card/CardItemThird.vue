<template>
	<view>
		<view style="display: flex;align-items: center;">
			<!-- <image src="/static/card_icon_3.png" mode="aspectFit" :style="$theme.setImageSize(120)"
				style="padding-right: 40rpx;"></image> -->
			<view>
				<view style="display: flex;align-items: center;line-height: 1.6;">
					<view style="color:#666666;font-size: 40rpx;">
						<!-- {{labels[0]}} -->
						총 자산
					</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}_dark.png`"
						@click.stop="handleShowAmount" :style="$theme.setImageSize(40)" style="margin-left: 20rpx;">
					</image>
				</view>
				<view style="font-size: 48rpx;font-weight: 500;line-height: 1.6;" :style="{color:$theme.SECOND}">
					{{showAmount?$util.formatMoney(info.value1)+' '+ '원':hideAmount}}
				</view>
			</view>
		</view>
		<view style="display: flex;align-items: center;margin-top: 15rpx;">
			<view style="flex:1 0 50%;">
				<view style="color:#666666;font-size: 30rpx;">
				<!-- {{labels[1]}} -->사용 가능 금액
				</view>
				<view style="font-size: 30rpx;" :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.value2)+' '+ '원':hideAmount}}</view>
			</view>
			<view style="flex:1 0 50%;">
				<view style="color:#666666;font-size: 30rpx;">
				<!-- {{labels[2]}} -->퀀트 ( 트레이딩 ) 
				</view>
				<view style="font-size: 30rpx;" :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.value3)+' '+ '원':hideAmount}}</view>
			</view>
			<!-- <view style="flex:1 0 50%;">
				<view style="color:#666666;font-size: 30rpx;">{{labels[2]}}</view>
				<view style="font-size: 30rpx;" :style="{color:$theme.SECOND}">{{showAmount?$util.formatMoney(info.value3):hideAmount}}</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CardItemThird',
		props: {
			info: {
				type: Object,
				default: {}
			},
			// label。单独分开，否则会因数据请求慢，导致label未加载
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
			}
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
		}
	}
</script>

<style>
</style>