<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color:#FFFFFF;">
			<HeaderSecond :title="$lang.ADDRESS_ADD_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="margin: 20px;padding-bottom: 100rpx;min-height: 100vh;">
			<view style="font-size: 28rpx;font-weight: 700;" :style="{color:$theme.SECOND}">
				{{$lang.ADDRESS_CHOOSE_COIN}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;"
				@tap="chooseCoin()">
				<view>{{curCoin}}</view>
				<image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)"></image>
			</view>

			<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
				{{$lang.ADDRESS_WALLET_ADDRESS}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;">
				<input v-model="address" type="text" :placeholder="$lang.ADDRESS_WALLET_ADDRESS"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>
		</view>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
		
		<view style="position: fixed;bottom: 60px;left: 0;right: 0;" v-if='id'>
			<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: crimson;" @click="deladdress()">
				Delete
			</view>
		</view>
		
		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		// 变更登入密码、变更支付密码。
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				curCoin: 'ERC20-USDT', // 当前选中Coin
				address: '', // 钱包地址
				id:""
			};
		},
		computed: {
			coinList() {
				return ['ERC20-USDT', 'TRC20-USDT','BTC','ETH']
			},
		},
		onLoad(op) {
			if(op.id){
				this.id=op.id
				this.getaddress()
			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 選擇一種coin
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curCoin = e.value[0];
				this.address = ''; // 切换选择后，清空输入的地址
				this.isShowCoinList = false;
			},
			async getaddress() {
				const result = await this.$http.post(`api/user/getaddress`, {
					id:this.id
				});
				if (!result) return false;
				
				let index = this.coinList.indexOf(result.huobi);
				this.curCoin=result.huobi
				console.log(11111,result,index)
				this.address=result.address
				
			},
			async deladdress() {
				const result = await this.$http.post(`api/user/deladdress`, {
					id:this.id
				});
				if (!result) return false;
				console.log(result)
				uni.showToast({
					title: 'Successfly',
					icon: 'success'
				})
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ADDRESS_INDEX
					});
				}, 1000);
			},
			async handleSubmit() {
				if (!this.address || this.address.length <= 0) {
					uni.showToast({
						title: this.$lang.ADDRESS_TIP_ENTER_ADDRESS,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					address: this.address,
					type: 2,
					huobi: this.curCoin, // huobi: ERC20-USDT / TRC20-USDT
					// 未用到
					realname: '',
					bank_name: '',
					bank_sub_name_address: '',
					bank_code: '',
					id:this.id
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: 'Successfly',
					icon: 'success'
				})
				setTimeout(() => {
					uni.redirectTo({
						url: this.$paths.ADDRESS_INDEX
					});
				}, 1000);
			},
		}
	}
</script>

<style>
</style>