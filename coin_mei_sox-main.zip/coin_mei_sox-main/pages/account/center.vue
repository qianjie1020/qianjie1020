<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<HeaderPrimary isSearch :title="$lang.ACCOUNT_CENTER_TITLE" :color="$theme.SECOND"></HeaderPrimary>

		<!-- <Profile :info="userInfo"></Profile> -->

		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_4" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemSecond :info="cardData" :labels="cardLabels"></CardItemSecond>
			</view>
		</view>

		<view class="common_block"
			style="display: flex;align-items: center;justify-content: space-between;border-radius: 24rpx;padding:20rpx 60rpx;">
			<view @click="linkDeposit()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top1.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.DEPOSIT_TITLE}}
				</view>
			</view>

			<view @click="linkWithdraw()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top2.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.WITHDRAW_TITLE}}
				</view>
			</view>
			<view @click="linkTransfer()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.TRANSFER_TITLE}}
				</view>
			</view>

			<view @click="linkService()">
				<view style="display: flex;align-items: center;justify-content: center;">
					<image src="/static/top4.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
				</view>
				<view style="text-align: center;font-size: 26rpx;color:#121212;line-height: 1.4;">
					{{$lang.ACCOUNT_SERVICE}}
				</view>
			</view>
		</view>

		<!-- 資金賬戶 合約賬戶 -->
		<view style="display: flex;align-items: center;margin:0 40rpx;">
			<block v-for="(item,index) in setTabs" :key="index">
				<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
					{{item}}
				</view>
			</block>
		</view>

		<view style="display: flex;align-items: center;justify-content: flex-end;padding-right: 40rpx;">
			<view style="padding-right: 12rpx;">{{$lang.ACCOUNT_HIDE_ZERO_DATA}}</view>
			<u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" label="" v-model="isHideZero"
					labelColor="#666666" labelSize="24rpx" @change="changeHideZero" :checked="isHideZero"
					iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group>
		</view>


		<!-- <view style="background-color: #FFFFFF;margin:20rpx;border-radius: 32rpx 32rpx 0 0;">
			<view
				style="margin:30rpx 40rpx 0 20rpx;font-size: 36rpx;font-weight: 700;line-height: 2.4;border-bottom: 1px solid #F3F3F3;"
				:style="{color:$theme.SECOND}">
				{{$lang.ACCOUNT_MORE_FEATURES}}
			</view>
			<FeatureListPrimary :code="userInfo.is_check"></FeatureListPrimary>

			<view style="margin-top: 120rpx;padding-bottom: 60rpx;">
				<SignOut></SignOut>
			</view>
		</view> -->


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/account/Profile.vue';
	import FeatureListPrimary from '@/components/account/FeatureListPrimary.vue';
	import AccountAssets from '@/components/account/AccountAssets.vue';
	import SignOut from '@/components/SignOut.vue';
	import CardItemSecond from '@/components/card/CardItemSecond.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			FeatureListPrimary,
			AccountAssets,
			SignOut,
			CardItemSecond
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				cardData: {}, // 资产卡
				curTab: 0, // assets or contract
				isHideZero: false, // 是否過濾掉0餘額

			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
			setTabs() {
				return [
					this.$lang.ACCOUNT_TAB_ASSETS_TITLE,
					this.$lang.ACCOUNT_TAB_CONTRACT_TITLE
				]
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo()
		},
		onHide() {
			this.isAnimat = false;
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			changeTab(val) {
				this.curTab = val;
			},

			// 過濾掉0餘額數據
			changeHideZero(e) {
				this.isHideZero = e;
				if (this.isHideZero) {
					console.log('filter!', e);
				}
			},

			// 设置样式
			setStyle(val, w = 120) {
				// const temp = this.curTab == 0 ? this.$theme.RISE : this.$theme.FALL;
				return {
					minWidth: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#F6F8FC',
					color: val ? '#FFFFFF' : '#666666',
					borderRadius: `44rpx`,
				}
			},
			// 提款
			linkWithdraw() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_WITHDRAW
				})
			},
			// 存金
			linkDeposit() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_DEPOSIT
				})
			},
			linkTransfer() {
				uni.navigateTo({
					url: this.$paths.TRANSFER_INDEX
				})
			},
			linkService() {
				uni.navigateTo({
					url: this.$util.linkCustomerService()
				})
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				this.userInfo = result;
				this.cardData = {
					value1: this.userInfo.totalZichan || 0,
					value2: this.userInfo.money || 0,
					value3: this.userInfo.freeze || 0,
				};
			},
		},
	}
</script>