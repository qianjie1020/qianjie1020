<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="common_header" style="background-color: #FFFFFF;">
			<view class="left"  @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.TRANSFER_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="padding:40rpx; padding-bottom: 200rpx;">
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: #FFFFFF;">
				<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{curCoin}}</view>
				<!-- <image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)"></image> -->
			</view>

			<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;" :style="{color:$theme.SECOND}">
				{{$lang.TRANSFER_IN_ACCOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: #FFFFFF;"
				@tap="chooseIn()">
				<view>{{curTransferIn}}</view>
				<image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)"></image>
			</view>

			<template v-if="curTransferIn!=''">
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 40rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRANSFER_BALANCE}}
					</view>
					<view :style="{color:$theme.SECOND}">{{transferInMoney+` `+this.curCoin}}</view>
				</view>
			</template>

			<view style="font-size: 28rpx;font-weight: 700;margin-top: 20rpx;margin-top: 40rpx;"
				:style="{color:$theme.SECOND}">
				{{$lang.TRANSFER_OUT_ACCOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: #FFFFFF;"
				@tap="chooseOut()">
				<view>{{curTransferOut}}</view>
				<image src="/static/arrow_down_solid.png" mode="aspectFit" style="margin-left: auto;"
					:style="$theme.setImageSize(16)"></image>
			</view>

			<template v-if="curTransferOut!=''">
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 40rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.TRANSFER_BALANCE}}
					</view>
					<view :style="{color:$theme.SECOND}">{{transferOutMoney+` `+this.curCoin}}</view>
				</view>
			</template>

			<view style="font-size: 28rpx;font-weight: 700;margin-top: 40rpx;" :style="{color:$theme.SECOND}">
				{{$lang.TRANSFER_AMOUNT}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 10rpx;border:1px solid #E8EAF3;border-radius: 16rpx;padding-left: 40rpx;background-color: #FFFFFF;">
				<input v-model="amount" type="digit" :placeholder="$lang.TRANSFER_AMOUNT"
					:placeholder-style="$theme.setPlaceholder()"></input>
				<view style="margin-left: auto;padding-right: 40rpx; color:#999;">{{curCoin}}</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>

		<!-- Coin  選擇器 -->
		<!-- <u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="code"
			visibleItemCount="9"></u-picker> -->

		<!-- 转入账户 -->
		<u-picker :show="isShowIn" :columns="[transferList]" @change="changeIn" @cancel="isShowIn=false"
			@confirm="confirmIn" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
		<!-- 转出账户 -->
		<u-picker :show="isShowOut" :columns="[transferList]" @change="changeOut" @cancel="isShowOut=false"
			@confirm="confirmOut" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isAnimat: false, // 页面动画
				curCoin: 'USDT', // 固定值
				assetsMoney: '', // assets usdt money
				contractMoney: '', // contract money
				amount: '', // 划转金额
				isShowIn: false, // 转入账户选择器
				isShowOut: false, // 转出账户选择器
				curTransferIn: '', // 当前转入账户
				curTransferOut: '', // 当前转出账户
				QIQUANMoney:""
			};
		},
		computed: {
			// 转出转入
			transferList() {
				return [this.$lang.TRANSFER_ASSETS_TITLE, this.$lang.TRANSFER_CONTRACT_TITLE,this.$lang.TRANSFER_Options_TITLE]
			},
			transferInMoney() {
				const temp = this.curTransferIn.includes(this.transferList[0]);
				return temp ? this.assetsMoney : (this.curTransferIn.includes(this.transferList[1])?this.contractMoney:this.QIQUANMoney);
			},
			transferOutMoney() {
				const temp = this.curTransferOut.includes(this.transferList[0]);
				return temp ? this.assetsMoney : (this.curTransferOut.includes(this.transferList[1])?this.contractMoney:this.QIQUANMoney);
			},
		},
		onShow() {
			this.isAnimat = true;
			this.curTransferIn = this.transferList[0];
			this.curTransferOut = this.transferList[1];
			this.transferBalance();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRANSFER_RECORD
				})
			},
			// 转入账户
			chooseIn() {
				this.isShowIn = true;
			},
			changeIn(e) {
				console.log(`changeIn e:`, e);
			},
			confirmIn(e) {
				console.log(`confirmIn e:`, e);
				this.curTransferIn = e.value[0];
				this.isShowIn = false;
				const temp = this.transferList.findIndex(item => item == this.curTransferIn);
				if(this.curTransferIn==this.curTransferOut){
					this.curTransferOut = temp == 0 ? this.transferList[1] : this.transferList[0];
				}
				
				console.log(`??`, this.curTransferIn, this.transferList[0],this.curTransferOut);
				this.transferBalance();

			},
			// 转出
			chooseOut() {
				this.isShowOut = true;
			},
			changeOut(e) {
				console.log(`changeOut e:`, e);
			},
			confirmOut(e) {
				console.log(`confirmOut e:`, e);
				this.curTransferOut = e.value[0];
				this.isShowOut = false;
				const temp = this.transferList.findIndex(item => item == this.curTransferOut);
				if(this.curTransferIn==this.curTransferOut){
					this.curTransferIn = temp == 0 ? this.transferList[1] : this.transferList[0];
				}
				this.transferBalance();
			},
			// 转出转入选定后，根据选定值请求资产或合约的余额
			transferBalance() {
				if (this.curTransferIn.includes(this.transferList[0])) this.getAssets();
				if (this.curTransferIn.includes(this.transferList[1])) this.getContarct(1);
				if (this.curTransferIn.includes(this.transferList[2])) this.getContarct(3);
				
				if (this.curTransferOut.includes(this.transferList[0])) this.getAssets();
				if (this.curTransferOut.includes(this.transferList[1])) this.getContarct(1);
				if (this.curTransferOut.includes(this.transferList[2])) this.getContarct(3);
			},

			async getAssets() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/user/assets`, {
					type: 2 // assets
				});
				if (!result) return false;
				console.log(`result:`, result);
				// 只需要 USDT 的 name 和money
				const temp = result.filter(item => item.name = this.curCoin);
				this.assetsMoney = temp.length <= 0 ? 0 : temp[0].money;
				console.log(`assetsMoney:`, this.assetsMoney);
			},
			async getContarct(type) {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/user/assets`, {
					type: type, // contract
					name: this.curCoin, //'USDT'
				});
				if (!result) return false;
				console.log(`result:`, result);
				// 只需要 USDT 的 name 和money
				const temp = result.filter(item => item.name = this.curCoin);
				if(type==3){
					this.QIQUANMoney = temp.length <= 0 ? 0 : temp[0].money;
				}else{
					this.contractMoney = temp.length <= 0 ? 0 : temp[0].money;
				}
				console.log(`contractMoney:`, this.contractMoney);
			},

			async handleSubmit() {
				if (this.curTransferIn == '') {
					uni.showToast({
						title: this.$lang.TRANSFER_IN_ACCOUNT,
						icon: 'none'
					})
					return false;
				}
				if (this.curTransferOut == '') {
					uni.showToast({
						title: this.$lang.TRANSFER_OUT_ACCOUNT,
						icon: 'none'
					})
					return false;
				}
				if (this.curTransferIn == this.curTransferOut) {
					uni.showToast({
						title: this.$lang.TRANSFER_TIP,
						icon: 'none'
					});
					return false;
				}
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.WITHDRAW_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/huazhuan`, {
					num: this.amount,
					coin: this.curCoin,
					// 1代表转出是资金   2代表转入是资金
					type1: this.curTransferIn.includes(this.transferList[0]) ? 2 : (this.curTransferIn.includes(this.transferList[1])?1:3),
					type2: this.curTransferOut.includes(this.transferList[0]) ? 2 : (this.curTransferOut.includes(this.transferList[1])?1:3),
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});

				setTimeout(() => {
					this.linkRecord();
				}, 1000)

			},

			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					color: '#6D41FF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>