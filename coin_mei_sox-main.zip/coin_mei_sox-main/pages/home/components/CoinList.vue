<template>
	<view>
		<view class="flex flex-b gap10 padding-10">
			
			<view v-for="(item, key, index) in list" :key="key" v-if="index < 3" style="background-color: #fff;padding: 20px;" class="flex-1 text-center radius30">
				<view class="font-size-10">{{item.name}}</view>
				<view  class="font-size-10" :style="$theme.setStockRiseFall(item.rate>0)">
					{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
				</view>
				<view style="font-size: 34rpx;font-weight: 700;color: #000;">
					{{item.current_price}}
				</view>
			</view>
		</view>
		
		<view style="padding: 10px;">
			<image src="/static/home1.png" mode="widthFix" style="width: 100%;"></image>
		</view>
		
		<view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.TABBAR_MARKET">
				<view style="font-size: 13px;margin-left: auto;" @click="linkMarket()" :style="{color:$theme.SECOND}">
					{{$lang.COMMON_MORE}}
					<view class="arrow rotate_45" :style="$theme.setImageSize(12)"></view>
				</view>
			</TitlePrimary>
		</view>
		
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;padding:40rpx;">
					<view style="display: flex;align-items: center;" @click="linkInfo(item.code)">
						<view style="margin-right: auto;">
							<CustomLogo :logo="item.logo" :name="item.name" :size="50"></CustomLogo>
						</view>
						<view style="padding-left: 30rpx;flex:auto">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 60rpx;font-size: 28rpx;" class="flex-1" :style="{color:$theme.SECOND}">
									{{item.name}}
								</view>
								<view style="font-size: 32rpx;font-weight: 500;color: #333333;"  class="flex-1">
									{{item.current_price}}
								</view>
								<view   class="flex-1 text-right" :style="$theme.setStockRiseFall(item.rate>0)">
									{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
					<view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;line-height: 1.4;">
						{{`24H: ` }}<template v-if="item.vol">{{item.vol}}</template>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		name: 'CoinList',
		components: {
			EmptyData,
			CustomLogo,
			TitlePrimary,
		},
		data() {
			return {
				gpIndex: 0,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
				list3:""
			};
		},
		created() {
			this.getList();
		},

		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			isValidIndex(index) {  
				// this.iindex=this.iindex+1;
				// console.log(this.iindex <= 2)
				// return this.iindex <= 2;  
			},
			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$paths.MARKET_INDEX + `?type=0`,
				})
			},
			// 跳转到 coin trade index
			linkInfo(code) {
				uni.reLaunch({
					url: this.$paths.COIN_INDEX + `?code=${code}`
				});
			},

			// websocket链接
			connect() {
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WS_COIN_URL);
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {
							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/list`, {
					page: this.curPage,
					gp_index: this.gpIndex
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				if (this.socket) this.disconnect();
				this.connect(); // 启动 websocket链接
			}
		}
	}
</script>

<style>
</style>