<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="common_header" style="background-color: #FFFFFF;">
			<view class="left"  @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.TRADE_IPO_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="padding-bottom: 200rpx;">

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block" style="border-radius: 24rpx;" @tap="linkDetail(item.id)">
						<view style="display: flex;align-items: center;">
							<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
							<view style="padding-left: 20rpx;font-size: 32rpx;" :style="{color:$theme.SECOND}">
								{{item.goods.name}}
							</view>
							<view style="margin-left: auto;">
								<view class="common_tag" :style="setStyle(item.data)">
									{{item.end_day+` `+$lang.TRADE_IPO_LIST_DAY}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between; line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_LIST_TOTAL}}</view>
							<view :style="{color:$theme.SECOND}">{{item.fa_amount}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 2.4;">
							<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_CT}}</view>
							<view :style="{color:$theme.LOG_VALUE}">{{item.shengou_date}}</view>
						</view>
						<!-- 动态进度 余力 -->
						<view style="background-color: #E8E8E8;border-radius: 24rpx;position: relative;height: 20rpx;">
							<view
								style="position: absolute;left: 0;right: 0;top:0;bottom: 0; background-color: #121212;border-radius: 24rpx;"
								:style="{width:setWidth(item.fa_amount*1,item.sell_num*1)*100 +`%`}">
							</view>
						</view>
						<view style="display: flex;align-items: center;line-height: 1.8;">
							<view :style="{color:$theme.SECOND}">{{$lang.TRADE_IPO_LIST_RC+ ` `}}
								{{$util.formatNumber(setWidth(item.fa_amount*1,item.sell_num*1)*100,2) +`%`}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';

	export default {
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: []
			};
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO_DETAIL + `?id=${val}`,
				})
			},
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_IPO_RECORD
				})
			},

			// 计算每条数据的进度百分比 fa_amount - sell_num
			setWidth(val1, val2) {
				const tempVal1 = val1 * 1;
				const tempVal2 = val2 * 1;
				return tempVal2 / tempVal1;
			},


			setStyle(val) {
				const temp = val == 1 ? this.$theme.FALL : this.$theme.RISE;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			// tab切换
			changeTab(val) {
				this.curTab = val;
			},

			// 获取列表
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods-shengou/calendar`, {
					type: 1, // 传参 1或2
				})
				console.log(result);
				this.list = result;
			},
		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>