<template>
	<header class="common_header">
		<!-- <template v-if="!isRtl"> -->
		<view class="custom_header_left" @click="$util.goBack()">
			<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
		</view>
		<!-- 	</template> -->
		<text class="custom_header_center" :style="{color:color}">{{title}}</text>
		<!-- <template v-if="isRtl">
			<view class="custom_header_right"  @click="$util.goBack()">
				<view class="arrow rotate_45" :style="arrowStyle"></view>
			</view>
		</template> -->
	</header>
</template>

<script>
	export default {
		name: 'HeaderSecond',
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#333333'
			},
		},
		data() {
			return {};
		},
		computed: {
			// 设置回退箭头的样式
			arrowStyle() {
				return {
					...this.$theme.setImageSize(20),
					// 通常与标题文字同色
					borderColor: this.color
				}
			}
		},
		methods: {}
	}
</script>

<style>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;
		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
	}

	.custom_header_left {
		/* flex: 10%; */
		margin-right: auto;
	}

	.custom_header_left>image {
		width: 24px;
		height: 24px;
	}

	.custom_header_center {
		display: block;
		color: #333333;
		font-size: 32rpx;
		padding: 0 10px;
		flex: 80%;
		text-align: center;
		font-weight: 100;
	}

	.custom_header_right {
		margin-left: auto;
	}
</style>