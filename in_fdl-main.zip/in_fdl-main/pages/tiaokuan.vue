<template>
	<view>
		<view class="flex" style="background-color: #fff;height: 50px;">
			<view class="flex-1">
				<image src="../static/jiantouo.png" mode="widthFix" style="width: 25px;height: 25px;"
					@click="$u.route({url:'/pages/account/sigin'});"></image>
			</view>
			<view class="flex-2 font-size-20">Privacy Policy</view>
		</view>

		<view style="width: 85%;margin-left: 30px;margin-top: 20px;">
			<view>The promotional offer is being managed by Fidelity Investment Group.</view>

			<view style="margin-top: 10px;">The risk management policies and other internal policies of FIGFIIA
				applicable on the clients and trades executed by them would be applicable on
				the trades.</view>

			<view style="margin-top: 10px;">Transactions charges of 0.02 % will be applied for
				the trade on both buying and selling,and a stamp
				duty charges of 0.15 %. Please note that these
				charges will be deducted automatically from your
				account at the time of the trade.</view>

			<view style="margin-top: 10px;">STT, Stamp Duty, Transaction charges, GST and
				other charges will be levied separately as
				applicable.
			</view>

			<view style="margin-top: 10px;">Brokerage will not exceed the SEBI prescribed
				limit.</view>

			<view style="margin-top: 10px;">An investor will receive an advisor and qualify as a
				private wealth investor only if they have a margin
				of Rs. 3,00,000 or more in their account after
				opening.</view>

			<view style="margin-top: 10px;">There is no restriction on withdrawal of unutilized
				account opening/margin amount.</view>

			<view style="margin-top: 10px;">Fidelity Investments is a prominent financial services firm based in Boston,
				USA. Established in 1946 by Edward C. Johnson II, it is now led by his granddaughter, Abigail Johnson.
			</view>

			<view style="margin-top: 10px;">Fidelity operates in many countries around the world, with offices and
				subsidiaries in regions including Europe and Asia. Their international business includes global asset
				management, cross-border investment solutions, and international brokerage services.
			</view>

			<view style="margin-top: 10px;">Accounts would be made accessible once the
				registration process has been successfully
				completed. For the purpose of verifying real
				names an account would be established documents would be collected in a digital format.</view>
				<view style="margin-top: 10px;color: #fff;">.</view>
		</view>
	</view>

</template>

<script>
</script>

<style>
</style>