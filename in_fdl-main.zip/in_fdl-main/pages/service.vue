<!-- 客服 -->
<template>
	<view>
		<!-- 客服页面之一 -->
		<template>
			<web-view :src="list"></web-view>
		</template>
		
		<!-- 另一种客服页面 -->
		<!-- <image :src="lineimg"  mode="widthFix" style="margin-left: 20%;width: 60%;margin-top: 50px;" ></image>
		<view class="padding-20">
			<view class="text-center font-size-16">Add LINE friends via QR code</view>
					<view class="text-center font-size-14 hui">Open the Friends tab in the INE app and tap the Add Friend icon.
Select 'QR Code' in the top right corner, then scan this QR code.</view>
		</view>
		 
		
		<u-button type="primary" @click="saveImg()" text="QR 코드 저장" style="width: 90%;margin-left: 5%;" size="large"></u-button>
		<u-button type="success" @click="link()" text="LINE 열기" style="width: 90%;margin-left: 5%;margin-top:20px" size="large"></u-button>
		
		<view class="padding-20">
			 <view class="text-center font-size-14 red" >"If the "LINE Delivery" button does not jump properly, click the button below and copy it to your mobile browser to open it.</view>
		</view>
		
		<u-button type="error" @click="fuzhi()" text="LINE 링크 복사" style="width: 90%;margin-left: 5%;margin-top:20px" size="large"></u-button> -->
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
				// lineimg:"/static/kefu/line.png"
			};
		},
		mounted() {
			this.get_url()
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},
			async get_url() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				this.list = list.data.data[8].value
			},
			
			// saveImg() {
			// 	var oA = document.createElement("a");
			// 	oA.download = ''; // 设置下载的文件名，默认是'下载'
			// 	oA.href = this.lineimg;
			// 	document.body.appendChild(oA);
			// 	oA.click();
			// 	oA.remove(); // 下载之后把创建的元素删除
			// },
			// fuzhi(){					
			// 	let info=this.list
			// 	// #ifndef H5
			// 	//uni.setClipboardData方法就是讲内容复制到粘贴板
			// 	uni.setClipboardData({
			// 		data: info,//要被复制的内容
			// 		success:() => {//复制成功的回调函数
			// 			uni.showToast({//提示
			// 				title:'복사가 완료되었습니다. 붙여넣고 브라우저에서 열어주세요.' 
			// 			})
			// 		}
			// 	});
			// 	// #endif
				
			// 	 // #ifdef H5 
			// 		let textarea = document.createElement("textarea")
			// 		textarea.value = info
			// 		textarea.readOnly = "readOnly"
			// 		document.body.appendChild(textarea)
			// 		textarea.select() // 选中文本内容
			// 		textarea.setSelectionRange(0, info.length) 
			// 		uni.showToast({//提示
			// 			title:'복사가 완료되었습니다. 붙여넣고 브라우저에서 열어주세요.' 
			// 		})
			// 		result = document.execCommand("copy") 
			// 		textarea.remove()    
			// 	// #endif
							
			// },
			// link(){
			// 	window.open(this.list, '_blank');
			// },
		},
		
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	iframe {
		width: 600px !important;
	}

	.college-content {
		width: 100%;
		height: 100%;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>