<!-- 下单 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader :title="!detailedData?'':detailedData.name" @action="handleBack()"></CustomHeader>
		</view>

		<template v-if="userInfo">
			<view
				style="display: flex;flex-direction: column;justify-content: space-around;align-items: center;margin-top: 10px;">
				<view :style="{color:$util.THEME.TIP}"> Current Balance</view>
				<view style="font-size: 36px;font-weight: 700" :style="{color:$util.THEME.TEXT_DARK}">
					₹{{$util.formatNumber(userInfo.money)}}
				</view>
			</view>
		</template>

		<template v-if="detailedData">
			<view class="common_block" style="padding:10px;">
				<view class="flex padding-bottom-10">
					<view style="margin-left: 10px;" :style="{color:$util.THEME.TEXT}">{{detailedData.name}}</view>

					<view class="text-right flex-1 bold margin-right-20">
						<view :style="{color:$util.THEME.TEXT}">
							{{$util.formatNumber(detailedData.current_price,2)}}
						</view>
						<view :style="$util.calcStyleRiseFall(detailedData.rate>0)">{{detailedData.rate}}%</view>
					</view>
				</view>
				<view class="margin-top-20" :style="{color:$util.THEME.TIP}">Quantity</view>

				<view class="btns">
					<block v-for="(item,index) in quantityList" :key="index">
						<view class="item" style="flex:30%;margin:4px;" :class="curQuantity==item?'actity':'noactity'"
							@click="handleSelected(item)">{{item}}</view>
					</block>
				</view>

				<view class="common_input_wrapper"
					style="background-color: rgba(198, 198, 198,0.2);border: 1px solid #C6C6C6;">
					<view style="width: 20px;"></view>
					<input v-model="quantity" type="number" placeholder="Please Enter Quantity" @input="handleInput"
						:placeholderStyle="$util.setStylePlaceholder()"></input>
				</view>

				<!-- 若后台开启杠杆，此处条件成立，页面会显示杠杠选择 -->
				<!-- <template v-if="userInfo.ganggan">
				<view class="margin-top-20" :style="{color:$util.THEME.TIP}">
					Choose your leverage
				</view>
				<view class="margin-top-10 text-center">
					<u-grid :border="false" col="3">
						<u-grid-item v-for="(item,index) in userInfo.ganggan">
							<view style="width: 90%;" :class="ganggan==item?'actity':'noactity'" @click="ganggan=item">
								{{item}}
							</view>
						</u-grid-item>
					</u-grid>
				</view>
			</template> -->


				<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
					<view class="flex-1">Amount of payment</view>
					<view class="flex-1 text-right"><text
							v-if="detailedData.project_type_id==2"></text>{{detailedData.current_price*this.quantity/this.ganggan|addZero}}
					</view>
				</view>
				<view class="flex" style="font-size: 28rpx;" :style="{color:$util.THEME.TEXT}">
					<view class="flex-1">Charge</view>
					<view class="flex-2 text-right"><text
							v-if="detailedData.project_type_id==2"></text>{{detailedData.current_price*this.quantity/this.ganggan*fee|addZero}}
					</view>
				</view>
			</view>

			<view class="common_btn btn_primary" style="margin: 10px 30px;" @click="placeOrder()">
				Order
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				quantityList: [100, 150, 200, 300, 400, 500], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				show: false,
				quantity: 100,
				detailedData: null,
				ganggan: 1,
				userInfo: null,
				fee: 0.01,
				code: '',
			};
		},

		onLoad(opt) {
			this.code = opt.code || this.code;
		},
		onShow() {
			this.getUserInfo();
			this.product();
			this.getconfig();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleSelected(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},

			// 获取配置
			async getconfig() {
				const result = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				console.log(result);
				console.log(result.data.data);

				if (result.data.code == 0) {
					const temp = result.data.data;
					let map = new Map();
					for (let obj in temp) {
						if (temp.hasOwnProperty(obj)) {
							map.set(temp[obj].key, temp[obj].value);
						}
					}
					this.fee = map.get('TransRate') || this.fee || 0.01;

					// const temp = result.data.data.reduce((map, item) => {
					// 	map.set(item.key, item.value);
					// 	return map;
					// }, new Map());
					// this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async product() {
				const result = await this.$http.get('api/product/info', {
					code: this.code,
				})
				console.log(`result:`, result);
				if (result.data.code == 0) {
					this.detailedData = result.data.data[0]
				}
			},
			//购买
			placeOrder() {
				// if (this.quantity < 100) {
				// 	uni.$u.toast('Minimum value 100');
				// 	return false;
				// }

				const _this = this;
				let money = this.$util.formatNumber(this.detailedData.current_price * this.quantity * 1);
				uni.showModal({
					title: "Do you want to Executed Orders ? ",
					// content: this.detailedData.name + ' ' + this.quantity.toString().replace(
					// 	/\B(?=(\d{3})+(?!\d))/g, ",") + "Weekly payment amount " + money + "one",
					cancelText: "Cancel", // 取消按钮的文字
					confirmText: "Execute", // 确认按钮的文字
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: '#39B54A',
					cancelColor: '#f55850',
					success: (res) => {
						if (res.confirm) {
							console.log('comfirm') //点击确定之后执行的代码
							_this.buy()
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}
				})


			},
			async buy() {
				uni.showLoading({
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(`api/product/purchase`, {
					num: this.quantity || 0,
					gid: this.detailedData.gid,
					price: this.detailedData.current_price,
					ganggan: this.ganggan,
				});
				uni.hideLoading();

				if (result.data.code == 0) {
					uni.$u.toast(result.data.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//实名认证
			async getUserInfo() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				console.log('result:', result);
				this.userInfo = result.data.data;
			},
		},
		filters: {
			addZero: function(data) {
				return data.toFixed(0).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
			}
		},
	}
</script>

<style lang="scss">
	.gp_type {
		position: fixed;
		top: 220rpx;
		background-color: #ed4344;
		color: #fff;
		width: 80rpx;
		padding: 14rpx;
		right: 40rpx;
		text-align: center;
	}

	.purchase {
		width: 90%;
		height: 80rpx;
		// background: url(../../static/anniu.png);
		background-size: 100% 100%;
		border-radius: 20rpx;
		font-weight: 700;
		color: #fff;
		font-size: 40rpx;
		display: -webkit-box;
		display: -ms-flexbox;
		display: flex;
		-webkit-box-align: center;
		-ms-flex-align: center;
		align-items: center;
		-webkit-box-pack: center;
		-ms-flex-pack: center;
		justify-content: center;
		margin: 40rpx 5%;
	}

	.actity {
		background-color: #f7d60d3b;
		color: #3c1f20;
		font-weight: 700;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.noactity {
		background-color: #fff;
		color: #979898;
		border: 1px solid #f1f5f9;
		height: 80rpx;
		line-height: 80rpx;
		text-align: center;
		margin-bottom: 20rpx;
	}

	.f-dis-input {
		padding: 26rpx 24rpx;
		background: #f6f6f6;
		border-radius: 10rpx;
		color: #262626;
		font-size: 32rpx;
	}

	.yue {
		margin: 10px 20px;
		color: #fff;
		font-size: 56rpx;
		font-weight: 700;
	}
</style>