<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Nominee Details" @action="handleBack()"></CustomHeader>
		</view>
		<view class="common_block" style="margin:0;padding:20px;">
			<view>Nominee Name</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<input v-model="info.lastname" type="text" placeholder="Enter Nominee Name"
					:placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>
			<view>Permanant Account No (PAN)</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<input v-model="info.pan" type="password" placeholder=""
					:placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view>Aadhaar No (UID)</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<input v-model="info.idcard" type="text" placeholder=""
					:placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view>Mobile No</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<input v-model="info.mobile" type="text" placeholder="Enter Nominee Mobile Number"
					:placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>
			<!-- <view>Email Id</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<input v-model="info.email" type="text" placeholder="Enter Nominee Email Id"
					:placeholderStyle="$util.setStylePlaceholder()"></input>
			</view> -->
			<view>Date Of Birth</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<u-datetime-picker :show="showBirth" v-model="info.birthtime" mode="date" closeOnClickOverlay
					@close="showBirth = false" @cancel="showBirth = false" @confirm="handleBirth" cancelText="Cancel" :minDate="Number(new Date('1920-01-01T00:00:00Z'))"  :maxDate="Number(new Date())"
					confirmText="Confirm"></u-datetime-picker>
				<view style="width: 100%;color:rgba(102, 102, 102, 1);" @click="showBirth = true">{{birthValue}}</view>
			</view>

			<!-- <view>Relationship with Client</view>
			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<view @click="show = true" style="color:rgba(102, 102, 102, 1);width: 100%;">{{selectedValue}}</view>
				<u-picker :show="show" :columns="columns" closeOnClickOverlay @confirm="handleConfirm"
					@change="handleChange" @close="show = false" @cancel="show = false" cancelText="Cancel"
					confirmText="Confirm"></u-picker>
			</view> -->

			<view class="common_input_wrapper"
				style="margin:10px 0;background-color: rgba(247, 246, 252, 1); border-radius: 6px;width: 90%;">
				<u-radio-group v-model="radiovalue1" placement="column" @change="groupChange">
					<u-radio :customStyle="{marginBottom: '8px'}" v-for="(item, index) in radiolist1" :key="index"
						:label="item.name" :name="item.name" @change="radioChange" :activeColor="$util.THEME.PRIMARY"
						labelSize="11px"
						:labelColor="item.name==radiovalue1?'rgba(51, 51, 51, 1)':'rgba(102, 102, 102, 1)' ">
					</u-radio>
				</u-radio-group>
			</view>

			<view style="font-size: 16px;">Upload Proof<text style="color: red;">*</text></view>

			<view style="width: 80%;padding:20px;">
				<view style="width: 100%;height: 30vh;">
					<u-upload @afterRead="afterRead" @delete="deletePic" name="6" multiple :maxCount="1" width="360px"
						height="240px">
						<image :src="info.src" mode="aspectFit" style="margin-left: 34%; height: 180px;width: 180px;"></image>
					</u-upload>
				</view>
			</view>

			<!-- <view style="margin-bottom: 20px;display: flex;align-items: center;">
				<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple
					:maxCount="1" width="" height="200" style="z-index: 10;">
					<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #95918a;">Upload
						Color and Clear image of PAN of Nomine</view>
					<image :src="src" mode="aspectFit" style="margin:0 auto;height: 180px;width: 180px;">
					</image>
				</u-upload>
			</view> -->


			<view class="common_btn btn_primary" style="width:50%;margin: auto;color: #FFF;"
				@click="handleAccount">{{$lang.CONFIRM}}</view>
		</view>
	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				fileList6: [],
				info: {},
				birthValue: 'Enter Date Of Birth',
				showBirth: false,
				selectedValue: 'Click And Selected',
				show: false,
				columns: [
					['Child', 'Parents', 'Brothers And Sisters', 'Grandparents', 'Maternal Grandparents', 
					'Wife','Husband']
				],
				radiolist1: [{
						name: 'Same As Primary Applicant Correspondence',
						disabled: false
					},
					{
						name: 'Add New Address',
						disabled: false
					}
				],
				// u-radio-group的v-model绑定的值如果设置为某个radio的name，就会被默认选中
				radiovalue1: 'Add New Address',
			};
		},

		onShow() {
			this.getJiCheng();
		},

		methods: {
			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,

					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
				this.info.src = this.fileList6[0].thumb
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},

			result(time, mode) {
				const timeFormat = uni.$u.timeFormat,
					toast = uni.$u.toast
				switch (mode) {
					case 'datetime':
						return toast(timeFormat(time, 'yyyy-mm-dd hh:MM'))
					case 'date':
						return toast(timeFormat(time, 'yyyy-mm-dd'))
					case 'year-month':
						return toast(timeFormat(time, 'yyyy-mm'))
					case 'time':
						return toast(time)
					default:
						return ''
				}
			},
			// 生日
			handleBirth(e) {
				console.log('e', e);
				this.showBirth = false;
				// 格式化选中的年月日
				this.info.birthtime = uni.$u.timeFormat(e.value, 'yyyy-mm-dd');
				this.birthValue = this.info.birthtime;
			},
			// 回调参数为包含columnIndex、value、values
			handleConfirm(e) {
				console.log('confirm', e);
				this.show = false
				this.selectedValue = e.value[0];
			},
			handleChange(e) {
				console.log('confirm', e)
				this.selectedValue = e.value[0];
			},
			groupChange(n) {
				console.log('groupChange', n);
			},
			radioChange(n) {
				console.log('radioChange', n);
			},
			handleBack() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},

			// 检查表单
			checkForm() {
				if (this.info.lastname == '') {
					uni.$u.toast('Enter Nominee Name');
					return false;
				}
				if (this.info.pan == '') {
					uni.$u.toast('Permanant Account No (PAN)');
					return false;
				}
				if (this.info.idcard == '') {
					uni.$u.toast('Aadhaar No (UID)');
					return false;
				}
				if (this.info.mobile == '') {
					uni.$u.toast('Enter Mobille No');
					return false;
				}
				if (this.info.email == '') {
					uni.$u.toast('Enter Emall Id');
					return false;
				}
				return true;
			},

			// 提交表单
			handleAccount() {
				if (this.checkForm()) {
					this.AccountRelationship();
				}
			},

			// 获取遗传继承的数据
			async getJiCheng() {
				const result = await this.$http.get(this.$http.API_URL.USER_JICHENG_GET);
				if (result.data.code == 0) {

					if (!result.data.data) {
						console.log(result);
						this.info = {
							lastname: '',
							pan: '',
							idcard: '',
							mobile: '',
							email: '',
							guanxi: 'Child',
							birthtime: this.birthValue,
							src: '/static/upload.png', // 图片地址								
						}
					} else {
						this.info = result.data.data;
					}
					this.selectedValue = this.info.guanxi;
					this.birthValue = this.info.birthtime;
				}
			},

			// 遗传继承
			async AccountRelationship() {
				const tempBirth = this.birthValue.includes('Select') ? '' : this.birthValue;
				const tempRela = this.selectedValue.includes('Click') ? '' : this.selectedValue;
				const result = await this.$http.post(this.$http.API_URL.USER_JICHENG_SAVE, {
					id: this.info.id,
					uid: Number(this.info.uid),
					lastname: this.info.lastname,
					pan: this.info.pan,
					mobile: this.info.mobile,
					email: this.info.email,
					birthtime: tempBirth,
					guanxi: tempRela,
					idcard: this.info.idcard,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>

<style>
</style>