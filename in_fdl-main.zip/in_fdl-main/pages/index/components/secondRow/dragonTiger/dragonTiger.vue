<template>
	<view>
		<view class="college-bg">
			<view class="college-text">용과 호랑이 목록</view>
			<view class=""></view>
		</view>
		<view class="ulto">
			<view class="">이름</view>
			<view class="">상장일</view>
			<view class="">해석</view>
		</view>
		<view class="lis" v-for="(item,index) in dragon" :key="index">
			<view class="">
				<view class="name" style="margin-bottom: 6rpx;">{{item.secu_abbr}}</view>
				<view class="area" v-if="item.locate=='깊은'">
					<view class="deep">{{item.locate}}</view>
					<view class="deep-number">{{item.secu_code}}</view>
				</view>
				<view class="area" v-if="item.locate=='북쪽'">
					<view class="north">{{item.locate}}</view>
					<view class="north-number">{{item.secu_code}}</view>
				</view>
				<view class="area" v-if="item.locate=='상하이'">
					<view class="shanghai">{{item.locate}}</view>
					<view class="shanghai-number">{{item.secu_code}}</view>
				</view>
			</view>
			<view class="trading_day">
				{{item.trading_day}}
			</view>
			<view class="detailed-information" @click="detail(item)">세부</view>
		</view>


		<!-- 弹窗 -->
		<u-popup class="popup" :show="show" :round="20" mode="center" @close="close" @open="open">
			<view class="" v-for="(item,index) in detailed" :key="index">
				<view class="popupContent">
					<view class="content">
						<view class="amount">총액</view>
						<view class="money">{{item.business_balance }}</view>
					</view>
					<view class="content">
						<view class="amount">거래 수</view>
						<view class="money">{{item.business_amount}}</view>
					</view>
					<view class="content">
						<view class="amount">총액 대비 구매 비율</view>
						<view class="money">{{item.buy_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">매출액 대비 총액 비율 </view>
						<view class="money">{{item.sale_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">구매 금액</view>
						<view class="money">{{item.buy_balance}}</view>
					</view>
					<view class="content">
						<view class="amount">판매금액 </view>
						<view class="money">{{item.sale_balance }}</view>
					</view>
					<view class="content">
						<view class="amount">순매수금액</view>
						<view class="money">{{item.net_rate}}</view>
					</view>
					<view class="content">
						<view class="amount">판매량</view>
						<view class="money">{{item.sale_balance}}</view>
					</view>
				</view>
				<view class="account">목록에 포함된 이유:{{item.abnormal_type}}</view>
			</view>

		</u-popup>


	</view>
</template>

<script>
	export default {
		data() {
			return {
				show: false,
				dragon: '',
				detailed: ''
			};
		},
		methods: {
			detail(item) {
				this.show = true
				this.popNotification(item)
			},
			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			},

			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: this.$util.PAGE_URL.HOME
				});
			},
			// 列表 
			async tigerList() {
				let list = await this.$http.get('api/stock-api/BaseDragonTiger', {})
				this.dragon = list.data.data
			},
			// 弹窗详情 
			async popNotification(item) {
				let list = await this.$http.get('api/stock-api/BaseDragonTigerInfo', {
					secu_code: item.secu_code
				})
				this.detailed = list.data.data
			},
		},
		mounted() {
			this.tigerList()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 20rpx;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #01B4D5);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}
	}

	.ulto {
		border-bottom: 2rpx solid #e0e0e0;
		display: flex;
		justify-content: space-between;
		margin-top: -20rpx;
		background: #fff;
		border-radius: 30rpx 30rpx 0 0;
		padding: 20rpx 30rpx;
		color: #666;
	}

	.lis {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx;
		font-size: 30rpx;
		border-bottom: 2rpx solid #e0e0e0;

		.name {
			font-size: 30rpx;
			color: #1a1a1a;
		}

		.secu_code {
			color: #666;
			font-size: 26rpx;
		}

		.trading_day {
			font-size: 28rpx;
			color: #1a1a1a;
		}

		.detailed-information {
			background-image: linear-gradient(to right, #1a73e8, #01B4D5);
			border-radius: 30rpx;
			text-align: center;
			color: #fff;
			padding: 6rpx 36rpx;
			font-size: 28rpx;
		}
	}

	//弹窗
	/deep/.u-popup__content {
		width: 90%;
	}

	.popupContent {
		padding: 10rpx 30rpx;
		text-align: center;
		font-size: 28rpx;
		text-align: left;
		display: flex;
		flex-wrap: wrap;
		justify-content: space-between;
		align-items: center;

		.content {
			width: 50%;
		}

	}


	.amount {
		margin: 30rpx 0;
	}

	.money {
		margin: 30rpx 0;
		color: #dd362b;
		font-weight: 600;
		font-family: "\82F9\65B9";
	}

	.account {
		text-align: center;
		color: #333;
		font-size: 24rpx;
		margin: 0 0 30rpx;
	}
</style>
