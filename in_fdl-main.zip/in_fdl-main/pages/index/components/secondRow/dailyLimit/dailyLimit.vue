<template>
	<view>
		<!-- 头部-->
		<view class="college-bg">
			<view class="account">
				
				<view class="college-text">每日涨停</view>
				
			</view>
		</view>

		<view class="boxkl" v-for="(item,index) in everyday" :key="index">
			<view class="ulkm">
				<view class="display">
					<view class="display">
						<view class="" style="margin-right: 40rpx;">股票名称:</view> <text>{{item.名称}}</text>
					</view>
					<view class="display">
						<view class="" style="margin-right: 40rpx;">股票代码:</view> <text>{{item.代码}}</text>
					</view>
				</view>

				<view class="turnover">
					<view class="ulkms">换手率(%):</view> <text>{{item.换手率}}</text>
				</view>
				<view class="turnover">
					<view class="ulkms"> 涨跌幅: </view><text>{{item.涨跌幅}}</text>
				</view>
				<view class="turnover">
					<view class="ulkms"> 最新价:</view> <text>{{item.最新价}}</text>
				</view>
				<view class="turnover">
					<view class="ulkms">成交额: </view> <text>{{item.成交额}}</text>
				</view>
				<view class="turnover">
					<view class="ulkms"> 流通市值:</view> <text>{{item.流通市值}}</text>
				</view>
				<view class="turnover">
					<view class="ulkms"> 总市值:</view> <text>{{item.总市值}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				everyday: ''
			};
		},
		methods: {
			changeTab(Inv) {
				that.navIdx = Inv;
			},
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: this.$util.PAGE_URL.HOME
				});
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SEARCH
				});
			},
			//刷新功能
			refresh() {
				uni.redirectTo({
					url: '/pages/index/components/secondRow/dailyLimit/dailyLimit'
				});
			},
			//沪市
			async priceLimit() {
				let list = await this.$http.get('api/stock-api/PoolZT', {})
				this.everyday = list.data.data
			},

		},
		mounted() {
			this.priceLimit()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 20rpx;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #01B4D5);

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.renovate {
			width: 40rpx;
		}

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

		.suo {
			background: hsla(0, 0%, 100%, .1);
			border-radius: 40rpx;
			padding: 10rpx 30rpx;
			margin: 40rpx 0 0;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}
		}
	}

	.boxkl {
		margin-top: -20rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		display: flex;
		padding: 0rpx 0 20rpx;

		.ulkm {
			background: #eff4ff;
			margin: 20rpx 20rpx 0;
			width: 100%;
			border-radius: 20rpx;
			padding: 30rpx;
			font-size: 28rpx;

			// color: #fff;
			.turnover {
				display: flex;
				align-items: center;

				.ulkms {
					width: 24%;
				}

			}

			view {
				margin: 10rpx 0;
			}

			text {
				color: #FE0101;
				margin-left: 20rpx;
			}
		}
	}
</style>