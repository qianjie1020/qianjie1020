<!-- 申购 记录 -->
<template>
	<view style="background-color: #FFF;">
		<view class="header_wrapper_10">
			<CustomHeader title="Full details" @action="handleBack()"></CustomHeader>
		</view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="border-bottom: 1px solid #ccc;margin: 4px 20px;background-color: #FFF;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
					<view>{{item.goods.name}}</view>
					<!-- 		<text v-if="item.status==0">未中签</text>
								<text v-if="item.status==1">申购中</text>
								<text v-if="item.status==2">申购中签</text>
								<text v-if="item.status==3">已구독하다金额</text>
								<text v-if="item.status==4">中签弃奖</text>
								<text v-if="item.status==5">已上市</text> -->
					<view style="font-size: 14px;color:#ea3544;">{{item.message}}</view>
				</view>
				<view style="display: flex;align-items: center;padding-bottom: 6px;">
					<view style="flex:15%;" :style="{color:$util.THEME.TIP}">Subscription amount</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:35%;text-align: right;padding-right: 20px;">
						{{$util.formatNumber(item.price)}}
					</view>
					
					<view style="flex:15%;" :style="{color:$util.THEME.TIP}" v-if="item.success">Subscription quantity</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:35%;text-align: right;"  v-if="item.success">
						{{$util.formatNumber(item.success)}}
					</view>
				</view>
				
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" v-if="item.success">
					<view :style="{color:$util.THEME.TIP}">Total subscription amount</view>
					<view style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{item.success*1*item.price}}</view>
				</view>
				
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" v-if="item.success">
					<view :style="{color:$util.THEME.TIP}">Subscribed funds</view>
					<view style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{item.freeze*1}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Opening Date</view>
					<view>{{item.shengou.shengou_date}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Closing Date</view>
					<view>{{item.shengou.rj_date}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Allotment Date</view>
					<view>{{item.shengou.gb_date}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Listing Date</view>
					<view>{{item.shengou.online_date}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>Purchase time</view>
					<view>{{item.created_at}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;"
					:style="{color:$util.THEME.TIP}">
					<view>transaction code</view>
					<view>{{item.order_sn}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		onLoad(item) {},
		onLoad(option) {
			this.shengou();
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			// 新股申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
	}
</script>