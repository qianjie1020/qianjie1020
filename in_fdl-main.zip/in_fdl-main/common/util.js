import LANGUAGE from '@/common/lang/kr.js';
// import LANGUAGE from '@/common/lang/zh.js';
const THEME = {
	BG: '#121212',
	FG: '#232323',
	PRIMARY: '#109E58',
	SECONDARY: '#FF8C00',
	RISE: '#16a139',
	FALL: '#fd4331',
	LABEL: '#F7F7F7',
	TEXT: '#333333', // D3D3D3
	TIP: '#999999',
	TEXT_DARK: '#010259',

}

// #014b8d

// 折线图 StockLineChart 
// 饼状图 StockPieChart

// 销售额 StockSales
// 投资者交易趋势 TradeTrend
// 卖空量 ShortSellVol

// 非page.json使用的页面url，减少硬编码
const PAGE_URL = {
	HOME: `/pages/home`, // 主页
	SERVICE: `/pages/service`, // 客服
	ABOUT: `/pages/about`, // 关于、隐私协议、用户协议、版本更新
	SEARCH: `/pages/search`, // 搜索 
	NOTIFICATION: `/pages/notification`, // 通知 

	ACCOUNT_SIGNIN: `/pages/account/sigin`, // 登入、注册
	ACCOUNT_CENTER: `/pages/account/center`, // 个人中心
	ACCOUNT_WITHDRAW: `/pages/account/withdraw`, // 提款
	ACCOUNT_DEPOSIT: `/pages/account/deposit`, // 存款
	ACCOUNT_PWD: `/pages/account/pwd`, // 登入密码
	ACCOUNT_PWD_PAY: `/pages/account/pwdPay`, // 支付密码
	ACCOUNT_BANK_CARD: `/pages/account/cardList`, // 银行卡 绑定换绑
	ACCOUNT_TRADE: `/pages/account/trade`, // 个人交易
	ACCOUNT_AUTH: `/pages/account/auth`, // 认证
	ACCOUNT_TRADE_LOG: `/pages/account/tradeLog`, // 账户交易记录
	ACCOUNT_INHERIT: `/pages/account/inherit`, // 账户遗传继承
	ACCOUNT_CREDIT_SCORE: `/pages/account/creditScore`, // 信用积分
	ACCOUNT_LOAN: `/pages/account/loan`, // 贷款

	STOCK_ALL: `/pages/stock/all`, // 全部股票
	STOCK_BOOKMARK: `/pages/stock/bookmark`, // 关注的股票
	STOCK_OVERVIEW: `/pages/stock/overview`, // 单股概况
	STOCK_NEWS: `/pages/stock/news`, // 单股新闻
	STOCK_BUY: `/pages/stock/buy`, // 单股买入

	MARKET_NEWS: `/pages/market/news`, // 市场新闻
	MARKET_INDICATOR: `/pages/market/indicator`, // 市场指标
	MARKET_HOT: `/pages/market/hot`, // 市场热门
	MARKET_OVERVIEW: `/pages/market/overview`, // 市场概况

	TRADE_SHORT: `/pages/trade/short`, // 短打交易
	TRADE_SHORT_LOG: `/pages/trade/shortLog`, // 短打交易 记录
	TRADE_LARGE: `/pages/trade/large`, // 大宗交易
	TRADE_LARGE_LOG: `/pages/trade/largeLog`, // 大宗交易 记录
	TRADE_IPO: `/pages/trade/ipo`, // ipo交易
	TRADE_IPO_LOG: `/pages/trade/ipoLog`, // ipo交易 记录
	TRADE_DISCOUNT: `/pages/trade/discount`, // 折扣交易
	TRADE_DISCOUNT_LOG: `/pages/trade/discountLog`, // 折扣交易 记录
	// TRADE_DISCOUNT:`/pages/trade/sale`, // 
	// TRADE_DISCOUNT_LOG:`/pages/trade/saleLog`, // 
};

// 作为股票排序：最热、最新、涨率、跌率、关注。右侧有余位，放置跳转箭头。
const SORT_MODE = [LANGUAGE.STOCK_HOT, LANGUAGE.STOCK_LAST, LANGUAGE.STOCK_RISE, LANGUAGE.STOCK_FALL, LANGUAGE
	.STOCK_BOOK
];

// 主页功能按钮组配置
const BTNS_CONFIG_HOME = [
	// 	{
	// 	name: 'Daily Price',
	// 	icon: 'top1',
	// 	url: PAGE_URL.TRADE_SHORT,
	// }, 
	// {
	// 	name: 'AI Stock Basket',
	// 	icon: 'top1',
	// 	url: '/pages/index/components/fund/fund',
	// }, 
	{
		name: 'BlockTrading',
		icon: 'top2',
		url: PAGE_URL.TRADE_LARGE,
	},
	{
		name: 'IPO',
		icon: 'top4',
		url: PAGE_URL.TRADE_IPO,
	},

	{
		name: 'Subscription',
		icon: 'top1',
		url: `/pages/trade/subscription`,
	},

	// {
	// 	name: 'AllStocks',
	// 	icon: 'top3',
	// 	url: PAGE_URL.STOCK_ALL,
	// }, 
	{
		name: 'Deposit',
		icon: 'top5',
		url: PAGE_URL.ACCOUNT_DEPOSIT,
	}, {
		name: 'Withdrawal',
		icon: 'top6',
		url: PAGE_URL.ACCOUNT_WITHDRAW,
	}, {
		name: 'Trade Log',
		icon: 'top7',
		url: PAGE_URL.ACCOUNT_TRADE_LOG,
	},
	// {
	// 	name: 'Identity',
	// 	icon: 'top3',
	// 	url: PAGE_URL.ACCOUNT_INHERIT,
	// },
	{
		name: 'Credit Score',
		icon: 'top3',
		url: PAGE_URL.ACCOUNT_CREDIT_SCORE,
	},
	{
		name: 'Service',
		icon: 'top8',
		url: '/pages/service',
	},
	//  {
	// 	name: 'Charge',
	// 	icon: 'top6',
	// 	url: PAGE_URL.ACCOUNT_DEPOSIT,
	// }, {
	// 	name: 'Identity',
	// 	icon: 'top7',
	// 	url: PAGE_URL.ACCOUNT_AUTH,
	// },
];

const BTNS_TRADE_LOG = [LANGUAGE.LOG_TRADE, LANGUAGE.LOG_DEPOSIT, LANGUAGE.LOG_WITHDRAW]

// 提款说明
const TIP_WITHDRAW_CONDITION = [
	LANGUAGE.TIP_WITHDRAW_1,
	LANGUAGE.TIP_WITHDRAW_2,
	LANGUAGE.TIP_WITHDRAW_3,
	LANGUAGE.TIP_WITHDRAW_4,
	LANGUAGE.TIP_WITHDRAW_5,
]

const calcStyleTabActive = (active = true) => {
	return {
		color: active ? THEME.TEXT_DARK : THEME.TIP,
		// borderBottom: active ? `3px solid ${THEME.PRIMARY}` : '',
		// backgroundColor: active ? '#03327857' : '',
	}
}

const calcStyleTabSecond = (active = true) => {
	return {
		color: active ? THEME.TEXT_DARK : THEME.TIP,
		backgroundColor: active ? THEME.PRIMARY : '#c2c2c233',
	}
}

const calcStyleTabThird = (active = true) => {
	return {
		color: active ? THEME.TEXT_DARK : THEME.TEXT,
		borderBottom: active ? `3px solid ${THEME.PRIMARY}` : '',
	}
}

const calcStyleRiseFall = (val = true, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? THEME.RISE : THEME.FALL,
		backgroundColor: !isbg ? '' : val ? THEME.RISE : THEME.FALL,
	}
}

const calcImageSize = (val) => {
	// widthFix
	return {
		width: `${val}px`,
		height: `${val}px`,
	};
};

const calcPageHeight = () => {
	const systemInfo = uni.getSystemInfoSync();
	const tabBarHeight = systemInfo.screenHeight - systemInfo.windowHeight;
	return systemInfo.screenHeight - tabBarHeight;
};

const calcBodyHeight = () => {
	return parseInt(calcPageHeight() - 70);
};

const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

const formatDate = (timeString) => {
	// console.log('fmt:',fmt);
	const date = new Date(timeString);
	const year = date.getUTCFullYear();
	const month = String(date.getUTCMonth() + 1).padStart(2, '0');
	const day = String(date.getUTCDate()).padStart(2, '0');
	const h = String(date.getUTCHours()).padStart(2, '0');
	const m = String(date.getUTCMinutes()).padStart(2, '0');
	const s = String(date.getUTCSeconds()).padStart(2, '0');

	return `${year}.${month}.${day} ${h}:${m}:${s}`;
}



const mqBtnsConfig = () => {
	return [{
		name: LANGUAGE.FULL_INFO,
		url: '',
		icon: 'maket1'
	}, {
		name: LANGUAGE.HOT_GOODS,
		url: '',
		icon: 'maket2'
	}, {
		name: LANGUAGE.MARKET_INDICATORS,
		url: '',
		icon: 'maket3'
	}, {
		name: LANGUAGE.MARKET_ISSUES,
		url: '',
		icon: 'maket4'
	}];
};

// 市场
const MARKET_TAB = [LANGUAGE.FULL_INFO];

// 市场概况：国内、国外、虚拟
const tabsMaketOverviewType = ["Domestic", "Overseas", "Virtual Currency"];
// 市场概况：热门股票排序
const tabsMaketOverviewHot = ["rising rate", "falling rate", "new price", "volume", 'transaction amount'];
// 热门股票：
const tabsMarketHot = ['Rise rate', 'Fall rate', 'Report price', 'Trading volume top/bottom',
	'Trading amount top/bottom', 'Foreign net purchase', 'Institution net purchase', 'New listing',
	'Short selling proportion '
];
// 热门股票过滤
const tabsMarketHotFilter = ['same day', '1 week', '1 month', '3 months', '6 months'];
// 市场指标：
const tabsMarketIndex = ['index', 'exchange rate', 'raw materials', 'virtual currency'];
// 股票 按照[分、日、周、月]
const DATE_MODE = [LANGUAGE.MINUTE, LANGUAGE.DAY, LANGUAGE.WEEK, LANGUAGE.MONTH]

// 市场新闻： 新闻、市场、经济、行业、债券、衍生品、公司、投资
const tabsMarketNew = [LANGUAGE.NEWS, LANGUAGE.MARKETS, LANGUAGE.ECONOMY, LANGUAGE.INDUSTRIES,
	LANGUAGE.BONDS, LANGUAGE.DERIVATICES, LANGUAGE.COMPANIES, LANGUAGE.INVESTMENTS
];

// 股票详情 一级TABS
const STOCK_OVERVIEW_TABS = ['Latest News', 'Summary', 'Issue'];
const BTNS_IPO = ['Subscription application', 'Subscription record', 'Winning record'];

const TRADE_LOG_STATUS = [{
		text: 'Under review',
		icon: '/static/failed.png',
		color: '#d50000'
	},
	{
		text: 'Successful',
		icon: '/static/success.png',
		color: '#5AC725'
	},
	{
		text: 'Withdrawal failed. Contact customer service.',
		icon: '/static/failed.png',
		color: '#F9AE3D'
	},
	{
		text: 'canceled',
		icon: '/static/failed.png',
		color: '#F9AE3D'
	}
];

const AUTH_LIST = [{
	name: LANGUAGE.VERIFIED,
	url: PAGE_URL.ACCOUNT_AUTH,
	icon: 'authentication',
	code: -1,
	mode: 'link',
}, {
	name: LANGUAGE.AUDIT,
	url: PAGE_URL.ACCOUNT_AUTH,
	icon: 'authentication',
	code: 0,
	mode: 'link',
}, {
	name: LANGUAGE.AUDIT_FAILED,
	url: PAGE_URL.ACCOUNT_AUTH,
	icon: 'authentication',
	code: 2,
	mode: 'link',
}];

const MODE_DIALOG = [{
		name: LANGUAGE.CHANGE_PWD,
		url: PAGE_URL.ACCOUNT_PWD,
		icon: 'signin_pwd',
		mode: 'link',
	},
	// {
	// 	name: LANGUAGE.CHANGE_PAY_PWD,
	// 	url: PAGE_URL.ACCOUNT_PWD_PAY,
	// 	icon: 'pay_pwd',
	// 	mode: 'link',
	// },
	{
		name: LANGUAGE.CARD_MANAGEMENT,
		url: PAGE_URL.ACCOUNT_BANK_CARD,
		icon: 'bank_card',
		mode: 'link',
	}
];

// 个人中心，功能列表
const funcListConfig = (code = '') => {
	// const temp = AUTH_LIST.filter(item => item.code == code);
	const data = [
		// {
		// 	name: 'Identity Verification',
		// 	url: PAGE_URL.ACCOUNT_INHERIT,
		// 	icon: 'inherit',
		// 	mode: 'link',
		// },
		{
			name: 'Credit Score',
			url: PAGE_URL.ACCOUNT_CREDIT_SCORE,
			icon: 'daikuan',
			mode: 'link',
		},
		{
			name: LANGUAGE.TRADE_LOG,
			url: PAGE_URL.ACCOUNT_TRADE_LOG,
			icon: 'capital_deatil',
			mode: 'link',
		}, {
			name: LANGUAGE.ABOUT,
			url: PAGE_URL.ABOUT,
			icon: 'about',
			mode: 'link',
		}, {
			name: LANGUAGE.SIGN_UP,
			url: '',
			icon: 'sign_out',
			mode: 'sign_out',
		}
	];
	return [{
		name: `Real Name Verification`,
		url: PAGE_URL.ACCOUNT_AUTH,
		icon: 'authentication',
		// code: 2,
		mode: 'link',
	}, ...MODE_DIALOG, ...data];
}

// const TRADE_LOG_STATUS =[
// 	{label:'검토를 보류하다',color:'gray'},
// 	{label:'통과하다',color:'red'},
// 	{label:'거부하다',color:'green'}];
// 1是通过   0是待审核   2是拒绝     通过红色   拒绝绿色   待审核灰色
const calcTradeLogStatusLabel = (val) => {
	return TRADE_LOG_STATUS[val].text;
}
const calcTradeLogStatusColor = (val) => {
	return TRADE_LOG_STATUS[val].color;
}

// 贷款审核状态值与样式
const STATUS_LOAN = [{
	text: 'Pending',
	color: '#007aff',
}, {
	text: 'Success',
	color: '#4cd964',
}, {
	text: 'Repaid',
	color: '#4cd964'
}, {
	text: 'Reject',
	color: '#dd524d',
}]
const setStatusTextLoan = (val) => {
	console.log(val);
	return STATUS_LOAN[val].text;
}
const setStatusColorLoan = (val) => {
	return STATUS_LOAN[val].color;
}

const setStylePlaceholder = () => {
	return `font-size:12px`;
}



const UTIL = {
	// 根据当前平台，执行回退方式
	goBack: () => {
		/*#ifdef APP-PLUS*/
		uni.navigateBack({
			delta: 1
		});
		/*#endif*/

		/*#ifdef H5*/
		history.back();
		/*#endif*/
	},

	setStylePlaceholder,
	THEME,
	PAGE_URL,
	BTNS_CONFIG_HOME,
	SORT_MODE,
	MODE_DIALOG,
	BTNS_TRADE_LOG,
	TIP_WITHDRAW_CONDITION,
	calcStyleTabActive,
	calcStyleTabSecond,
	calcStyleTabThird,
	calcStyleRiseFall,
	calcImageSize,
	formatNumber,
	formatDate,
	calcPageHeight,
	calcBodyHeight,
	mqBtnsConfig,
	tabsMaketOverviewType,
	tabsMaketOverviewHot,
	tabsMarketHot,
	tabsMarketHotFilter,
	tabsMarketIndex,
	tabsMarketNew,
	funcListConfig,
	TRADE_LOG_STATUS,
	MARKET_TAB,
	STOCK_OVERVIEW_TABS,
	BTNS_IPO,
	calcTradeLogStatusLabel,
	calcTradeLogStatusColor,
	setStatusTextLoan,
	setStatusColorLoan,

	// 统一处理杠杆，后端数据返回不一致。
	leverList: (val) => {
		val = val || [];
		// 如果没有数据。就返回默认杠杆 1
		if (!val || val.length <= 0) return [1];

		// 数组对象类型 
		// ganggan: [{name: "", index: ""}] 
		// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
		if (val.length > 0 && typeof(val[0]) === 'object') {
			// val[0].index && val[0].index * 1 > 0
			const temp = val.map(item => item.index * 1);
			console.log('lever array object:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		}

		// 字符串类型 ganggan: "2,3,4,5,6,7,8,9,10" 
		if (typeof(val) === 'string') {
			const temp = val.split(',').map(item => item * 1);
			console.log('lever string:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		}
		// if (typeof(val) == 'array') {
		// return val.filter(item => item * 1);
		// }
	},
}

export default UTIL;