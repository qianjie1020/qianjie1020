<template>
	<view style="margin:10px;">
		<view class="info flex flex-b common_block" style="margin:0;background-color:#FFF;padding:0 10px;">
			<view class="flex-1">
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>52-WK High</view>
					<view class="t">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_52_high:productDetails.data.response2.data.companyDetails.bse_52_high}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>52-WK High Date</view>
					<view class="t num-font">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_52_high_date:productDetails.data.response2.data.companyDetails.bse_52_high_date}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>52-WK Low</view>
					<view class="t">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_52_low:productDetails.data.response2.data.companyDetails.nse_52_low}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>52-WK Low Date</view>
					<view class="red num-font">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_52_low_date:productDetails.data.response2.data.companyDetails.nse_52_low_date}}
					</view>
				</view>
			</view>
			<view class="flex-1">
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>All Time High</view>
					<view class="t num-font">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_all_high:productDetails.data.response2.data.companyDetails.nse_all_high}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>All Time High Date</view>
					<view class="t">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_all_high_date:productDetails.data.response2.data.companyDetails.nse_all_high_date}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>All Time Low</view>
					<view class="t">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_all_low:productDetails.data.response2.data.companyDetails.nse_all_low}}
					</view>
				</view>
				<view style="background-color:#F8F7FC;margin:10px 4px;text-align: center;">
					<view>All Time Low Date</view>
					<view class="blue num-font">
						{{productDetails.project_type_id==1?productDetails.data.response2.data.companyDetails.nse_all_low_date:productDetails.data.response2.data.companyDetails.nse_all_low_date}}
					</view>
				</view>
			</view>
		</view>

		<view class="about" style="background-color:#FFFFFF;border-radius: 10px;">
			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;">
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">Company Overview</view>
				<view style="flex:10%;text-align: right;" @click="txt_show=false" :style="{color:$util.THEME.TIP}">More
				</view>
			</view>
			<view class="txt" :class="txt_show?'show':''" style="white-space:pre-wrap;">
				{{productDetails.data.response2.data.companyDetails.memo}}
				<view class="t1" @click="txt_show=true"> briefly </view>
			</view>
		</view>


		<view class="flex flex-b tb" style="margin-top:10px;">
			<view class="flex flex-b flex-1 tabs">
				<view :class="info_two_ac==0?'active':''" @click="qh_info_two(0)">quarterly sales</view>
				<view :class="info_two_ac==1?'active':''" @click="qh_info_two(1)">annual sales</view>
			</view>
			<view class="flex-1 t-r t" v-if="info_two_ac==0&&top3">standard {{top3[0].report_year_month}}</view>
			<view class="flex-1 t-r t" v-if="info_two_ac==1&&top33">standard {{top33[0].report_year_month}}</view>
		</view>
		<view class="nums" v-if="info_two_ac==0">
			<view class="t">Peer Group Comparison</view>
			<view class="flex flex-b">
				<view class="item" v-for="(item,index) in productDetails.data.response2.data.companyPeerGroup"
					v-if="index<3">
					<view class="t1">{{item.company_name}}</view>
					<view class="t2" :class="item.per_chg>0?'':'die'">{{item.current_price}}</view>
					<view class="t3" :class="item.per_chg>0?'':'die'">{{item.per_chg}}%</view>
				</view>
			</view>
		</view>

		<view class="nums" v-if="info_two_ac==1">
			<view class="t">Peer Group Comparison</view>
			<view class="flex flex-b">
				<view class="item" v-for="(item,index) in productDetails.data.response2.data.companyPeerGroup"
					v-if="index>=3&&index<6">
					<view class="t1">{{item.company_name}}</view>
					<view class="t2" :class="item.per_chg>0?'':'die'">{{item.current_price}}</view>
					<view class="t3" :class="item.per_chg>0?'':'die'">{{item.per_chg}}%</view>
				</view>
			</view>
		</view>

		<!-- <view class="chart-box">
			<view class="flex flex-b tb">
				<view class="flex flex-b flex-1 tabs">
					<view :class="zhexian_index==0?'active':''" @click="zhexian_act(0)">take</view>
					<view :class="zhexian_index==1?'active':''" @click="zhexian_act(1)">operating profit</view>
					<view :class="zhexian_index==2?'active':''" @click="zhexian_act(2)">net profit</view>
				</view>
			</view>
			<view id="main" class="chart">
				<canvas canvas-id="zhexian" id="zhexian" class="charts" />
			</view>
		</view> -->

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 4px 10px;">
			<view style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">Trading trends by investor</view>
		</view>

		<view class="common_block" style="background-color: #FFF;margin:0px;padding:0 10px;">
			<view>
				<view>
					<view class="flex flex-b top">
						<view class="t">Summary</view>
					</view>
					<view class="border pdd">
						<view class="t2">Srivasavi Adhesive Tapes Ltd- Key Fundamentals</view>
						<view class="flex flex-b last">
							<view>Market Cap (₹ Cr)</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].market_capital}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>EPS - TTM (₹) [S]</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].eps}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>P/E Ratio (X) [S]</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].p_e_ratio}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>Face Value (₹)</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].face_value}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>Latest Dividend (%)</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].latest_dividend}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>Latest Dividend Date</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].latest_dividend}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>Dividend Yield (%)</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].dividend_yield}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>Book Value Share (₹) [S]</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].book_value_share}}</span>
							</view>
						</view>
						<view class="flex flex-b last">
							<view>P/B Ratio (₹) [S]</view>
							<view>
								<span>{{productDetails.data.response2.data.companyOverview['key-fundamentals'][0].p_b_ratio}}</span>
							</view>
						</view>
						<!-- <view class="flex flex-b last">
								<view>[*C] Consolidated [*S] Standalone</view>
								<view><span>22</span></view>
							</view> -->

					</view>

				</view>
			</view>

		</view>
		
		
		<!-- <view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 4px;">
			<view style="pfont-size: 16px;" :style="{color:$util.THEME.PRIMARY}">Trading trends</view>
		</view>
		<view class="list common_block" style="background-color: #FFF;margin:0px;padding:0 10px;border:none;">
			<view class="flex flex-b">
				<canvas canvas-id="huan1" id="huan1" class="charts" />
			</view>
		</view>

		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 4px;">
			<view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">Short selling volume
			</view>
		</view>
		<view class="top common_block" style="margin:0;padding: 10px;">
			<view class="flex flex-b">
				<view class="item" style="background: #f8f7fc;">
					<view>
						<view class="t1">Short selling volume</view>
						<view class="t2">Compared to total trading volume</view>
					</view>
					<view class="flex mtb">
						<view class="t3 num-font">{{top7[0].short_volume}}main</view>
						<view class="t4">{{top7[0].short_volume_weight}}%</view>
					</view>
					<view>
						<view class="t2">standard</view>
						<view class="t4">{{top7[0].dt}}</view>
					</view>
				</view>
				<view class="item" style="background: #f8f7fc;">
					<view>
						<view class="t1">Short sale balance</view>
						<view class="t2">Relative to market capitalization</view>
					</view>
					<view class="flex mtb">
						<view class="t3 num-font">{{top7[1].short_volume}}main</view>
						<view class="t4">{{top7[1].short_volume_weight}}%</view>
					</view>
					<view>
						<view class="t2">standard</view>
						<view class="t4">{{top7[1].dt}}</view>
					</view>
				</view>
			</view>
		</view>

		<view class="common_block" style="margin: 0;background-color: #FFF;">
			<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;margin: 10px;">
				<view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">업종 내 비교</view>
				<view style="flex:10%;text-align: right;" @click="txt_show=false" :style="{color:$util.THEME.TIP}">자동차부품
					{{top8.count}} Among them
				</view>
			</view>
			<view class="title flex flex-b" style="background-color: #f8f7fc;">
				<view class="flex-1"></view>
				<view class="flex-1 t-c">current event</view>
				<view class="flex-1 t-c">Industry average</view>
				<view class="flex-1 t-r">Ranking within the industry</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">Evaluation amount</view>
				<view class="flex-1 t-c red num-font" :style="$util.calcStyleRiseFall(top8.marketcap>0)">
					{{top8.marketcap}}100 million
				</view>
				<view class="flex-1 t-c red num-font" :style="$util.calcStyleRiseFall(top8.marketcap_avg>0)">
					{{top8.marketcap_avg}} 100 million
				</view>
				<view class="flex-1 t-r">{{top8.marketcap_rank}}stomach</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">Net profit growth rate</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.net_income_growth>0)">
					{{top8.net_income_growth}}%
				</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.net_income_growth_avg>0)">
					{{top8.net_income_growth_avg}}%
				</view>
				<view class="flex-1 t-r">{{top8.net_income_growth_rank}}위</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">debt ratio</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.debt_ratio>0)">
					{{top8.debt_ratio}}%
				</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.debt_ratio_avg>0)">
					{{top8.debt_ratio_avg}}%
				</view>
				<view class="flex-1 t-r">{{top8.debt_ratio_rank}}위</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">PER</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.per>0)">{{top8.per}}배
				</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.per_avg>0)">
					{{top8.per_avg}}배
				</view>
				<view class="flex-1 t-r">{{top8.per_rank}}위</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">PBR</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.pbr>0)">{{top8.pbr}}배
				</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.pbr_avg>0)">
					{{top8.pbr_avg}}배
				</view>
				<view class="flex-1 t-r">{{top8.pbr_rank}}위</view>
			</view>
			<view class="item flex flex-b">
				<view class="flex-1">ROE</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.roe>0)">{{top8.roe}}%
				</view>
				<view class="flex-1 t-c red" :style="$util.calcStyleRiseFall(top8.roe_avg>0)">
					{{top8.roe_avg}}%
				</view>
				<view class="flex-1 t-r">{{top8.roe_rank}}위</view>
			</view>
		</view> -->
	</view>
</template>

<script>
	import zhexian from '@/utils/zhexian.js';
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: 'InfoTwo',
		components: {
			zhexian
		},
		props: ['code', 'productDetails'],
		data() {

			return {
				cWidth: 750,
				cHeight: 500,
				top1: {
					sharesout: 0,
					year_high: 0,
					marketcap: 0,
					foreigners_pie: 0,
					year_low: 0
				},
				top2: [],
				top3: "",
				top33: "",
				top4: "",
				top5: "",
				top7: "",
				top8: '',
				txt_show: true,
				info_two_ac: 0,
				zhexian_index: 0,
				zhexian_index_i: 29
			}
		},

		methods: {

			qh_info_two(index) {
				this.info_two_ac = index;
				if (index == 0) {
					this.info_two()
				} else {
					this.info_two1()
				}
			},
			number_geshi1(price) {
				var fuhao = "";
				if (price * 1 > 0) {
					fuhao = "+";
				}
				var price = fuhao + price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

				return price;
			},
			number_geshi(prices, index) {
				var prices = (prices * 1).toFixed(index);
				if (prices > 0) {
					prices = "+" + prices;
				}
				return prices;
			},

			drawCharts(id, data) {
				const ctx = uni.createCanvasContext(id, this);
				uChartsInstance[id] = new uCharts({
					type: "ring",
					context: ctx,
					width: this.cWidth,
					height: this.cHeight,
					series: data.series,
					animation: true,
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					background: "#FFFFFF",
					color: ["#1890FF", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [5, 5, 5, 5],
					fontSize: 13,
					fontColor: "#666666",
					dataLabel: true,
					dataPointShape: true,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: true,
						position: "right",
						lineHeight: 25,
						float: "left",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					// title: {
					//   name: "2,515억",
					//   fontSize: 15,
					//   color: "#666666",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					// subtitle: {
					//   name: "자산총계",
					//   fontSize: 25,
					//   color: "#7cb5ec",
					//   offsetX: 0,
					//   offsetY: 0
					// },
					extra: {
						ring: {
							ringWidth: 30,
							activeOpacity: 0.5,
							activeRadius: 10,
							offsetAngle: 0,
							labelWidth: 15,
							border: true,
							borderWidth: 3,
							borderColor: "#FFFFFF",
							centerColor: "#FFFFFF",
							customRadius: 0,
							linearType: "none"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						}
					}
				});
			},
			async info_two() {
				uni.showLoading({
					mask: true
				})
				console.log(this.productDetails);
				let list = await this.$http.post('api/product/info_two', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				uni.hideLoading()
				console.log(list);
				this.top1 = list.data.data[0].top1
				this.top2 = list.data.data[0].top2
				this.top3 = list.data.data[0].top3
				this.top4 = list.data.data[0].top4
				this.top5 = list.data.data[0].top5
				this.top7 = list.data.data[0].top7
				this.top8 = list.data.data[0].top8


				this.zhexian();

				let res = {
					series: [{
						data: list.data.data[0].top6
					}]
				};
				this.drawCharts('huan1', res);

			},
			zhexian_act(index) {
				this.zhexian_index = index;

				if (index == 0) {
					this.zhexian_index_i = 29
				} else if (index == 1) {
					this.zhexian_index_i = 32
				} else if (index == 2) {
					this.zhexian_index_i = 36
				}

				this.zhexian()
			},
			zhexian() {
				let temp_top = this.info_two_ac == 0 ? this.top3 : this.top33;
				let res = {
					categories: temp_top.map(item => item.report_year_month),
					series: [{
						name: "",
						data: temp_top.map(item => item.fields[this.zhexian_index_i].value / 100000000),
					}]
				};

				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(zhexian.Charts(ctx, res, this.cWidth, this.cHeight))
			},
			async info_two1() {
				let list = await this.$http.post('api/product/info_two1', {
					code: this.code,
					stock_id: this.productDetails.stock_id
				})
				this.top33 = list.data.data[0].top3
				this.zhexian_act(0)
			},
		},

		mounted() {
			// this.info_two()
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(750);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);


			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接

		},

		onLoad() {

		},
		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>
<style scoped>
	.charts {
		width: 750rpx;
		height: 500rpx;
	}
</style>
<style lang="scss">
	.info {
		padding: 0 16px 16px;

		uni-view {
			color: #666;
			line-height: 32px;
		}

		.t {
			color: #333;
		}

		.red {
			color: red;
		}

		.blue {
			color: #01B4D5;
		}
	}

	.about {
		// border-top: 5px solid #f0f2f5;
		// border-bottom: 5px solid #f0f2f5;
		padding: 10px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			color: #999;
		}

		.txt {
			margin-top: 6px;
			color: #333;
			line-height: 26px;
		}

		.txt.show {
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 2;
		}
	}

	// .xs{
	//     padding: 16px 0;
	.tb {
		padding: 0 16px 10px;
	}

	.tabs {
		background: #f6c10b24;
		border-radius: 5px;
		height: 32px;
		padding: 0 5px;

		.t {
			font-size: 12px;
			color: #999;
		}

		.active {
			color: #010259;
			background: #fff;
			border-radius: 3px;
		}

		uni-view {
			color: #121212;
			height: 26px;
			line-height: 26px;
			text-align: center;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;
		}
	}

	.nums {
		background: #FFFFFF;
		border-radius: 10px;
		padding: 5px;
		margin: 0 5px;
		text-align: center;

		.t {
			padding: 10px 0;
		}

		.item {
			background: #F8F7FC;
			border-radius: 8px;
			padding: 6px 0;
			width: 32%;

			.t1 {
				color: #999999;
			}

			.t2 {
				font-size: 21px;
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
				margin: 10px 0;
			}

			.t3 {
				font-size: 19px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}

			.die {
				color: #01B4D5;
			}
		}
	}

	.chart-box {
		padding: 16px 5px 10px;
	}

	// }

	.top {
		padding: 16px;

		.t {
			font-size: 17px;
			font-weight: 700;
			color: #333;
		}

		.t1 {
			font-size: 12px;
			color: #999;
		}

		.item {
			background: #f1f2f4;
			border-radius: 10px;
			width: 42%;
			padding: 16px 10px;

			.t1 {
				font-size: 17px;
				font-weight: 700;
				color: #333;
			}

			.t2 {
				color: #999;
			}

			.t3 {
				font-size: 17px;
				font-weight: 700;
				color: #01B4D5;
				margin-right: 5px;
			}

			.t4 {
				color: #333;
			}

			.mtb {
				margin: 16px 0;
			}
		}
	}

	.cot {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;

		.tb {
			padding: 16px 16px 0;
		}
	}

	.border {
		border-bottom: 1px solid #dcdee0;
	}

	.pdd {
		padding: 10px;

		.t2 {
			color: #333;
			font-size: 17px;
		}
	}

	.last {
		padding: 10px 0 0;

		uni-view {
			color: #333;
		}

		.die {
			color: #01B4D5;
		}

		span {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}
	}

	.list {
		border-top: 5px solid #f0f2f5;
		border-bottom: 5px solid #f0f2f5;
		padding: 16px 0;

		.tb {
			padding: 0 16px 16px;
		}

		.tabs {
			background: #f1f2f4;
			border-radius: 5px;
			height: 32px;
			padding: 0 5px;

			.active {
				color: #01B4D5;
				background: #fff;
				border-radius: 3px;
			}
		}

		.mb20 {
			margin-bottom: 10px;
		}

		.titles {
			padding: 10px;
			background: #f0f2f5;
		}

		.item {
			padding: 10px;

			.time {
				color: #333;
			}

			.red.die {
				color: #01B4D5;
			}

			.red {
				font-family: Roboto;
				font-weight: 700;
				color: #f72121;
			}
		}
	}

	.title {
		background: #f0f2f5;
		padding: 10px;
	}

	.item {
		padding: 10px;

		.red {
			font-family: Roboto;
			font-weight: 700;
			color: #f72121;
		}

		uni-view {
			color: #333;
		}

		.red.die {
			color: #01B4D5;
		}
	}
</style>