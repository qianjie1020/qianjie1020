<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line common_block" style="margin:0 10px 20px 10px;padding:10px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Balance</view>
					<view style="flex:70%;font-size: 18px;font-weight: 700;text-align: right;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(item.after)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:40%;" :style="{color:$util.THEME.TIP}">Before change:</view>
					<view style="flex:60%;text-align: right;" >
						{{$util.formatNumber(item.before)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Deposit</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TEXT}">
					{{$util.formatNumber(item.desc)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Date time:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$util.THEME.TIP}">
						{{item.created_at}}
					</view>
				</view>
				<view style="">
					<view >{{item.desc}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FINANCE, {})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>