<template>
	<view class="common_block" style="margin-top: 20px;">
		<TabsSecond :tabs="$util.tabsMarketHot" @action="handleChangeTab"></TabsSecond>
		<template v-if="current<=1">
			<TabsThird :tabs="$util.tabsMarketHotFilter" @action="handleChangeTabFilter"></TabsThird>
		</template>

		<view class="flex flex-b titles" style="padding: 6px 10px;" :style="{color:$util.THEME.LABEL}">
			<view class="flex-2">Item name</view>
			<view class="flex-1 t-r">Current price</view>
			<view class="flex-1 t-r">fluctuation rate</view>
		</view>
		<view>
			<block v-for="(item,index) in list" :key="index">
				<view class="item flex flex-b"
					@click="$u.route($util.PAGE_URL.STOCK_OVERVIEW,{code:item.code,id:item.id});">
					<view class="t flex-2" :style="{color:$util.THEME.TEXT}"><span class="t" :class="index>2?'num':''"
							style="margin-right: 10px;" :style="{color:$util.THEME.TEXT}">{{index+1}} </span>
						{{item.ko_name}}
					</view>
					<view class="t1 flex-1 t-r num-font" :style="$util.calcStyleRiseFall(item.returns>0)">
						{{$util.formatNumber(item.close)}}
					</view>
					<view class="t1 flex-1 t-r" :style="$util.calcStyleRiseFall(item.returns>0)">
						{{(item.returns*1).toFixed(2)}}%
					</view>
				</view>
			</block>
			<view style="text-align: center;color: #999;">For popular items, only the top 100 rankings are provided..</view>
		</view>
	</view>
</template>

<script>
	import TabsSecond from '@/components/TabsSecond.vue';
	import TabsThird from '@/components/TabsThird.vue';
	export default {
		name: 'TabTwo',
		components: {
			TabsSecond,
			TabsThird,
		},
		props: {},
		data() {
			return {
				list: [],
				current1: 0,
				current: 0,
			}
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleChangeTab(val) {
				this.current = val;
				this.getList();
			},
			handleChangeTabFilter(val) {
				this.current1 = val;
				this.getList()
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.GOODS_PAIHANG, {
					current: this.current,
					current1: this.current1,
				})
				this.list = result.data.data
				uni.hideLoading()
			},
		},
	}
</script>

<style lang="scss">
	.titles {
		padding: 10px;

		uni-view {
			color: #91a2b1;
		}
	}

	.item {
		padding: 10px;

		.t {
			font-size: 14px;
			font-weight: 700;
			color: #333;
		}

		.num {
			color: #999;
		}
	}

	.t-r {
		text-align: right;
	}

	.nav-box {
		height: 40px;
		border-bottom: 1px solid #ccc;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;

		.nav-item {
			height: 40px;
			width: 50%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-orient: vertical;
			-webkit-box-direction: normal;
			-webkit-flex-direction: column;
			flex-direction: column;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: end;
			-webkit-justify-content: flex-end;
			justify-content: flex-end;
			font-size: 16px;
			color: #999;

			span {
				width: 100%;
				height: 3px;
				background: transparent;
				margin-top: 10px;
				display: block;
			}
		}

		.active {
			font-size: 16px;
			font-weight: 700;
			color: #FF8C00;

			span {
				background: #d3d3d3;
			}
		}
	}
</style>