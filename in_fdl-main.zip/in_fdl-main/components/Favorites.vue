<template>
	<view class="common_block" style="margin-top:20px;box-shadow: none;padding-bottom: 6px;">
		<view
			style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;">
			<text style="font-size: 16px;" :style="{color:$util.THEME.PRIMARY}">{{ $lang.STOCK_BOOK}}</text>
			<view style="font-size: 14px;" @click="handleAllList()" :style="{color:$util.THEME.LABEL}">
				{{$lang.MORE}}
				<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
			</view>
		</view>
		<view style="overflow-y: scroll;height: 14vh;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view @click="handleDetail(item.goods.code,item.goods.project_type_id)" class="line"
					style="padding-top: 6px;margin-left:10px;display: flex;align-items: center;">
					<view style="display: inline-block;flex:6%;">
						<image mode="aspectFit" :src="$BaseUrl+item.goods.logo" :style="$util.calcImageSize(30)"></image>
					</view>
					<view style="display: inline-block;flex:44%;padding-left: 6px;"
						:style="{color:$util.THEME.TEXT}">
						{{item.goods.name}}
					</view>
					<text style="display: inline-block;flex:25%;text-align: right;padding-right: 16px;font-size: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{$util.formatNumber(item.goods.current_price*1)}}
					</text>
					<view
						style="border-radius: 3px;font-weight: 700; display: inline-block;flex:25%;text-align: right;padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">
						<view style="display: inline-block;padding-right:4px;">{{item.goods.rate>0?'+':""}}{{(1*item.goods.rate).toFixed(2)}}%
						</view>
						<image mode="aspectFit" :src="`/static/${item.goods.rate>0?'up':'down'}.png`"
							:style="$util.calcImageSize(12)"></image>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "Favorites",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},

		mounted() {
			this.getList();
		},

		methods: {
			handleAllList() {
				uni.switchTab({
					url: this.$util.PAGE_URL.STOCK_BOOKMARK
				});
			},
			handleDetail(code,type) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&type=${type}`,
				})
			},
			async getList() {
				// if (this.list.length <= 0) {
				// 	uni.showLoading({
				// 		title: this.$lang.LOADING,
				// 	})
				// }
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (result.data.code == 0) {
					this.list = result.data.data.list;
				}else{
					uni.$u.toast(result.data.message);
				}				
			},
		}
	}
</script>

<style>

</style>