<template>
	<!-- 新股抢筹/配售 -->
	<view style="margin:10px">
		<view style="background-color: #FFF;height: 60vh;margin-top: 10px;padding-top:5px;overflow-y: scroll;">
			<view v-for="(item,index) in funding" :key="index"
				style="border-bottom: 0.037037rem solid #e0e0e0;margin:10px;padding-bottom: 10px;">
				<view class="display" style="margin: 20rpx 0;">
					
					<!-- 申购 -->
					<view class="common_btn" style="margin:10px 60px;" @tap="purchase(item.id,item.peishou_price)">
						요청서
					</view>
				</view>

				<view class="display">
					<view class="display find">
						<view class="">
							발행 가격</view>
						<view class="">{{$util.formatNumber(item.price)}}/공유하다</view>
					</view>
					<view class="display ration">
						<view class="">
							배치 가격</view>
						<view class="">{{$util.formatNumber(item.peishou_price)}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				funding: ''
			}
		},
		methods: {
			// 기록 보관
			ration() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/ration'
				});
			},
			// 우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/ration/luckyNumber'
				});
			},
			//抢筹
			purchase(id, peishou_price) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/offlinePlacement/offlinePlacement' +
						`?id=${id}&peishou_price=${peishou_price}`
				});
				// console.log(gid, '抛出去');
			},

			//列表
			async scramble() {
				let list = await this.$http.post('api/goods-scramble/calendar', {})
				this.funding = list.data.data
				// console.log(this.funding, '99999999');
			},
		},
		mounted() {
			this.scramble()
		}
	}
</script>

<style lang="scss">
	.corporation {
		font-size: 30rpx;
		font-weight: 600;
		color: #333;

	}

	.purchase {
		background-color: rgb(72, 156, 229);
		color: #fff;
		border-radius: 40rpx;
		padding: 6rpx 40rpx;
		font-size: 26rpx
	}

	.find {
		width: 50%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	.ration {
		width: 42%;
		font-size: 28rpx;

		view:nth-child(2) {
			color: #f85252;
		}
	}

	// .science {
	// 	// margin: 30rpx;
	// 	// padding-bottom: 30rpx;
	// 	border-bottom: 0.037037rem solid #e0e0e0;


	// }
</style>