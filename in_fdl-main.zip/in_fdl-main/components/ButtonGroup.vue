<template>
	<view class="btns" style="background-color: transparent;padding:0 4px;">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.calcImageSize(40)"></image>
				<text style="padding-top: 6px;font-size: 15px;width: 110px;text-align: center;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		props: ['btns', 'col'],
		data() {
			return {};
		},

		methods: {
			actionEvent(url, index) {
				// 如果是客服
				if (url.includes('service')) {
					uni.showToast({
						title: `Hello, please contact offline customer service.`,
						icon: 'none'
					});
					return false;
				}

				// 如果点击大宗交易
				if (url == `/pages/trade/large`) {
					console.log('btn:', url);
					this.$emit('action', url);
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>