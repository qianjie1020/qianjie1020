# in_fdl
fork yindu5

![LOGO](https://github.com/github1413/in_fdl/raw/main/static/logo.png)

nse用ncode   bse用bcode
或者就是project_type_id=1用ncode   2就是bcode